package com.auto.mall.mapper;

import com.auto.mall.model.MoneyLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface MoneyLogMapper extends BaseMapper<MoneyLog> {
}
