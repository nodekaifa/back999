package com.auto.mall.api.req;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@Data
public class BatchOrderReq implements Serializable {
    private static final long serialVersionUID = -82328037365315952L;
    /**
     * 下单用户ID
     */
    private List<String> partyIds;
    /**
     * 商品ID
     */
    private List<String> items;
    /**
     * 商品属性ID
     */
    private List<String> skuIds;
    /**
     * 下单时间区间
     */
    private String[] datetime;
    /**
     * 下单间隔区间
     */
    private int[] time_limit;
    /**
     * 单笔价格区间
     */
    private BigDecimal[] price_limit;

    private int[] item_limit;

    private BigDecimal total_amount;
    /**
     * 总单数
     */
    private int total_count;

    /**
     * 操作人名称
     */
    private String createUser;


}
