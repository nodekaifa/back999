package com.auto.mall.utils;

public class Constant {

    /**
     * 订单收入
     */
    public static final String MONEY_LOG_CONTENT_ORDER_INCOME = "order-income";

    /**
     * 订单一级返利
     */
    public static final String MONEY_LOG_CONTENT_ORDER_REBATE = "brokerage";


    public static final String LEVEL_ONE_REBATE_RATIO = "level_one_rebate_ratio";

    public static final String LEVEL_TWO_REBATE_RATIO = "level_two_rebate_ratio";

    public static final String LEVEL_THREE_REBATE_RATIO = "level_three_rebate_ratio";
    /**
     * pos下单单笔金额浮动比例
     */
    public static final String POS_ODER_FLOAT_RATIO = "pos_oder_float_ratio";

}
