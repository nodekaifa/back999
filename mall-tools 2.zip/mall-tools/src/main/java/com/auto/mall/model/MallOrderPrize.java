package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@TableName("T_MALL_ORDERS_PRIZE")
public class MallOrderPrize implements Serializable {
    private static final long serialVersionUID = 2053074722488993544L;

    @TableId(value = "uuid")
    private String uuid;

    @TableField(value = "party_id")
    private String partyId;

    @TableField(value = "user_code")
    private String userCode;

    @TableField(value = "seller_id")
    private String sellerId;

    @TableField(value = "seller_name")
    private String sellerName;

    @TableField(value = "goods__count")
    private Integer goodsCount;

    @TableField(value = "prize_original")
    private BigDecimal prizeOriginal;

    @TableField(value = "prize_real")
    private BigDecimal prizeReal;

    @TableField(value = "system_price")
    private BigDecimal systemPrice;

    @TableField(value = "status")
    private Integer status;

    @TableField(value = "order_status")
    private Integer orderStatus;

    @TableField(value = "return_status")
    private Integer returnStatus;

    @TableField(value = "fees")
    private BigDecimal fees;

    @TableField(value = "tax")
    private BigDecimal tax;

    @TableField(value = "profit")
    private BigDecimal profit;

    @TableField(value = "create_time")
    private Date createTime;

    @TableField(value = "refund_time")
    private Date refundTime;

    @TableField(value = "refund_deal_time")
    private Date refundDealTime;

    @TableField(value = "pay_time")
    private Date payTime;

    @TableField(value = "pay_status")
    private Integer payStatus;

    @TableField(value = "up_time")
    private Long upTime;

    @TableField(value = "phone")
    private String phone;

    @TableField(value = "email")
    private String email;

    @TableField(value = "contacts")
    private String contacts;

    @TableField(value = "postcode")
    private String postcode;

    @TableField(value = "country")
    private String country;

    @TableField(value = "province")
    private String province;

    @TableField(value = "city")
    private String city;

    @TableField(value = "address")
    private String address;

    @TableField(value = "profit_status")
    private Integer profitStatus;

    @TableField(value = "purch_status")
    private Integer purchStatus;

    @TableField(value = "purch_time")
    private Date purchTime;

    @TableField(value = "refund_remark")
    private String refundRemark;

    @TableField(value = "return_reason")
    private String returnReason;

    @TableField(value = "return_detail")
    private String returnDetail;

    @TableField(value = "has_comment")
    private Integer hasComment;

}
