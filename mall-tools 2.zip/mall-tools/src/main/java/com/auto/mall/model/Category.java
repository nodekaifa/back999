package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
@TableName("T_MALL_CATEGORY")
public class Category implements Serializable {

    private static final long serialVersionUID = 6045174050551552011L;

    @TableId(value = "UUID", type = IdType.UUID)
    private String id;

    @TableField(value = "SORT")
    private Integer sort;

    @TableField(value = "ICON_IMG")
    private String iconImg;

    @TableField(value = "REC_TIME")
    private long recTime;

    @TableField(value = "CREATE_TIME")
    private Date createTime;

    @TableField(value = "STATUS")
    private String status;



}