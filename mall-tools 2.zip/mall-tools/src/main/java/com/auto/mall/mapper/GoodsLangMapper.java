package com.auto.mall.mapper;

import com.auto.mall.model.GoodsLang;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface GoodsLangMapper extends BaseMapper<GoodsLang> {
}
