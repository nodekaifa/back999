package com.auto.mall.model;

import com.auto.mall.api.req.GoodsReq;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

@Data
@TableName("T_MALL_SYSTEM_GOODS_LANG")
public class GoodsLang implements Serializable {
    private static final long serialVersionUID = 1655474738296596465L;

    @TableId(value = "uuid", type = IdType.UUID)
    private String id;

    @TableField(value = "goods_id")
    private String goodId;

    @TableField(value = "lang")
    private String lang = "en";

    @TableField(value = "unit")
    private String unit;

    @TableField(value = "name")
    private String name;

    @TableField(value = "des")
    private String des;

    @TableField(value = "img_des")
    private String img_desc;

    @TableField(value = "type")
    private Integer type = 0;

    public GoodsLang(){

    }

    public GoodsLang(GoodsReq req, String goodId){
        this.goodId = goodId;
        this.name = req.getTitle().replaceAll(" ", "");
        this.des = req.basic_info_str();
        this.img_desc = req.detail_str();
    }

}
