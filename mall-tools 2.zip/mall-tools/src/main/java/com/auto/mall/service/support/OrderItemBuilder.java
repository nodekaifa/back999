package com.auto.mall.service.support;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.auto.mall.dto.LocalOrderResult;
import com.auto.mall.model.OrderRecordDetail;
import com.auto.mall.service.OrderRecordDetailService;
import com.auto.mall.service.OrderRecordService;
import com.auto.mall.utils.StringUtils;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
public class OrderItemBuilder implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(OrderItemBuilder.class);

    private String api;

    private String orderId;

    private long delay;

    private String partyId;

    /**
     * 店铺商品id + skuId
     */
    private String uuid;

    /**
     * 商家店铺id
     */
    private String sellerId;

    private int count;

    private BigDecimal amount;

    private OrderRecordService orderRecordService;

    private OrderRecordDetailService recordDetailService;

    public OrderItemBuilder(){

    }

    public OrderItemBuilder(long time,String partyId, String uuid, String sellerId,int count, BigDecimal amount){
        this.delay = time;
        this.partyId = partyId;
        this.uuid = uuid;
        this.sellerId = sellerId;
        this.count = count;
        this.amount = amount;
    }

    @Override
    public void run() {
        if (this.delay > 0){
            String value = HttpUtil.post(api + "?partyId=" + this.partyId + "&uuid=" + this.uuid + "&num=" + this.count, "");
            logger.info("execute batch order:[orderId=>{}, partyId=>{},uuid=>{}, count=>{}, amount=>{}], response:[{}]", orderId,
                        this.partyId, this.uuid, this.count, this.amount, value);
            // 从orderList里提取orderId
            try {
                JSONObject object = JSONUtil.parseObj(value);
                JSONObject data = JSONUtil.parseObj(object.get("data"));
                List<LocalOrderResult> orderList = data.getBeanList("orderList", LocalOrderResult.class);
                // 成功下的订单数量
                Set<String> orderSuccess = orderList.stream()
                        .filter(o -> o != null && StringUtils.isNotEmpty(o.getOrderId()))
                        .map(LocalOrderResult ::getOrderId)
                        .collect(Collectors.toSet());
                String[] split = uuid.split(",");
                this.orderRecordService.updateItem(this.orderId, this.uuid, this.count, this.amount, orderSuccess);
                if (CollectionUtil.isNotEmpty(orderSuccess)){
                    for (String success : orderSuccess) {
                        OrderRecordDetail detail = new OrderRecordDetail(this.orderId,
                                success, this.partyId, this.amount, this.sellerId, split[0], split[1], this.count);
                        this.recordDetailService.save(detail);
                    }
                }
            }catch (Exception e){
                e.printStackTrace();;
            }
        }
    }
}
