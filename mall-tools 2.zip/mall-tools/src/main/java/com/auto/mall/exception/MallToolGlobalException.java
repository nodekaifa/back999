package com.auto.mall.exception;


import lombok.Data;

@Data
public class MallToolGlobalException extends RuntimeException{

    private int code;

    private String message;

    public MallToolGlobalException(){
        super();
        this.code = 500;
    }

    public MallToolGlobalException(String message){
        super(message);
        this.code = 500;
        this.message = message;
    }

    public MallToolGlobalException(int code, String message){
        super(message);
        this.code = code;
        this.message = message;
    }

}
