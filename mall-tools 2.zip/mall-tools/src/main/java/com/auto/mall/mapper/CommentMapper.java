package com.auto.mall.mapper;

import com.auto.mall.model.Comment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface CommentMapper extends BaseMapper<Comment> {
}
