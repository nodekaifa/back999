package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@TableName("T_MONEY_LOG")
public class MoneyLog implements Serializable {
    private static final long serialVersionUID = 56724818108491382L;

    @TableId(value = "uuid", type = IdType.UUID)
    private String id;

    @TableField(value = "log")
    private String log;

    @TableField(value = "wallettype")
    private String walletType;

    @TableField(value = "create_time")
    private Date createTime;

    @TableField(value = "party_id")
    private String partyId;

    @TableField(value = "amount")
    private BigDecimal amount;

    @TableField(value = "amount_before")
    private BigDecimal amountBefore;

    @TableField(value = "amount_after")
    private BigDecimal amountAfter;

    @TableField(value = "content_type")
    private String contentType;

    @TableField(value = "category")
    private String category;

}
