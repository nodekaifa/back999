package com.auto.mall.api.req;



public class PromoteReq extends PageReq {
    private static final long serialVersionUID = 6038545556502126284L;

    private Integer level;

    private String token;

    private String partyId;

    public Integer getLevel() {
        return (null == level || level <= 0) ? 1 : level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }
}
