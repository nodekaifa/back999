package com.auto.mall.model;

import com.auto.mall.api.req.CommentReq;
import com.auto.mall.api.req.GoodsReq;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

@Data
@TableName("T_MALL_COMMENT")
public class Comment implements Serializable {
    private static final long serialVersionUID = 6045174050551552011L;

    @TableId(value = "uuid", type = IdType.UUID)
    private String id;

    @TableField(value = "username")
    private String username;

    @TableField(value = "category")
    private String category;

    @TableField(value = "good_id")
    private String goodId;

    @TableField(value = "content")
    private String content;

    @TableField(value = "date")
    private String date;


    public Comment(){
    }

    public Comment(CommentReq req, String category, String goodId){
        this.username = req.getUsername();
        this.goodId = goodId;
        this.category = category;
        this.content = req.getContent();
        this.date = req.getDate();
    }

}
