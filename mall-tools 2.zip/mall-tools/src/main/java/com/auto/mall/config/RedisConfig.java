package com.auto.mall.config;


import com.auto.mall.config.codec.FastJsonCodec;
import lombok.Getter;
import lombok.Setter;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "mall.redis")
public class RedisConfig {

    private static final Logger logger = LoggerFactory.getLogger(RedisConfig.class);

    private String host = "redis://127.0.0.1:6380";

    private String password = "";

    private ServerModel serverModel = ServerModel.Single;

    public enum ServerModel {
        /**
         * 默认:单机模式
         */
        Single,
    }

    @Bean
    public RedissonClient redissonClient(){
        Config config = new Config();
        if(serverModel == ServerModel.Single){
            config.useSingleServer()
                    .setAddress(host);
        }
        logger.info("init redis service:{}, model:{}", this.host, serverModel.name());
        config.setCodec(new FastJsonCodec());
        return Redisson.create(config);
    }



}
