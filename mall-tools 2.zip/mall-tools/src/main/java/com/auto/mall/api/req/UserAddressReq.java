package com.auto.mall.api.req;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserAddressReq implements Serializable {
    private static final long serialVersionUID = -5587107986675583725L;

    private String userAddressId;

}