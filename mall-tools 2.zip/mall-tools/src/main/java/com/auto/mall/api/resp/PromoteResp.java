package com.auto.mall.api.resp;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;


@Data
public class PromoteResp implements Serializable {
    private static final long serialVersionUID = -3472269520924090526L;

    private String uuid;

    private String avatar;

    private String name;

    private BigDecimal income;

    private Integer orderCount;

    private String createTime;

}
