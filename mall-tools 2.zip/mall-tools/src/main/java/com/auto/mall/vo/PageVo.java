package com.auto.mall.vo;

import lombok.Data;

@Data
public class PageVo {

    private static final long serialVersionUID = 885273467335880608L;
    private Integer pageNum = 1;

    private Integer pageSize = 10;
}