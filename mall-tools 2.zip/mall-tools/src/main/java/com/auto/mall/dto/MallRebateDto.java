package com.auto.mall.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;


@Data
public class MallRebateDto implements Serializable {

    private String uuid;

    private int orderCount;

    private BigDecimal income;

}
