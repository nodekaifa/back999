package com.auto.mall.service.impl;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.auto.mall.api.req.SellerGoodsReq;
import com.auto.mall.api.resp.CategoryResp;
import com.auto.mall.api.resp.PageResp;
import com.auto.mall.api.resp.PartyResp;
import com.auto.mall.api.resp.SellerGoodsResp;
import com.auto.mall.api.resp.SellerResp;
import com.auto.mall.mapper.CategoryMapper;
import com.auto.mall.model.UserRecom;
import com.auto.mall.service.CategoryService;
import com.auto.mall.service.redis.RedisService;
import com.auto.mall.utils.RedisKey;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Resource
    private CategoryMapper categoryMapper;

    @Resource
    RedisService redisService;

    @Override
    public List<CategoryResp> findCategoryList() {
        return categoryMapper.findCategoryList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<SellerResp> findSellerList(String loginPartyId) {
        List<SellerResp> sellerResps = categoryMapper.findSellerList();
        if (loginPartyId != null) {
            List<String> children = findChildren(loginPartyId);
            sellerResps = sellerResps.stream().filter(s -> children.stream().filter(f -> f.equals(s.getSellerId())).findAny().isPresent()).collect(Collectors.toList());
        }
        return sellerResps;
    }

    @Override
    @Transactional(readOnly = true)
    public PageResp findSellerGoodsList(SellerGoodsReq req) {
        Page page = req.getPage();
        String loginPartyId = req.getLoginPartyId();

        List<SellerGoodsResp> sellerGoodsList = null;
        if (StrUtil.isBlank(loginPartyId)) {
            sellerGoodsList = categoryMapper.findSellerGoodsList(page, req);
        } else {
            List<String> children = findChildren(loginPartyId);
            req.setChildren(children);
            sellerGoodsList = categoryMapper.findSellerGoodsList(page, req);
        }

        PageResp pageResp = new PageResp<>(page, sellerGoodsList);
        return pageResp;
    }

    @Override
    @Transactional(readOnly = true)
    public List<PartyResp> findPartyList() {
        return categoryMapper.findPartyList();
    }

    @Override
    @Transactional(readOnly = true)
    public int findPartyCount() {
        return categoryMapper.findPartyCount();
    }

    public List<String> findChildren(String partyId) {
        List list = new ArrayList();
        list = findChildren(partyId, list);
        return list;
    }

    private List<String> findChildren(Serializable partyId, List<String> list) {
        List recom_list = findRecoms(partyId);
        for (int i = 0; i < recom_list.size(); i++) {
            list.add(((UserRecom) recom_list.get(i)).getPartyId().toString());
            findChildren(((UserRecom) recom_list.get(i)).getPartyId().toString(), list);
        }

        return list;
    }

    public List<UserRecom> findRecoms(Serializable partyId) {
        List<UserRecom> list = new ArrayList<>();

        JSONArray jsonArray = redisService.get(RedisKey.USER_RECOM_RECO_ID + partyId.toString(), JSONArray.class);
        if (!Objects.isNull(jsonArray) && !jsonArray.isEmpty()) {
            for (Object o : jsonArray) {
                UserRecom userRecom = new UserRecom();
                JSONObject object = (JSONObject) o;
                userRecom.setPartyId((String) object.get("partyId"));
                ;
                list.add(userRecom);
            }
        }
        return list;
    }

}