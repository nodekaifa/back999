package com.auto.mall.service.support.wheel;

import cn.hutool.core.collection.CollectionUtil;
import io.netty.util.HashedWheelTimer;
import io.netty.util.Timeout;
import io.netty.util.TimerTask;
import io.netty.util.internal.PlatformDependent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class OrderTimeWheelScheduler implements TimeWheelScheduler {

    private final HashedWheelTimer executorService;

    private final ScheduledThreadPoolExecutor scheduledExecutor;

    private final ConcurrentMap<String, List<Timeout>> scheduledFutures = PlatformDependent.newConcurrentHashMap();

    // todo 存储任务状态
    private final ConcurrentMap<String, Integer> scheduledStatus = PlatformDependent.newConcurrentHashMap();
    private static volatile OrderTimeWheelScheduler ORDER_WHEEL_TIMER;


    public static OrderTimeWheelScheduler getInstance(){
        if(null == ORDER_WHEEL_TIMER){
            synchronized (OrderTimeWheelScheduler.class){
                if(null == ORDER_WHEEL_TIMER){
                    ORDER_WHEEL_TIMER = new OrderTimeWheelScheduler();
                }
            }
        }
        return ORDER_WHEEL_TIMER;
    }


    private OrderTimeWheelScheduler(){
        this.executorService = new HashedWheelTimer();
        this.scheduledExecutor = new ScheduledThreadPoolExecutor(2);
    }


    @Override
    public void schedule(String key, Runnable runnable, long delay, TimeUnit unit) {
        Timeout timeout = this.executorService.newTimeout(new TimerTask() {
            @Override
            public void run(Timeout timeout) throws Exception {
                scheduledExecutor.execute(() -> {
                    runnable.run();
                });
            }
        }, delay, unit);
        if(!timeout.isExpired()){
            this.put(key, timeout);
        }
    }

    private void put(String key, Timeout timeout){
        List<Timeout> timeoutList = this.scheduledFutures.get(key);
        if (CollectionUtil.isEmpty(timeoutList)){
            timeoutList = new ArrayList<>();
        }
        timeoutList.add(timeout);
        this.scheduledFutures.put(key, timeoutList);
    }

    @Override
    public void cancel(String key) {
        List<Timeout> timeouts = this.scheduledFutures.get(key);
        if (CollectionUtil.isNotEmpty(timeouts)){
            for (Timeout timeout : timeouts) {
                if (null != timeout && !timeout.isExpired()){
                    timeout.cancel();
                }
            }
        }
    }
}
