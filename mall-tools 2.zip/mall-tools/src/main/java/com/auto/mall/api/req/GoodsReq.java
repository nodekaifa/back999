package com.auto.mall.api.req;

import cn.hutool.core.collection.CollectionUtil;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class GoodsReq implements Serializable {
    private static final long serialVersionUID = -5123352701056675374L;

    private String title;

    private String link;

    private String price;

    private String category;

    private List<String> img;

    private List<String> basic_info;

    private List<String> detail;

    private List<CommentReq> comments;

    public String detail_str(){
        if (CollectionUtil.isEmpty(this.detail)){
            return "";
        }
        StringBuilder builder = new StringBuilder();
        for (String s : this.detail) {
            builder.append(s+",");
        }
        return builder.toString();
    }

    public String basic_info_str(){
        if(CollectionUtil.isEmpty(this.basic_info)){
            return "";
        }
        StringBuilder builder = new StringBuilder();
        for (String s : this.basic_info) {
            builder.append(s+",");
        }
        return builder.toString();
    }

    @Override
    public String toString() {
        return "GoodsReq{" +
                "title='" + title + '\'' +
                ", price='" + price + '\'' +
                ", link='" + link + '\'' +
                ", category='" + category + '\'' +
                ", img=" + img +
                ", basic_info=" + basic_info +
                ", detail=" + detail +
                ", comments=" + comments +
                '}';
    }
}
