package com.auto.mall.utils;

public class RedisKey {

    public static final String TOKEN = "TOKEN_";

    /**
     * 后台免登录token
     */
    public static final String PLAT_FROM_TOKEN = "PLAT_FROM_TOKEN_";

    public static final String SYSPARA_CODE = "SYSPARA_CODE_";

    public static final String WALLET_KEY = "WALLET_PARTY_ID_";

    public static final String ORDER_LOCK = "order-lock_";


    public final static String USER_RECOM_RECO_ID = "USER_RECOM_RECO_ID_";

}
