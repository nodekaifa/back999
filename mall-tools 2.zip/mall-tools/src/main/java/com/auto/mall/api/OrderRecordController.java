package com.auto.mall.api;

import cn.hutool.core.bean.BeanUtil;
import com.auto.mall.api.req.OrderRecordReq;
import com.auto.mall.api.resp.MallOrdersPrizeResp;
import com.auto.mall.api.resp.PageResp;
import com.auto.mall.dto.OrderRecordDetailDto;
import com.auto.mall.model.MallOrdersPrize;
import com.auto.mall.model.OrderRecord;
import com.auto.mall.service.MallOrdersPrizeService;
import com.auto.mall.service.OrderRecordDetailService;
import com.auto.mall.service.OrderRecordService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/orderRecord")
public class OrderRecordController {

    @Autowired
    private OrderRecordService orderRecordService;

    @Autowired
    private MallOrdersPrizeService mallOrdersPrizeService;

    @Resource
    OrderRecordDetailService recordDetailService;

    /**
     * 下单记录
     *
     * @param req
     * @return
     */
    @PostMapping("/list")
    public PageResp<OrderRecord> findOrderRecordList(@RequestBody OrderRecordReq req) {

        return orderRecordService.findOrderRecordByPage(req);
    }

    @PostMapping("/list/detail")
    public PageResp<OrderRecordDetailDto> orderDetail(@RequestBody OrderRecordReq req) {
        return this.recordDetailService.selectOrderRecordDetailByPage(req);
    }

    /**
     * 下单中已经返回的订单
     *
     * @param req 请求信息
     * @return
     */
    @PostMapping("/details/orderedList")
    public PageResp<MallOrdersPrizeResp> findSellerGoodsList(@RequestBody OrderRecordReq req) {
//        OrderRecord orderRecord = orderRecordService.queryOrderList(req.getId());
//        ArrayList<MallOrdersPrizeResp> emptyList = new ArrayList<>();
//        if (orderRecord == null) {
//            return JsonResponse.success(200, "", emptyList);
//        }
//        String orderIds = orderRecord.getOrderIds();
//        if (StringUtils.isEmpty(orderIds)) {
//            return JsonResponse.success(200, "", emptyList);
//        }
//        List<String> orderIdList = StrSplitter.split(orderIds, ",", true, true);
//        if (CollectionUtil.isEmpty(orderIdList)) {
//            return JsonResponse.success(200, "", emptyList);
//        }
        List<MallOrdersPrize> mallOrdersPrizes =  recordDetailService.queryOrderList(req);
        long total = recordDetailService.queryOrderTotal(req);
        List<MallOrdersPrizeResp> mallOrdersPrizeResps = BeanUtil.copyToList(mallOrdersPrizes, MallOrdersPrizeResp.class);
        Page page = req.getPage();
        page.setTotal(total);
        return new PageResp(page, mallOrdersPrizeResps);
    }
}
