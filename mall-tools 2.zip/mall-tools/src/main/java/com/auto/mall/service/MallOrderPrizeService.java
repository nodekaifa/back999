package com.auto.mall.service;

import cn.hutool.core.collection.CollectionUtil;
import com.auto.mall.mapper.MallOrderPrizeMapper;
import com.auto.mall.mapper.MallRebateMapper;
import com.auto.mall.mapper.UserDataMapper;
import com.auto.mall.model.MallOrderPrize;
import com.auto.mall.model.MallRebate;
import com.auto.mall.model.MoneyLog;
import com.auto.mall.model.PatParty;
import com.auto.mall.model.UserData;
import com.auto.mall.model.Wallet;
import com.auto.mall.service.redis.RedisService;
import com.auto.mall.utils.Constant;
import com.auto.mall.utils.RedisKey;
import com.auto.mall.utils.StringUtils;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;


@Service
public class MallOrderPrizeService extends ServiceImpl<MallOrderPrizeMapper, MallOrderPrize> {

    private static final Logger logger = LoggerFactory.getLogger(MallOrderPrizeService.class);

    @Resource
    UserRecomService userRecomService;

    @Resource
    SysParamService sysParamService;

    @Resource
    WalletService walletService;

    @Resource
    MoneyLogService moneyLogService;

    @Resource
    MallRebateMapper mallRebateMapper;

    @Resource
    UserDataMapper userDataMapper;

    @Resource
    RedisService redisService;

    @Resource
    PatPartyService patPartyService;

    @Transactional
    public List<String> distribution(String orderId) {
        List<String> result = new ArrayList<>();
        try {
            boolean tryLock = this.redisService.tryLock(RedisKey.ORDER_LOCK + orderId);
            if (tryLock) {
                MallOrderPrize mallOrderPrize = this.getBaseMapper().selectById(orderId);
                if (Objects.nonNull(mallOrderPrize)) {
                    Integer status = mallOrderPrize.getStatus();
                    Integer profitStatus = mallOrderPrize.getProfitStatus();
                    logger.info("订单[{}][status:{}][profit-status:{}]释放佣金!", orderId, status, profitStatus);
                    if ((status == 4 || status == 5) && (null == profitStatus || profitStatus.intValue() == 0)) {
                        QueryWrapper<MoneyLog> wrapper = new QueryWrapper<>();
                        wrapper.like("LOG", orderId);
                        wrapper.eq("CONTENT_TYPE", Constant.MONEY_LOG_CONTENT_ORDER_INCOME);
                        List<MoneyLog> moneyLogs = this.moneyLogService.getBaseMapper().selectList(wrapper);
                        if (CollectionUtil.isNotEmpty(moneyLogs)) {
                            this.updateOrder(mallOrderPrize);
                            return result;
                        }
                        String sellerId = mallOrderPrize.getSellerId();
                        Map<Integer, String> parents = this.userRecomService.findParents(sellerId);
                        // 总利润
                        BigDecimal profit = mallOrderPrize.getProfit();
                        BigDecimal remain = profit;
                        if (CollectionUtil.isNotEmpty(parents)) {
                            for (Map.Entry<Integer, String> entry : parents.entrySet()) {
                                Integer level = entry.getKey();
                                String userId = entry.getValue();
                                PatParty party = this.patPartyService.getById(userId);
                                if (Objects.isNull(party) || party.getRoleName().equals("AGENT")) {
                                    continue;
                                }
                                BigDecimal rebate_ratio = this.sysParamService.getLevelRatio(level);
                                if (null != rebate_ratio) {
                                    BigDecimal rebateAmount = profit.multiply(rebate_ratio).setScale(2, BigDecimal.ROUND_HALF_UP);
                                    if (rebateAmount.compareTo(new BigDecimal("0.00")) > 0) {
                                        remain = remain.subtract(rebateAmount);
                                        this.updateWallet(orderId, userId, Constant.MONEY_LOG_CONTENT_ORDER_REBATE, null, rebateAmount);
                                        this.saveMallRebate(orderId, userId, sellerId, level, rebateAmount);
                                        this.saveUserData(userId, level, rebateAmount);
                                        result.add(userId);
                                    }
                                }
                            }
                        }
                        result.add(sellerId);
                        this.updateWallet(orderId, sellerId, Constant.MONEY_LOG_CONTENT_ORDER_INCOME, mallOrderPrize.getSystemPrice(), remain);
                        this.updateOrder(mallOrderPrize);
                    }
                }
            }
        } catch (Exception ex) {
            logger.info(ex.getMessage());
        } finally {
            this.redisService.unLock(RedisKey.ORDER_LOCK + orderId);
        }
        return result;
    }

    private void saveUserData(String partyId, Integer level, BigDecimal rebateAmount) {
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDateTime startTime = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
        LocalDateTime endTime = LocalDateTime.of(LocalDate.now(), LocalTime.MAX);
        QueryWrapper<UserData> wrapper = new QueryWrapper<>();
        wrapper.eq("party_id", partyId);
        wrapper.between("create_time", Date.from(startTime.atZone(zoneId).toInstant()), Date.from(endTime.atZone(zoneId).toInstant()));
        List<UserData> userDatas = this.userDataMapper.selectList(wrapper);
        UserData userData = new UserData();
        if (CollectionUtil.isNotEmpty(userDatas)) {
            userData = userDatas.get(0);
        }
        switch (level) {
            case 1:
                userData.setRebate1(rebateAmount.add(userData.getRebate1()));
                break;
            case 2:
                userData.setRebate2(rebateAmount.add(userData.getRebate2()));
                break;
            case 3:
                userData.setRebate3(rebateAmount.add(userData.getRebate3()));
                break;
        }
        if (StringUtils.isEmpty(userData.getId())) {
            userData.setPartyId(partyId);
            userData.setCreateTime(new Date());
            this.userDataMapper.insert(userData);
        } else {
            this.userDataMapper.updateById(userData);
        }
    }

    private void saveMallRebate(String orderId, String partyId, String orderSellerId, Integer level, BigDecimal rebateAmount) {
        MallRebate rebate = new MallRebate();
        rebate.setOrderId(orderId);
        rebate.setPartyId(partyId);
        rebate.setOrderPartyId(orderSellerId);
        rebate.setLevel(level);
        rebate.setRebate(rebateAmount);
        rebate.setCreateTime(new Date());
        this.mallRebateMapper.insert(rebate);
    }

    private void updateWallet(String orderId, String partyId, String type, BigDecimal principal, BigDecimal amount) {
        QueryWrapper<Wallet> wrapper = new QueryWrapper<>();
        wrapper.eq("party_id", partyId);
        Wallet wallet = this.walletService.getBaseMapper().selectOne(wrapper);
        BigDecimal totalAmount = amount;
        if (null == wallet) {
            wallet = new Wallet();
            wallet.setPartyId(partyId);
        }
        if (null != principal) {
            totalAmount = amount.add(principal);
        }
        BigDecimal currentAmount = wallet.getMoney();
        BigDecimal afterAmount = currentAmount.add(totalAmount);
        wallet.setMoney(afterAmount);
        wallet.setRebate(wallet.getRebate().add(amount));
        this.walletService.getBaseMapper().updateById(wallet);
        redisService.set(RedisKey.WALLET_KEY + wallet.getPartyId(), wallet);
        MoneyLog log = new MoneyLog();
        log.setLog("订单：" + orderId);
        log.setAmount(totalAmount);
        log.setAmountBefore(currentAmount);
        log.setAmountAfter(afterAmount);
        log.setPartyId(partyId);
        log.setCreateTime(new Date());
        log.setWalletType("USDT");
        log.setCategory("coin");
        log.setContentType(type);

        this.moneyLogService.getBaseMapper().insert(log);

    }

    private void updateOrder(MallOrderPrize orderPrize) {
        orderPrize.setProfitStatus(1);
        this.getBaseMapper().updateById(orderPrize);
    }
}
