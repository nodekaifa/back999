package com.auto.mall.api.resp;

import lombok.Data;

import java.io.Serializable;

@Data
public class PartyResp implements Serializable {

    private static final long serialVersionUID = 5510845374811485958L;
    //收货人Id
    private String partyId;

    //收货人姓名
    private String contacts;

    //用户地址Id
    private String userAddressId;

}