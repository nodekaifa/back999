package com.auto.mall.page;

import com.github.pagehelper.Page;
import lombok.Data;
import org.springframework.http.HttpStatus;

import java.io.Serializable;
import java.util.List;

/**
 * @description
 * @date 2017/11/14 11:15 create
 */
@Data
public class PageResult<T> implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 2984636422561292981L;

    private int code;
    private String msg;
    private long totalRows = 0;
    private int totalPages = 0;
    private int pageNum = 1;
    private int pageSize = 0;
    private List<T> rows;

    public PageResult() {
    }

    /**
     * 构造函数
     *
     * @param list
     */
    public PageResult(List<T> list) {
        this.code = HttpStatus.OK.value();
        this.msg = "success!";
        //分页插件的结果集
        if (list instanceof Page) {
            Page<T> page = (Page<T>) list;
            this.totalPages = page.getPages();
            this.totalRows = page.getTotal();
            this.pageNum = page.getPageNum();
            this.pageSize = page.getPageSize();
            this.rows = page.getResult();
        } else {
            this.rows = list;
        }
    }

    public void setTotalRows(long totalRows) {
        this.totalRows = totalRows;
    }

    public void setTotalRows(long totalRows,int i) {
        this.totalRows = totalRows;
        calTotalPages();
    }

    public void calTotalPages() {
        this.totalPages = (int) ((this.totalRows % this.pageSize == 0) ? this.totalRows
                / this.pageSize
                : this.totalRows / this.pageSize + 1);
    }

    public int getTotalPages() {
        return totalPages;
    }


}
