package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@TableName("T_MALL_REBATE")
public class MallRebate implements Serializable {

    @TableId(value = "uuid", type = IdType.UUID)
    private String id;

    @TableField(value = "order_id")
    private String orderId;

    @TableField(value = "party_id")
    private String partyId;

    @TableField(value = "order_party_id")
    private String orderPartyId;

    @TableField(value = "rebate")
    private BigDecimal rebate;

    @TableField(value = "level")
    private Integer level;

    @TableField(fill = FieldFill.INSERT,value = "create_time")
    private Date createTime;

}
