package com.auto.mall.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
public class OrderRecordDetailDto implements Serializable {
    private static final long serialVersionUID = -6207467070540174816L;

    private String id;

    private String recordId;

    private String orderId;

    private String userId;

    private String shopName;

    private String username;

    private BigDecimal orderAmount;

    /**
     * 单价
     */
    private BigDecimal amount;

    private String goodsName;

    private Date createTime;

    private Integer num;

}
