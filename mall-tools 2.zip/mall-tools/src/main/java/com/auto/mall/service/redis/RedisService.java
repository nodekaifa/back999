package com.auto.mall.service.redis;


import cn.hutool.core.collection.CollectionUtil;
import org.redisson.api.RBucket;
import org.redisson.api.RList;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.Codec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.convert.ApplicationConversionService;
import org.springframework.core.convert.support.ConfigurableConversionService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Component
public class RedisService {

    private static final Logger logger = LoggerFactory.getLogger(RedisService.class);

    @Resource
    RedissonClient redisson;

    static volatile ConfigurableConversionService conversionService;

    static {
        conversionService = (ConfigurableConversionService) ApplicationConversionService.getSharedInstance();
    }

    public boolean tryLock(String key){
        RLock lock = this.redisson.getLock(key);
        try {
            if (null != lock){
                return lock.tryLock(3, 60, TimeUnit.SECONDS);
            }
        }catch (InterruptedException ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean unLock(String key){
        RLock lock = this.redisson.getLock(key);
        try {
            lock.unlock();
            return true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    /**
     * 获取key->value
     * @param key
     * @param targetType
     * @return
             */
    public <V> V get(String key,Class<V> targetType){
        RBucket<V> bucket = redisson.getBucket(key);
        return this.convertValueIfNecessary(bucket.get(), targetType);
    }

    public <V> V get(String key, Class<V> targetType, Codec codec){
        RBucket<V> bucket = this.redisson.getBucket(key, codec);
        return this.convertValueIfNecessary(bucket.get(), targetType);
    }


    public <V> List<V> getList(String key, Class<V> targetType, Codec codec) {
        List<V> result = new ArrayList<>();
        RList<Object> list = this.redisson.getList(key, codec);
        if (CollectionUtil.isNotEmpty(list)){
            for (Object o : list) {
                result.add(this.convertValueIfNecessary(o, targetType));
            }
        }
        return result;
    }

    /**
     *
     * @param key
     * @param value
     */
    public <V> void set(String key, V value) {
        RBucket<V> bucket = redisson.getBucket(key);
        bucket.set(value);
    }

    public <V> void set(String key, V value, Codec codec){
        RBucket<V> bucket = this.redisson.getBucket(key, codec);
        bucket.set(value);
    }

    private  <V> V convertValueIfNecessary(Object value, Class<V> targetType) {
        if (targetType != null) {
            return conversionService.convert(value, targetType);
        }
        return null;
    }



}
