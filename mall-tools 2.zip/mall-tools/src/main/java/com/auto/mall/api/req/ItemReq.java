package com.auto.mall.api.req;

import lombok.Data;

import java.io.Serializable;

@Data
public class ItemReq implements Serializable {
    private static final long serialVersionUID = -4900213401019956641L;

    private String itemId;
    private String skuId;

    private Integer count;

}
