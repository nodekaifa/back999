package com.auto.mall.api.req;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.Data;

import java.io.Serializable;

@Data
public class PageReq<T> implements Serializable {

    protected int pageNo;
    protected int pageSize;
    protected T parameter;
    protected String[] orders;

    public PageReq(){
        this.pageNo = 1;
        this.pageSize = 10;
    }

    public Page getPage(){
        return new Page<>(this.pageNo,this.pageSize);
    }
}
