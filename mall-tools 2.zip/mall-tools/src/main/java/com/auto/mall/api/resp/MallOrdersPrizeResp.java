package com.auto.mall.api.resp;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class MallOrdersPrizeResp implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;

    private String partyId;

    /**
     * 店家ID
     */
    private String sellerId;

    /**
     * 店家名称
     */
    private String sellerName;


    /**
     * 订单创建时间
     */
    private LocalDateTime createTime;


    /**
     * 地址
     */
    private String address;

    /**
     * 联系人
     */
    private String contacts;



}