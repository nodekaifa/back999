package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@TableName("T_MALL_ORDER_RECORD")
public class OrderRecord implements Serializable {
    private static final long serialVersionUID = -5838213798609801171L;
    @TableId(value = "uuid", type = IdType.UUID)
    private String id;

    @JsonProperty("startTime")
    @TableField(value = "start_time")
    private Date start_time;

    @JsonProperty("endTime")
    @TableField(value = "end_time")
    private Date end_time;

    @JsonProperty("orderSpacingStart")
    @TableField(value = "order_spacing_start")
    private Integer order_spacing_start;

    @JsonProperty("orderSpacingEnd")
    @TableField(value = "order_spacing_end")
    private Integer order_spacing_end;

    @JsonProperty("buyNumStart")
    @TableField(value = "buy_num_start")
    private Integer buy_num_start;

    @TableField(value = "buy_num_end")
    @JsonProperty("buyNumEnd")
    private Integer buy_num_end;
    @TableField(value = "buy_amount_start")
    @JsonProperty("buyAmountStart")
    private BigDecimal buy_amount_start;
    @TableField(value = "buy_amount_end")
    @JsonProperty("buyAmountEnd")
    private BigDecimal buy_amount_end;

    /**
     * 订单总金额
     */
    @TableField(value = "lump_amount")
    @JsonProperty("lumpAmount")
    private BigDecimal lump_amount;

    /**
     * 已经下单数量
     */
    @TableField(value = "ordered_num")
    @JsonProperty("orderedNum")
    private Integer order_num;

    @TableField(value = "CREATE_TIME")
    private Date createTime;

    /**
     * 总订单量
     */
    @TableField(value = "order_num_all")
    @JsonProperty("orderNumAll")
    private Integer orderNumAll;

    /**
     * 下单金额
     */
    @JsonProperty("orderAmount")
    @TableField(value = "order_amount")
    private BigDecimal order_amount;

    @TableField(value = "seller_goods_id")
    @JsonIgnore
    private String seller_goods_id;

    @TableField(value = "status")
    private Integer status;

    /**
     * 当前已经返回的订单id,用,拼接
     */
    @TableField(value = "ORDER_IDS")
    private String orderIds;

    // 任务类型,single单笔，batch批量
    @TableField(value = "type")
    private String type;

    @TableField(value = "CREATE_USER")
    private String createUser;

    public Integer getOrder_num() {
        return null == order_num ? 0 : order_num;
    }

    public BigDecimal getOrder_amount() {
        return null == order_amount ? new BigDecimal(0.0) : order_amount;
    }
}
