package com.auto.mall.task;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.auto.mall.api.req.PageReq;
import com.auto.mall.dto.LocalOrderResult;
import com.auto.mall.mapper.OrderTaskMapper;
import com.auto.mall.mapper.SellerGoodMapper;
import com.auto.mall.model.OrderRecord;
import com.auto.mall.model.OrderRecordDetail;
import com.auto.mall.model.OrderTask;
import com.auto.mall.model.SellerGoods;
import com.auto.mall.service.OrderRecordDetailService;
import com.auto.mall.service.OrderRecordService;
import com.auto.mall.utils.StringUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;


@Component
public class PosOrderTask {
    private static final Logger LOGGER = LoggerFactory.getLogger(PosOrderTask.class);
    @Resource
    private OrderTaskMapper orderTaskMapper;

    @Resource
    private OrderRecordService orderRecordService;

    @Resource
    private OrderRecordDetailService recordDetailService;

    @Resource
    private SellerGoodMapper sellerGoodMapper;

    @Value("${mall.order.api}")
    private String api;

    @Scheduled(cron = "0/9 * * * * ? ")
    @Transactional
    public void posOrders() {
        try {
            PageReq<OrderTask> page = new PageReq<>();

            page.setPageNo(0);
            page.setPageSize(20);
            List<OrderTask> orderTasks = orderTaskMapper.findOrderTaskByDelayAndStatusPage(page, new Date(), 0);
            for (OrderTask orderTask : orderTasks) {
                String partyId = orderTask.getPartyId();
                String uuid = orderTask.getGoodInfo();
                String[] split1 = uuid.split(",");
                String goodsId = split1[0];
                SellerGoods sellerGoods = sellerGoodMapper.selectOne(new LambdaQueryWrapper<SellerGoods>().eq(SellerGoods::getId, goodsId).eq(SellerGoods::getIsValid, 1).eq(SellerGoods::getIsShelf, 1));
                if (sellerGoods == null) {
                    LOGGER.info("商品已下架或已删除：goodsId {} ", goodsId);
                    //更新任务
                    orderTask.setStatus(2);
                    orderTaskMapper.updateById(orderTask);
                    continue;
                }
                int count = orderTask.getCount();
                String orderId = orderTask.getOrderId();
                BigDecimal amount = orderTask.getAmount();
                String sellerId = orderTask.getSellerId();

                try {
                    String value = HttpUtil.post(api + "?partyId=" + partyId + "&uuid=" + uuid + "&num=" + count, "", 60000);
                    LOGGER.info("execute batch order:[orderId=>{}, partyId=>{},uuid=>{}, count=>{}, amount=>{}], response:[{}]", orderId,
                            partyId, uuid, count, amount, value);
                    // 从orderList里提取orderId
                    JSONObject object = JSONUtil.parseObj(value);
                    JSONObject data = JSONUtil.parseObj(object.get("data"));
                    LOGGER.info("execute batch response: " + data.toString());
                    List<LocalOrderResult> orderList = data.getBeanList("orderList", LocalOrderResult.class);
                    // 成功下的订单数量
                    Set<String> orderSuccess = orderList.stream()
                            .filter(o -> o != null && StringUtils.isNotEmpty(o.getOrderId()))
                            .map(LocalOrderResult::getOrderId)
                            .collect(Collectors.toSet());
                    String[] split = split1;
                    this.orderRecordService.updateItem(orderId, uuid, count, amount, orderSuccess);
                    if (CollectionUtil.isNotEmpty(orderSuccess)) {
                        for (String success : orderSuccess) {
                            OrderRecordDetail detail = new OrderRecordDetail(orderId,
                                    success, partyId, amount, sellerId, split[0], split[1], count);
                            this.recordDetailService.save(detail);
                        }
                        //更新任务
                        orderTask.setStatus(1);
                        orderTaskMapper.updateById(orderTask);
                    }
                } catch (Exception e) {
                    LOGGER.error("pos下单失败", e);
                }
            }
        } catch (Exception e) {
            LOGGER.error("pos下单异常", e);
        }
    }

    /**
     * 每分钟执行一次跟新批量订单状态
     */
    @Scheduled(cron = "0 0/1 * * * ? ")
    @Transactional
    public void updateOrderStatus() {
        try {
            Page<OrderRecord> page = new Page<>();
            page.setSize(20);
            page.setCurrent(0);
            IPage<OrderRecord> batch = orderRecordService.getBaseMapper().selectPage(page, new LambdaQueryWrapper<OrderRecord>().eq(OrderRecord::getStatus, 1).eq(OrderRecord::getType, "batch"));
            List<OrderRecord> records = batch.getRecords();

            Page<OrderTask> page2 = new Page<>();
            page.setSize(20);
            page.setCurrent(0);
            for (OrderRecord record : records) {
                IPage<OrderTask> orderTaskIPage = orderTaskMapper.selectPage(page2, new LambdaQueryWrapper<OrderTask>().eq(OrderTask::getOrderId, record.getId()).eq(OrderTask::getStatus, 0));
                if (CollectionUtils.isEmpty(orderTaskIPage.getRecords())) {
                    record.setStatus(2);
                    orderRecordService.getBaseMapper().updateById(record);
                }
            }
        } catch (Exception e) {
            LOGGER.error("更新批量任务状态异常", e);
        }
    }

    /**
     * 每分钟执行一次跟新批量订单状态
     */
    @Scheduled(cron = "0 0 2 ? * Fri")
    @Transactional
    public void deleteOrderTask() {
        try {
            LocalDateTime dateTime = LocalDateTime.now().minusWeeks(1);
            orderTaskMapper.delete(new LambdaQueryWrapper<OrderTask>().le(OrderTask::getDelay, dateTime).ne(OrderTask::getStatus, 0));
        } catch (Exception e) {
            LOGGER.error("批量删除任务状态异常", e);
        }
    }
}
