package com.auto.mall.api.req;

import lombok.Data;

import java.io.Serializable;

@Data
public class CommentReq implements Serializable {
    private static final long serialVersionUID = 4116655160304145142L;
    private String username;

    private String date;

    private String content;

    public CommentReq(){

    }
}
