package com.auto.mall.service;

import com.auto.mall.mapper.MallOrdersPrizeMapper;
import com.auto.mall.model.MallOrdersPrize;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 订单价格表 服务实现类
 * </p>
 *
 * @author lucas
 * @since 2023-01-08
 */
@Service
public class MallOrdersPrizeService extends ServiceImpl<MallOrdersPrizeMapper, MallOrdersPrize> {

}
