package com.auto.mall.api.resp;

import lombok.Data;

import java.math.BigDecimal;


@Data
public class SellerGoodsResp {

    //商品ID
    private String goodsId;

    //店铺ID
    private String sellerId;

    //店铺商品ID
    private String sellerGoodsId;

    //封面图
    private String imgUrl;

    //商品价格
    private BigDecimal sellingPrice;

    //商品名称
    private String goodsName;
}