package com.auto.mall.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserRecomResult implements Serializable {

    private String id;

    private String reco_id;

    private String partyId;
}
