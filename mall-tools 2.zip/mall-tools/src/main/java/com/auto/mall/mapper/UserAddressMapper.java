package com.auto.mall.mapper;

import com.auto.mall.model.UserAddress;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface UserAddressMapper extends BaseMapper<UserAddress> {
}