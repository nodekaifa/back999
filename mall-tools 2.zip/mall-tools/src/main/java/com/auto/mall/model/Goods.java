package com.auto.mall.model;

import cn.hutool.core.collection.CollectionUtil;
import com.auto.mall.api.req.GoodsReq;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@TableName("T_MALL_SYSTEM_GOODS")
public class Goods implements Serializable {
    private static final long serialVersionUID = 4123602918171610611L;

    @TableId(value = "uuid", type = IdType.UUID)
    private String id;

    @TableField(value = "link")
    private String link;

    @TableField(value = "system_price")
    private BigDecimal systemPrice;

    @TableField(value = "category_id")
    private String categoryId;

    @TableField(value = "is_shelf")
    private Integer isShelf = 1;

    @TableField(value = "create_time")
    private Date createTime;

    @TableField(value = "up_time")
    private long upTime;

    @TableField(value = "freight_amount")
    private Double freightAmount = 0.0;

    @TableField(value = "img_url_1")
    private String img_url_1;

    @TableField(value = "img_url_2")
    private String img_url_2;

    @TableField(value = "img_url_3")
    private String img_url_3;

    @TableField(value = "img_url_4")
    private String img_url_4;

    @TableField(value = "img_url_5")
    private String img_url_5;

    @TableField(value = "img_url_6")
    private String img_url_6;

    @TableField(value = "img_url_7")
    private String img_url_7;

    @TableField(value = "img_url_8")
    private String img_url_8;

    @TableField(value = "img_url_9")
    private String img_url_9;

    @TableField(value = "img_url_10")
    private String img_url_10;

    public Goods(){

    }

    public Goods(GoodsReq req) {
        this.link = req.getLink();
        this.categoryId = req.getCategory();
        String price = req.getPrice();
        if (null != price && !price.equals("null")){
            BigDecimal decimal = new BigDecimal(price.replaceAll("\\$|\\¥", ""));
            BigDecimal multiply = decimal.multiply(new BigDecimal("0.9"));
            this.systemPrice = multiply;
        }else {
            this.systemPrice = new BigDecimal("0.00");
        }
        this.createTime = new Date();
        this.upTime = System.currentTimeMillis();
        List<String> img = req.getImg();
        this.img_url_1 = this.img(img, 0);
        this.img_url_2 = this.img(img, 1);
        this.img_url_3 = this.img(img, 2);
        this.img_url_4 = this.img(img, 3);
        this.img_url_5 = this.img(img, 4);
        this.img_url_6 = this.img(img, 5);
        this.img_url_7 = this.img(img, 6);
        this.img_url_8 = this.img(img, 7);
        this.img_url_9 = this.img(img, 8);
        this.img_url_10 = this.img(img, 9);
    }

    private String img(List<String> album, int index){
        if (CollectionUtil.isNotEmpty(album)){
            int length = album.size();
            if (index > length -1){
                return "";
            }else {
                return album.get(index);
            }
        }
        return "";
    }

}
