package com.auto.mall.service;


import cn.hutool.core.util.StrUtil;
import com.auto.mall.api.req.PromoteReq;
import com.auto.mall.api.resp.PromoteResp;
import com.auto.mall.exception.MallToolGlobalException;
import com.auto.mall.service.redis.RedisService;
import com.auto.mall.service.support.OrderItemBuilder;
import com.auto.mall.utils.RedisKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
public class PromoteService {


    private static final Logger logger = LoggerFactory.getLogger(PromoteService.class);

    @Resource
    RedisService redisService;

    @Resource
    UserRecomService userRecomService;

    @Resource
    MallOrderPrizeService mallOrderPrizeService;

    @Transactional(readOnly = true)
    public List<PromoteResp> list(PromoteReq req) {
        String token = req.getToken();
        if (StrUtil.isBlank(token)) {
            throw new MallToolGlobalException(403, "登录已过期");
        }

        String partyId = token.length() > 36
                ? this.redisService.get(RedisKey.PLAT_FROM_TOKEN + token, String.class)
                : this.redisService.get(RedisKey.TOKEN + token, String.class);

        if (StrUtil.isBlank(partyId)) {
            throw new MallToolGlobalException(403, "登录已过期");
        }
        req.setPartyId(partyId);
        return this.userRecomService.findChildPromote(req);
    }


    public List<String> distribution(String orderId) {
        return this.mallOrderPrizeService.distribution(orderId);
    }
}
