package com.auto.mall.mapper;

import com.auto.mall.model.MallOrdersPrize;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 订单价格表 Mapper 接口
 * </p>
 *
 * @author lucas
 * @since 2023-01-08
 */
public interface MallOrdersPrizeMapper extends BaseMapper<MallOrdersPrize> {

}
