package com.auto.mall.mapper;

import com.auto.mall.model.SellerGoods;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface SellerGoodMapper extends BaseMapper<SellerGoods> {
}
