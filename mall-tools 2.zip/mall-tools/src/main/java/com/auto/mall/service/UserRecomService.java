package com.auto.mall.service;

import cn.hutool.core.collection.CollectionUtil;
import com.auto.mall.api.req.PromoteReq;
import com.auto.mall.api.resp.PromoteResp;
import com.auto.mall.dto.MallRebateDto;
import com.auto.mall.mapper.MallRebateMapper;
import com.auto.mall.mapper.UserRecomMapper;
import com.auto.mall.model.UserRecom;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Service
public class UserRecomService extends ServiceImpl<UserRecomMapper, UserRecom> {

    @Resource
    MallRebateMapper rebateMapper;

    @Transactional(readOnly = true)
    public List<PromoteResp> findChildPromote(PromoteReq req) {
        List<String> children = this.findChildParty(req);
        if (CollectionUtil.isNotEmpty(children)) {
            List<PromoteResp> promotes = this.getBaseMapper().selectPromoteList(req.getPage(),children);
            if (CollectionUtil.isNotEmpty(promotes)) {
                promotes.forEach(e -> {
                    MallRebateDto rebate = this.rebateMapper.selectOrderRebate(e.getUuid(), req.getPartyId());
                    if (null != rebate) {
                        e.setOrderCount(rebate.getOrderCount());
                        e.setIncome(rebate.getIncome());
                    }
                });
            }
            return promotes;
        }
        return null;
    }
    @Transactional(readOnly = true)
    public Map<Integer, String> findParents(String sellerId) {
        Map<Integer, String> map = new HashMap<>();
        int level = 1;
        while (null != sellerId && level <= 3) {
            sellerId = this.recursion(sellerId);
            if (null != sellerId) {
                map.put(level, sellerId);
            }
            level++;
        }
        return map;
    }


    public List<String> findChildParty(PromoteReq req) {
        List<String> parents = new ArrayList<>();
        parents.add(req.getPartyId());
        int level = req.getLevel();
        while (level >= 1) {
            parents = this.recursion(parents);
            level--;
        }
        return parents;
    }

    private List<String> recursion(List<String> parent) {
        if (CollectionUtil.isNotEmpty(parent)) {
            QueryWrapper<UserRecom> wrapper = new QueryWrapper<>();
            wrapper.in("RECO_ID", parent);
            List<UserRecom> records  = this.getBaseMapper().selectList(wrapper);
            if (CollectionUtil.isNotEmpty(records)) {
                return records.stream().map(UserRecom::getPartyId).collect(Collectors.toList());
            }
        }
        return new ArrayList<>();
    }

    private String recursion(String child) {
        QueryWrapper<UserRecom> wrapper = new QueryWrapper<>();
        wrapper.eq("party_id", child);
        UserRecom userRecom = this.getBaseMapper().selectOne(wrapper);
        return null == userRecom ? null : userRecom.getRecoId();
    }


}
