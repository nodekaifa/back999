package com.auto.mall.api.req;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class OrderCancelBatchReq implements Serializable {

    private String secret;

    private List<String> orderIds;
}
