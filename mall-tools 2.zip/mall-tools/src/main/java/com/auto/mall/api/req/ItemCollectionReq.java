package com.auto.mall.api.req;

import lombok.Data;

import java.io.Serializable;


@Data
public class ItemCollectionReq implements Serializable {
    private static final long serialVersionUID = -4291495858496158982L;

    private String url;

    private String category;

    public ItemCollectionReq(){
    }

    public ItemCollectionReq(String url, String category){
        this.url = url;
        this.category = category;
    }

}
