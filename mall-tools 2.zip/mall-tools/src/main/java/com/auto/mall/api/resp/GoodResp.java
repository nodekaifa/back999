package com.auto.mall.api.resp;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class GoodResp implements Serializable {
    private static final long serialVersionUID = 5606408312857797609L;

    private String uuid;
    private String skuId;
    private String sellerId;
    private Integer sold_num;
    private Integer view_num;
    private BigDecimal discountPrice;
    private BigDecimal sellingPrice;
    private Date discountStartTime;
    private Date discountEndTime;

}
