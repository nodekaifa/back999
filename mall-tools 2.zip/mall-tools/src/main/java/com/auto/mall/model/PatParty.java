package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;


@Data
@TableName("PAT_PARTY")
public class PatParty implements Serializable {

    @TableId(value = "UUID")
    private String uuid;

    @TableField(value = "USERNAME")
    private String username;

    @TableField(value = "ROLENAME")
    private String roleName;

}
