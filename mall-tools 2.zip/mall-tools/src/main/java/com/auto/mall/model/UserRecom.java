package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

@Data
@TableName("PAT_USER_RECOM")
public class UserRecom implements Serializable {
    private static final long serialVersionUID = 2418749548542538512L;

    @TableId(value = "uuid")
    private String uuid;

    @TableField(value = "party_id")
    private String partyId;

    @TableField(value = "reco_id")
    private String recoId;

}
