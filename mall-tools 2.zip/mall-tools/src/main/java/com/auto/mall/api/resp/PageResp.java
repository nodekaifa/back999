package com.auto.mall.api.resp;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class PageResp<T> implements Serializable {

    private static final long serialVersionUID = 504701959298347730L;
    private int pageNo;
    private int pageSize;
    private int totalPage;
    private int totalCount;
    private boolean hasNext;
    private List<T> records;

    public PageResp(){}

    public PageResp(int pageNo,int pageSize,int totalPage,int totalCount,List<T> records){
        this.pageNo = pageNo;
        this.pageSize = pageSize;
        this.totalPage = totalPage;
        this.totalCount = totalCount;
        this.records = records;
        this.hasNext = this.pageNo < this.totalPage;
    }

    public PageResp(Page page,List<T> records){
        this.pageNo = (int)page.getCurrent();
        this.pageSize = (int) page.getSize();
        this.totalPage = (int) page.getPages();
        this.totalCount = (int) page.getTotal();
        this.hasNext = this.pageNo < this.totalPage;
        this.records = records;
    }

    public void setPage(Page page){
        this.pageNo = (int)page.getCurrent();
        this.pageSize = (int) page.getSize();
        this.totalPage = (int) page.getPages();
        this.totalCount = (int) page.getTotal();
        this.hasNext = this.pageNo < this.totalPage;
    }

    @JsonIgnore
    public PageResp<T> getPage(){
        return new PageResp<>(this.pageNo,this.pageSize,this.totalPage,this.totalCount,null);
    }

}
