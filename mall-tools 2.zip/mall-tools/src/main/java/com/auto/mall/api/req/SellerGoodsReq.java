package com.auto.mall.api.req;

import com.auto.mall.vo.PageVo;
import lombok.Data;

import java.io.Serializable;
import java.util.List;


@Data
public class SellerGoodsReq extends PageReq  {

    private static final long serialVersionUID = 1923654772813254748L;
    //商品名称
    private String goodsName;

    //商品Id
    private String sellerId;

    //商家用户id
    private String userCode;

    // 一级分类Id
    private String categoryId;

    // 二级分类，可能为空
    private String secondaryCategoryId;

    private String loginPartyId;

    private List<String> children;

}