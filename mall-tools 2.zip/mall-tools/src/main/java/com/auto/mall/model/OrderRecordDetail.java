package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@TableName("T_MALL_ORDER_RECORD_DETAIL")
public class OrderRecordDetail implements Serializable {

    @TableId(value = "UUID", type = IdType.UUID)
    private String id;

    @TableField(value = "RECORD_ID")
    private String recordId;

    @TableField(value = "SELLER_ID")
    private String sellerId;

    @TableField(value = "ORDER_ID")
    private String orderId;

    @TableField(value = "USER_ID")
    private String userId;

    @TableField("ORDER_AMOUNT")
    private BigDecimal orderAmount;

    @TableField("SELLER_GOODS_ID")
    private String sellerGoodsId;

    @TableField("SKU_ID")
    private String skuId;

    @TableField("CREATE_TIME")
    private Date createTime;

    @TableField("NUM")
    private Integer num;

    public OrderRecordDetail(){}

    public OrderRecordDetail(String recordId, String orderId, String userId, BigDecimal orderAmount,
                              String sellerId, String sellerGoodsId, String skuId, Integer num){
        this.recordId = recordId;
        this.orderId = orderId;
        this.userId = userId;
        this.sellerId = sellerId;
        this.orderAmount = orderAmount;
        this.sellerGoodsId = sellerGoodsId;
        this.skuId = skuId;
        this.num = num;
        this.createTime = new Date();
    }

}
