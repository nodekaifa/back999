package com.auto.mall.mapper;

import com.auto.mall.api.req.PageReq;
import com.auto.mall.model.OrderTask;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface OrderTaskMapper extends BaseMapper<OrderTask> {
    /**
     * 根据时间、状态查询订单
     *
     * @param status 订单状态
     * @param date   订单状态
     * @return 订单集合
     */
    List<OrderTask> findOrderTaskByDelayAndStatusPage(@Param(value = "page") PageReq<OrderTask> page, @Param(value = "date") Date date, @Param(value = "status") int status);
}
