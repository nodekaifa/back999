package com.auto.mall.mapper;

import com.auto.mall.model.OrderRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface OrderRecordMapper extends BaseMapper<OrderRecord> {
}
