package com.auto.mall.dto;

import lombok.Data;

/**
 * local下单data返回对象list
 */
@Data
public class LocalOrderResult {
    private String orderId;
    private String prizeReal;
    private String fees;
    private String tax;

}
