package com.auto.mall.api.req;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class OrderReq implements Serializable {
    private static final long serialVersionUID = 573145816239266985L;

    private String secret;

    private String partyId;

    private List<ItemReq> items;
    /**
     * 操作人名称
     */
    private String createUser;
}
