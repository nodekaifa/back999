package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;


@Data
@TableName("T_MALL_SELLER_GOODS")
public class SellerGoods implements Serializable {
    private static final long serialVersionUID = -5319590836180705807L;

    @TableId(value = "uuid", type = IdType.UUID)
    private String id;

    @TableField(value = "seller_id")
    private String sellerId;

    @TableField(value = "category_id")
    private String categoryId;

    @TableField(value = "secondary_category_id")
    private String secondaryCategoryId;

    @TableField(value = "goods_id")
    private String goodId;

    @TableField(value = "views_num")
    private Integer viewNum;

    @TableField(value = "selling_price")
    private BigDecimal sellingPrice;

    //	@ApiModelProperty(value = "是否上架（1上架 0不上架）")
    @TableField(value = "is_shelf")
    private Integer isShelf;

    // 是否删删除 (有效1(未删除)  无效0(删除))
    @TableField(value ="is_valid" )
    private int isValid;


}
