package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@TableName("T_MALL_ORDER_TASK")
public class OrderTask implements Serializable {
    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**
     * 订单编号
     */
    @TableField(value = "order_id")
    private String orderId;
    /**
     * 执行时间
     */
    @TableField(value = "delay")
    private Date delay;
    /**
     * 买家ID
     */
    @TableField(value = "party_id")
    private String partyId;

    /**
     * 店铺商品id + skuId
     */
    @TableField(value = "good_info")
    private String goodInfo;

    /**
     * 商家店铺id
     */
    @TableField(value = "seller_id")
    private String sellerId;
    /**
     * 商品数量
     */
    @TableField(value = "count")
    private int count;
    /**
     * 订单金额
     */
    @TableField(value = "amount")
    private BigDecimal amount;
    /**
     * 订单状态：0-未执行，1-已执行, 2-已执行但商品已下架
     */
    @TableField(value = "status")
    private int status;
}
