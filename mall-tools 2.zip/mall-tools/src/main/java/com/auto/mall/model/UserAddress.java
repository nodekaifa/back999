package com.auto.mall.model;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Date;

@Data
@TableName("T_MALL_USERADDRESS")
public class UserAddress {

    @TableId(value = "UUID", type = IdType.UUID)
    private String id;

    @TableField(value = "PARTY_ID")
    private String partyId;

    @TableField(value = "STATUS")
    private Integer status;

    @TableField(value = "PHONE")
    private String phone;

    @TableField(value = "EMAIL")
    private String email;

    @TableField(value = "CONTACTS")
    private String contacts;

    @TableField(value = "POSTCODE")
    private String postCode;

    @TableField(value = "COUNTRY")
    private String country;

    @TableField(value = "PROVINCE")
    private String province;

    @TableField(value = "CITY")
    private String city;

    @TableField(value = "ADDRESS")
    private String address;

    @TableField(value = "CREATE_TIME")
    private Date createTime;


}