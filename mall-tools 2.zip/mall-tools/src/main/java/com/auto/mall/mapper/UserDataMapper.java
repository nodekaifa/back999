package com.auto.mall.mapper;

import com.auto.mall.model.UserData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface UserDataMapper extends BaseMapper<UserData> {
}
