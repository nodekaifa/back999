package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * <p>
 * 订单价格表
 * </p>
 *
 * @author lucas
 * @since 2023-01-08
 */
@Data
@TableName("T_MALL_ORDERS_PRIZE")
public class MallOrdersPrize implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId("UUID")
    private String id;

    @TableField("PARTY_ID")
    private String partyId;

    /**
     * 用户code
     */
    @TableField("USER_CODE")
    private String userCode;

    /**
     * 店家ID
     */
    @TableField("SELLER_ID")
    private String sellerId;

    /**
     * 商家售卖价格
     */
    @TableField("PRIZE_ORIGINAL")
    private Object prizeOriginal;

    /**
     * 店家名称
     */
    @TableField("SELLER_NAME")
    private String sellerName;

    /**
     * 商品个数
     */
    @TableField("GOODS__COUNT")
    private Integer goodsCount;

    /**
     * 商家折扣价
     */
    @TableField("PRIZE_REAL")
    private Object prizeReal;

    /**
     * 进货价
     */
    @TableField("SYSTEM_PRICE")
    private Object systemPrice;

    /**
     * 状态（-1=已取消）（0=待付款）（1=待发货）（2=已确认）（3=待收货）（4=已收获）（5=已评价）（6=退款)
     */
    @TableField("STATUS")
    private Integer status;

    /**
     * 退货状态（0=未退款）（1=退款中）（2=退款成功）（3=退款失败）
     */
    @TableField("RETURN_STATUS")
    private Integer returnStatus;

    /**
     * 订单状态 （0 = 真实订单）（1=虚拟订单）
     */
    @TableField("ORDER_STATUS")
    private Integer orderStatus;

    /**
     * 运费
     */
    @TableField("FEES")
    private Object fees;

    /**
     * 税收
     */
    @TableField("TAX")
    private Object tax;

    /**
     * 利润
     */
    @TableField("PROFIT")
    private Object profit;

    /**
     * 支付状态（0-未支付，1-已支付）
     */
    @TableField("PAY_STATUS")
    private Integer payStatus;

    /**
     * 状态改变时间
     */
    @TableField("UP_TIME")
    private Long upTime;

    /**
     * 订单创建时间
     */
    @TableField("CREATE_TIME")
    private Date createTime;

    /**
     * 手机号
     */
    @TableField("PHONE")
    private String phone;

    /**
     * 邮箱
     */
    @TableField("EMAIL")
    private String email;

    /**
     * 联系人
     */
    @TableField("CONTACTS")
    private String contacts;

    /**
     * 邮编
     */
    @TableField("POSTCODE")
    private String postcode;

    /**
     * 国家
     */
    @TableField("COUNTRY")
    private String country;

    /**
     * 州/省
     */
    @TableField("PROVINCE")
    private String province;

    /**
     * 市
     */
    @TableField("CITY")
    private String city;

    /**
     * 地址
     */
    @TableField("ADDRESS")
    private String address;

    /**
     * 佣金状态 0-未发放，1-发放
     */
    @TableField("PROFIT_STATUS")
    private Integer profitStatus;

    /**
     * 商家采购状态 0-未采购，1已经采购
     */
    @TableField("PURCH_STATUS")
    private Integer purchStatus;



    /**
     * 退款拒绝备注
     */
    @TableField("REFUND_REMARK")
    private String refundRemark;

    /**
     * 退款理由
     */
    @TableField("RETURN_REASON")
    private String returnReason;

    /**
     * 退款说明
     */
    @TableField("RETURN_DETAIL")
    private String returnDetail;
}
