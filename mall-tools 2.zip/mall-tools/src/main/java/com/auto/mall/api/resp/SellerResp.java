package com.auto.mall.api.resp;

import lombok.Data;

@Data
public class SellerResp {

    //商店ID
    private String sellerId;

    //商店名称
    private String sellerName;
}