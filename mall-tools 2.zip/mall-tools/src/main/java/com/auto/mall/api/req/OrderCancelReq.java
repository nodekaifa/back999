package com.auto.mall.api.req;

import lombok.Data;

import java.io.Serializable;

@Data
public class OrderCancelReq implements Serializable {

    private String secret;

    private String orderId;
}
