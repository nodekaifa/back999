package com.auto.mall.api.req;

import com.auto.mall.model.OrderRecord;
import lombok.Data;

@Data
public class OrderRecordReq extends  PageReq<OrderRecord>{
    private String id;
    /**
     * 状态，1-进行中，2-系统结束，3-异常中断，4-已暂停，5-人工结束
     */
    private String status;
    private String startTime;
    private  String endTime;
    private String lang;
}
