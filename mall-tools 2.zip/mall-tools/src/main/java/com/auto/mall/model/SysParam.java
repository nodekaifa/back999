package com.auto.mall.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;


@Data
@TableName("T_SYSPARA")
public class SysParam implements Serializable {
    private static final long serialVersionUID = -7160285606866396828L;

    @TableId(value = "uuid")
    private String uuid;

    @TableField(value = "code")
    private String code;

    @TableField(value = "party_id")
    private String partyId;

    @TableField(value = "svalue")
    private String value;
}
