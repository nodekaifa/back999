import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueJsx from "@vitejs/plugin-vue-jsx";
import { vanillaExtractPlugin } from '@vanilla-extract/vite-plugin';
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'
import svgLoader from 'vite-svg-loader'
const resolve = (dir: string) => new URL(dir, import.meta.url).pathname;
import legacy from '@vitejs/plugin-legacy'

// https://vitejs.dev/config/
export default defineConfig({

  base: process.env.NODE_ENV === "development" ? "/" : "/chat/", // 默认 '/'
  build: {
    outDir: 'chat', // 默认是 'dist'  
  },

  plugins: [
    vue(),
    vueJsx(),
    vanillaExtractPlugin(),
    AutoImport({
      resolvers: [ElementPlusResolver()],
    },),
    svgLoader({ defaultImport: 'component', svgo: false, }),
    Components({
      resolvers: [ElementPlusResolver(),],
    }),
    legacy({
      targets: ['chrome 52'],
      additionalLegacyPolyfills: ['regenerator-runtime/runtime'],
      renderLegacyChunks: true,
      polyfills: [
        'es.symbol',
        'es.array.filter',
        'es.promise',
        'es.promise.finally',
        'es/map',
        'es/set',
        'es.array.for-each',
        'es.object.define-properties',
        'es.object.define-property',
        'es.object.get-own-property-descriptor',
        'es.object.get-own-property-descriptors',
        'es.object.keys',
        'es.object.to-string',
        'web.dom-collections.for-each',
        'esnext.global-this',
        'esnext.string.match-all'
      ]
    })
  ],
  resolve: {
    alias: {
      '@/': resolve('./src/')
    }
  },
  server: {
    port: 3000,
    open: true,
    host: '0.0.0.0',
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
    proxy: {
      "/wap": {
        secure: false,
        target: "https://thsjbvh.site/",
        changeOrigin: true,
      },

    }
  },

})
