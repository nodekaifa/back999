const formeateUser = (name) => {


    if (/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(name)) {
        const split = name.split('@');
        console.log(split[1]);
        // return `${headEnv.title} ***@${split[1]} `
    } else if (/^-?\d+$/.test(name) && name.length > 3) {
        return `${headEnv.title}  ${name.substring(0, 3)}***${name.substring(3, name.length - 1)}`
    }

    console.log(name)
    // return name
}

formeateUser('magio.add@gg.com')