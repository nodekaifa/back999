import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { createApp } from 'vue'
import App from './App.vue'
import './css/app.css'
import { router } from './router'
import { createPinia } from 'pinia'
import 'element-plus/dist/index.css'
import dayjs from 'dayjs';
// import { isYesterday } from './utils/imDate';
import isYesterday from 'dayjs/plugin/isYesterday';
import isToday from 'dayjs/plugin/isToday';


dayjs.extend(timezone)
dayjs.extend(utc)
dayjs.extend(isYesterday)
dayjs.extend(isToday)
dayjs.tz.setDefault(dayjs.tz.guess());
// console.log('---------timzone----------', dayjs.tz.guess())
// dayjs.tz.setDefault('Asia/Shanghai')

createApp(App).use(router).use(createPinia()).mount('#app')
