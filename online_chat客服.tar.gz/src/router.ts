import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'

import PcViews from './views/pc/index'
import H5ContactsView from './views/h5/contacts'
import H5MessagesView from './views/h5/message'
import H5BackMessage from './views/h5/messagelist'
import PlateH5 from './views/h5/messagelist_back'
import { base } from './utils'
import { $t } from './utils/lang'
import { headEnv } from './utils/env'


const routes: RouteRecordRaw[] = [
    //pc 商城pc 端， 商城后台 调用的 ,
    {
        path: '/pc/:color',
        component: PcViews
    }, 
    //h5 聊天 用户列表页
    {
        path: "/h5/contacts/:color",
        component: H5ContactsView
    },
    //h5 聊天 消息列表页
    {
        path: "/h5/message/:color",
        component: H5MessagesView
    },
    //虚拟用户 调用的，管理后台 无法获取历史用户列表 使用 chatid 作为与后端请求的接口 可以发送消息
    {
        path: "/h5/backh5/:color",
        component: H5BackMessage,
    }, 
    //管理后端 获取用户与客服的聊天记录 无法发送消息的 
    {
        path: "/h5/plateh5/:color",
        component: PlateH5,
    }
]

export const router = createRouter({
    history: createWebHashHistory(base),
    routes
})

const isFirst = true;


router.beforeEach((to, from, next) => {
    if (isFirst) {
        const langType: any = to.query.lang ?? 'cn';
        sessionStorage.setItem('im_lang', langType);
        document.title = `${headEnv.title} ${$t('customService')}`
        const favicon: any = document.querySelector('link[rel="icon"]');
        //@ts-ignore
        favicon && (favicon.href = `${base}${headEnv.icon}`)
        // document.icon
    }
    next();
})