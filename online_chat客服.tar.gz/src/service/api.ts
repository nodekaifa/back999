import request from "./service"


export const sendMessageApi = ({ partyid, type = "text", content, sendType, chatId }: {
    partyid?: string,
    type: string,
    content: string,
    sendType?: string,
    chatId?: string
}) => {
    return request.get('/wap/public/userOnlineChatController!send.action', {
        params: { partyid, type, content, sendType, chatId },

    })
}


export const getUnreadMessage = () => {
    return request.get('/wap/public/userOnlineChatController!unread.action')
}

export const loadPartyMessage = (partyid = "", message_id = "") => {
    return request.get('/wap/public/userOnlineChatController!list.action', {
        params: { partyid, message_id }
    })
}

export const getContacts = () => {
    return request.get('/wap/public/userOnlineChatController!userlist.action')
}

export const uploadMessageImg = (file: File) => {
    const form = new FormData();
    const token = sessionStorage.getItem('online_im_token')
    form.append("file", file);
    token && form.append('token', token);
    form.append("moduleName", "online")
    return request.post('/wap/api/uploadimg!execute.action', form)
}

export const imageUrl = (params: any) => `/wap/public/showimg!showImg.action?${params}`;

export const getMessageByChatId = (chatid: string, messageid?: string) => {
    return request.post('/wap/public/userOnlineChatController!onechat.action', {}, { params: { chatid, messageid } })
}

export const getProductDetail = (params: any) => request.post('/wap/api/sellerGoods!info.action', params)
export const sendDfaultPartiyMessageApi = (params: any) => request.get('/wap/public/userOnlineChatController!senddefault.action', { params })

export const getBackPlateMessage = (partyId: string, messageid?: string, selectType?: string) => {
    return request.post('/wap/api/newOnlinechat!list.action', { partyId, messageid, selectType })
}