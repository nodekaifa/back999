import {useRouteParams} from "@/hooks/useRouteParams";
import {defineComponent, onMounted} from "vue";
import {contactsContainerCss} from "./css/contacts.css";
import Header from '@/components/header'
import H5Header from '@/components/H5Header'
import Users from "@/components/users";
import {useContactsStore} from "@/stores/contacts";
import langues from '@/utils/lang'

export default defineComponent({
    setup() {

        const {color, startLoop, nohead, mt, isH5, lang} = useRouteParams();
        const contactStore = useContactsStore();

        onMounted(() => {
            startLoop();
        })
        return () => <div class={contactsContainerCss}
                          style={{width: window.screen.availWidth, height: window.screen.availHeight}}>
            {!nohead && <Header background={color}/>}
            {isH5 && <H5Header/>}
            <div style={{marginTop: mt}}>
                {contactStore.selectContactId ? <Users width="100%"/> : <div style={{
                    width: '100%',
                    height: '100vh',
                    justifyContent: 'center',
                    alignItems: 'center',
                    display: 'flex'
                }}>
                    {langues[lang].noContacts}
                </div>}
            </div>
        </div>
    }
})
