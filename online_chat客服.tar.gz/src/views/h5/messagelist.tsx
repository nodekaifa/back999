import Header from "@/components/header";
import { useRouteParams } from "@/hooks/useRouteParams";
import { defineComponent, onMounted, onUnmounted, ref } from "vue";
import { contactsContainerCss } from "./css/contacts.css";
import { getMessageByChatId, sendMessageApi, uploadMessageImg } from "@/service/api";
import { boxContainerCss, contentCss } from "@/components/message.css";
import Basic from "@/components/messageItem/basic";
import { Message } from "@/hooks/useMessage";
import Sendbox from "@/components/sendbox";
import { useContactsStore } from "@/stores/contacts";
import lang, { LangType } from "@/utils/lang";
import { showMessage } from "@/utils";

export default defineComponent({
    setup() {

        const messages = ref<Message[]>([])
        const scrollRef = ref<HTMLDivElement>()
        const contactsStore = useContactsStore();
        let intervalId: any = undefined;
        let isDoing = false;

        const { color, chatid = "ff808081857758320185779a7c8b002c-ff80808185cafa7b0185cb0ca6d00009", shopName } = useRouteParams();

        const loadMessage = async (messageid?: string) => {
            if (isDoing) {
                return
            }
            isDoing = true;
            const res = await getMessageByChatId(chatid, messageid)
            if (res.data.code === '0') {
                const data = ((res.data.data || []) as Array<any>).reverse();
                if (!messageid) {
                    messages.value = data;
                    scrollToButtom();
                } else {
                    messages.value = [...data, ...messages.value!]
                }
            }
            isDoing = false
        }

        onMounted(() => {
            loadMessage();
            startLoop();
            // contactsStore.isSending = false
        })

        const scrollToButtom = () => {
            setTimeout(() => {
                scrollRef.value!.scrollTo({ top: scrollRef.value!.scrollHeight })
            })
        }

        const handleScroll = () => {
            if (scrollRef.value!.scrollTop < 10) {
                loadMessage(messages.value?.[0].message_id);
            }
        }

        const onSendTextMessage = async (content: string) => {

            contactsStore.isSending = true
            // tag.isSendMessage = true
            // cancelTimer();
            // messages.now = [...messages.now, { id: `send_no_send`, type: "text", content, send_receive: "send" }]
            // tag.scrollToBottom = true;
            // tag.hasChange = true

            await sendMessageApi({
                content,
                type: "text",
                chatId: chatid,
                sendType: 'backendSend'
            })
            // startLoopGetMessage();

            await loadMessage();
            contactsStore.isSending = false
            // if (response.data.code != '0') {
            //     showMessage(response.data.msg, 'error')
            // }
        }

        const onSendImageMessage = async (file: File) => {
            contactsStore.isSending = true
            const langType = sessionStorage.getItem('im_lang') as LangType || 'cn'
            const langInstance = lang[langType];
            showMessage(langInstance.sending, 'info', 0)
            const resp = await uploadMessageImg(file);
            if (resp.data.code == '0') {
                showMessage(langInstance.sendSuccess, 'success')
                const response = await sendMessageApi({
                    chatId: chatid,
                    content: resp.data.data,
                    type: "image",
                    sendType: 'backendSend'
                })
                if (response.data.code == '0') {
                    // startLoopGetMessage();
                }
            }
            contactsStore.isSending = false
            await loadMessage()
        }


        const startLoop = () => {
            intervalId = setInterval(async () => {
                console.log(isDoing)
                if (!isDoing) {
                    isDoing = true
                    const res = await getMessageByChatId(chatid);
                    const data = ((res.data.data || []) as Array<any>);

                    if (messages.value.length == 0 || (data.length > 0 && data[0].message_id !== messages.value[messages.value?.length - 1].message_id)) {
                        messages.value = data.reverse()
                        scrollToButtom()
                    }

                    isDoing = false
                }
            }, 5 * 1000)

        }

        onUnmounted(() => {
            clearInterval(intervalId);
        })





        return () => {

            return <div class={contactsContainerCss} style={{ position: 'relative' }}>
                <Header background={color} shopName={shopName} />
                <div class={boxContainerCss} style={{ position: 'fixed', top: '44px', height: 'calc(100% - 88px)', }}>
                    <div onScroll={handleScroll}
                        class={contentCss}
                        ref={scrollRef}
                    >
                        {messages.value?.map((it, index) => <Basic lastTime={index > 0 ? messages.value![index - 1].createtime : ""} message={it} key={it.message_id} />)}
                    </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'row', width: '100%', position: 'fixed', bottom: 0, paddingLeft: '5px', paddingRight: '6px', background: 'white' }}>
                    <Sendbox background={color} sendImage={onSendImageMessage} sendText={onSendTextMessage} />
                    <div style={{ width: '10px' }} />
                </div>
            </div>
        }
    }
})
