import Header from "@/components/header";
import { useRouteParams } from "@/hooks/useRouteParams";
import { defineComponent, onMounted, ref } from "vue";
import { contactsContainerCss } from "./css/contacts.css";
import { getBackPlateMessage, getMessageByChatId } from "@/service/api";
import { boxContainerCss, contentCss } from "@/components/message.css";
import Basic from "@/components/messageItem/basic";
import { Message } from "@/hooks/useMessage";

export default defineComponent({
    setup() {

        const messages = ref<Message[]>()
        const scrollRef = ref<HTMLDivElement>()

        const { color, partyid, height, } = useRouteParams();

        const loadMessage = async (messageid?: string) => {
            const res = await getBackPlateMessage(partyid!, messageid, 'background')
            if (res.data.code === '0') {
                const data = ((res.data.data || []) as Array<any>).reverse();
                if (!messageid) {
                    messages.value = data;
                    scrollToButtom();
                } else {
                    messages.value = [...data, ...messages.value!]
                }
            }
        }

        onMounted(() => {
            loadMessage();
        })

        const scrollToButtom = () => {
            setTimeout(() => {
                scrollRef.value!.scrollTo({ top: scrollRef.value!.scrollHeight })
            })
        }

        const handleScroll = () => {
            if (scrollRef.value!.scrollTop < 10) {
                loadMessage(messages.value?.[0].message_id);
            }
        }

        return () => {
            let mobielStyle: any = { position: 'fixed', top: '44px', height: height || `${window.screen.availHeight - 44}px` }

            return <div class={contactsContainerCss}  >
                <Header background={color} />
                <div class={boxContainerCss} style={mobielStyle}>

                    <div onScroll={handleScroll}
                        class={contentCss}
                        ref={scrollRef}
                    >
                        {messages.value?.map((it, index) => <Basic lastTime={index > 0 ? messages.value![index - 1].createtime : ""} message={it} key={it.message_id} />)}
                    </div>
                </div>

            </div>
        }
    }
})