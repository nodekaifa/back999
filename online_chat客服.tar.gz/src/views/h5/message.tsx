import MessageBox from "@/components/message";
import {useRouteParams} from "@/hooks/useRouteParams";
import {defineComponent, onMounted, onUnmounted, ref} from "vue";
import {contactsContainerCss} from "./css/contacts.css";
import MobileHeader from "@/components/mobileHeader";
import H5Header from '@/components/H5Header'
import Sendbox from "@/components/sendbox";
import {useRoute, useRouter} from "vue-router";
import ProductInfo from "@/components/ProductInfo";
import {useContactsStore} from "@/stores/contacts";

export default defineComponent({
    setup() {

        const {color, lang, startLoop, nohead, partyid, isH5, productId} = useRouteParams();
        const contactsStore = useContactsStore();
        const router = useRouter();
        const route = useRoute();
        const messageRef = ref();
        const textRef = ref<any>();
        const headerRef = ref();
        const messageBoxRef = ref();
        const contentRef = ref();

        function sendText(text: string) {
            messageRef?.value.sendTextMessage(text);
        }

        function sendImage(file: any) {
            messageRef?.value.sendImageMessage(file);
        }

        function toContactsLiner(event: MessageEvent) {
            if (event.data == 'toContacts') {
                router.replace({query: route.query, params: route.params, path: `/h5/contacts/${route.params.color}`})
            }
        }

        onMounted(() => {
            startLoop();
            productId && contactsStore.setProductInfo(partyid!, productId)
            window.addEventListener('message', toContactsLiner, false);
        })

        onUnmounted(() => {
            window.removeEventListener('message', toContactsLiner)
        })


        return () => <div class={contactsContainerCss}
        >
            {!nohead && <MobileHeader background={color}/>}
            {isH5 && <H5Header ref={headerRef}/>}
            <div ref={contentRef} style={{
                display: 'flex',
                flexDirection: "column",
                position: 'relative',
                paddingBottom: '44px',
                height: nohead && !isH5 ? "100%" : 'calc(100% - 44px)'
            }}>
                <div ref={messageBoxRef} style={{height: "100%", position: 'relative',}}>
                    <MessageBox ref={messageRef} background={color} partyId={partyid} key={partyid}/>
                    {contactsStore.showProductInfo && <div style={{
                        position: 'fixed',
                        marginLeft: '10px',
                        width: "350px",
                        bottom: '74px',
                        height: '96px',
                        backgroundColor: 'white',
                        display: 'flex',
                        flexDirection: 'row',
                        borderRadius: '4px'
                    }}>
                        <ProductInfo/>
                    </div>}
                </div>
                <div style={{background: 'white'}}>
                    <Sendbox sendImage={sendImage} textRef={textRef} sendText={sendText} background={color}/>
                </div>
            </div>
        </div>
    }
})
