import {defineComponent, onMounted, ref,} from 'vue';
import {containerCss, contentContainerCss,} from './index.css'

import MessageBox from '@/components/message'
import Users from '@/components/users';
import Header from '@/components/header';
import {useRouteParams} from '@/hooks/useRouteParams';
import {useContactsStore} from '@/stores/contacts';
import Sendbox from '@/components/sendbox';
import ProductInfo from '@/components/ProductInfo';

export default defineComponent({


    setup() {

        const {color, startLoop, lang, productId, partyid} = useRouteParams()


        const contactsStore = useContactsStore();
        const messageRef = ref();

        function sendText(text: string) {
            messageRef?.value.sendTextMessage(text);
        }

        function sendImage(file: any) {
            messageRef?.value.sendImageMessage(file);
        }

        onMounted(() => {
            startLoop();
            productId && contactsStore.setProductInfo(partyid!, productId)
        })


        return () => {
            const partyId = contactsStore.selectContactId?.toString() || ""
            return <div style={{
                display: 'flex',
                width: "100%",
                height: "100vh",
                justifyContent: 'center',
                alignItems: "center"
            }}>
                <div class={containerCss}>
                    <Header background={color}/>
                    {/* <div style={{ height: "44px" }} /> */}
                    <div class={contentContainerCss}>
                        <Users width={"240px"} needSelect={true} style={{width: '300px'}}/>
                        <div style={{
                            display: 'flex',
                            flex: 1,
                            flexDirection: "column",
                            borderLeft: "#F3F6F9 1px solid",
                            position: 'relative',
                            paddingBottom: '44px',
                        }}>
                            <div style={{height: '100%', width: "100%", position: 'relative',}}>
                                <MessageBox ref={messageRef} partyId={partyId} key={partyId} background={color}/>
                                {contactsStore.showProductInfo && <div style={{
                                    position: 'absolute',
                                    marginLeft: '10px',
                                    width: "350px",
                                    bottom: '60px',
                                    height: '102px',
                                    backgroundColor: 'white',
                                    display: 'flex',
                                    flexDirection: 'row',
                                    borderRadius: '4px',
                                    boxShadow: '0px 0px 12px 0px rgba(0,0,0,0.3)',
                                }}>
                                    <ProductInfo/>
                                </div>}
                            </div>
                            <Sendbox sendImage={sendImage} sendText={sendText} background={color}/>
                        </div>

                    </div>
                </div>
            </div>
        }
    },

})



