import { style } from "@vanilla-extract/css";

export const containerCss = style({
    display: 'flex',
    flexDirection: "column",
    width: "1060px",
    height: "646px",
    background: "#FFFFFF",
    boxShadow: " 0px 18px 36px rgba(19, 26, 40, 0.2)",
    borderRadius: "4px",
})



export const contentContainerCss = style({
    display: "flex",
    flexDirection: "row",
    position: 'relative',
    width: "1060px",
    height: "100%",
});




export const messageContainerCss = style({
    height: '100%',
    width: "100%",

});

export const inputContainerCss = style({
    width: '100%',
    height: 44,
    background: "white",
    display: 'flex',
    flexDirection: "row",
    alignItems: "center",
    justifyContent: 'space-around'
});








