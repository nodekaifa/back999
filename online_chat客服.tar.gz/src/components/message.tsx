import { themes } from "@/css/app.css";
import { useMessageHooks } from "@/hooks/useMessage";
import { defineComponent, onMounted, onUnmounted, PropType, ref, watchEffect, } from "vue";
import { boxContainerCss, contentCss } from "./message.css";
import Basic from "./messageItem/basic";

export default defineComponent({
    name: "MessageContent",
    props: {
        background: Object as PropType<keyof typeof themes>,
        partyId: String
    },

    setup(props) {

        const scrollRef = ref<HTMLDivElement | null>(null)

        const { messages: { now, historyMessage },
            tag,
            loadingMore,
            startLoopGetMessage,
            cancelTimer,
            sendTextMessage,
            sendImageMessage } = useMessageHooks(props.partyId!);

        watchEffect(() => {
            if (tag.scrollToBottom.value) {
                tag.scrollToBottom.value = false;
                setTimeout(() => {
                    scrollRef.value?.scrollTo({ top: scrollRef.value!.scrollHeight })
                })
            }
        })

        onMounted(() => {
            console.log('this.now', now)
            startLoopGetMessage();
            // console.log(scrollRef.value)
        })

        onUnmounted(() => {
            cancelTimer();
        })

        const handleScroll = () => {

            if (scrollRef.value && scrollRef.value.scrollTop < 10) {
                loadingMore();
            }
        }

        return {
            handleScroll,
            scrollRef,
            now,
            historyMessage,
            sendTextMessage,
            sendImageMessage,
            tag,
        }
    },

    render() {

        return <div class={boxContainerCss} >
            <div onScroll={this.handleScroll}
                class={contentCss}
                ref='scrollRef'
            >
                {/* <div class={loadingCss}> <span>{isLoadingMore || messages.value.length == 0 ? ` 加载中........` : isNotMore?.value && '没有了更多了'}</span> </div> */}
                {this.historyMessage?.map((it, index) => <Basic
                    lastTime={index > 0 ? this.historyMessage[index - 1].createtime : ""}
                    message={it} key={it.id} />)}
                {this.now.map((it, index) => <Basic
                    lastTime={index > 0 ? this.now[index - 1].createtime : ""}
                    message={it}
                    key={it.id} />)}
            </div>
        </div>
    }
});

