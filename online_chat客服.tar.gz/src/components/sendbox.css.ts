import {style} from "@vanilla-extract/css";

export const sendContainerCss = style({
    height: 44,
    width: "100%",
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    background: 'white',
    justifyContent: 'space-around',
    paddingTop: 6,
    paddingBottom: 6,
    paddingLeft: 12,
    paddingRight: 12,
    boxSizing: 'border-box',
    position: 'absolute',
    bottom: 0,
});


export const sendButton = style({
    width: 80,
    height: 34,
    borderRadius: 17,
    color: "white",
    display: 'flex',
    position: 'relative',
    boxSizing: 'border-box',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    cursor: 'pointer'
});

export const sendButtonDisable = style([sendButton, {
    cursor: "not-allowed",
    borderColor: "#d9d9d9",
    color: "rgba(0,0,0,.25)",
    backgroundColor: "rgba(0,0,0,.04)",
    boxShadow: 'none'
}])

export const imageButtonCss = style({
    height: 24,
    width: 24,
});

export const inputBoxCss = style({
    height: 32,
    width: '100%',
    background: "#F3F6F9",
    border: 'none',
    marginLeft: 10,
    marginRight: 10,
});

export const loader = style({
    // animation
    borderRadius: '50%',
    width: 20,
    height: 20,
    animation: 'bblFadInOut 1.8s infinite ease-in-out',
    position: 'fixed',
    zIndex: 999
})
