import {style} from "@vanilla-extract/css";

export const usersListContainerCss = style({
    height: "100%",
    width: "100%",
    background: "white",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    overflowY: 'auto',
    overflowX: 'hidden',
    // overflowX: 'hidden'
    scrollbarWidth: 'thin',
    '::-webkit-scrollbar': {
        width: 5,
        height: 12,
        background: 'white'
    },
    '::-webkit-scrollbar-thumb': {
        background: "#aaa",
        borderRadius: '1ex',
        boxShadow: "0px 1px 2px rgba(0, 0, 0, 0.75)"
    },

    '::-webkit-scrollbar-corner': {
        background: 'white'
    },
    // height: '100%',
    overflowAnchor: "none"
});

export const userItemContainer = style({
    display: "flex",
    flexDirection: "row",
    width: "100%",
    height: 77,
    minHeight: 77,
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0 12px',
    boxSizing: 'border-box',
    cursor: 'pointer',
});


export const userAvatarCss = style({
    height: 44,
    width: 44,
    borderRadius: 22.5,
    marginRight: 12
});

export const userNameContainerCss = style({
    height: 43,
    width: '100%',
    display: 'flex',
    flexDirection: "column",
    marginRight: 18,
    flexShrink: 0,
    flex: 1
});

export const userNameCss = style({
    fontSize: 12,
    marginBottom: 4
})

export const unreadNumberCssContainer = style({
    display: "flex",
    flexDirection: "column",
    alignItems: 'center',
    position: 'absolute',
    right: 12,
});

export const unreadNumberCss = style({
    padding: 2,
    width: 16,
    height: 16,
    lineHeight: '16px',
    borderRadius: '50%',
    background: '#FF3E3E',
    color: 'white',
    textAlign: 'center',
    flexShrink: 0,
    fontSize: 12,
    display: "flex",
    alignItems: 'center',
    justifyContent: "center",
    transform: 'scale(0.7)',
});

export const timeCss = style({
    fontSize: '12px',
    marginTop: 2,
});


export const textContentCss = style({
    //    wordWrap:"no"
    display: 'inline-block',
    whiteSpace: 'nowrap',
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    // width: "100%"
});
