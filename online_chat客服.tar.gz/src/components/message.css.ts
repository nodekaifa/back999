import {style} from "@vanilla-extract/css";

export const boxContainerCss = style({
    height: '100%',
    width: "100%",
    display: "flex",
    flexDirection: 'column',
    // borderLeft: "#F3F6F9 1px solid",
    position: 'absolute'
});

export const contentCss = style({
    display: 'flex',
    width: "100%",
    overflow: 'overlay',
    flexDirection: "column",
    background: '#F3F6F9',
    scrollbarWidth: 'thin',
    '::-webkit-scrollbar': {
        width: 5,
        height: 12,
        background: 'white'
    },
    '::-webkit-scrollbar-thumb': {
        background: "#aaa",
        borderRadius: '1ex',
        boxShadow: "0px 1px 2px rgba(0, 0, 0, 0.75)"
    },

    '::-webkit-scrollbar-corner': {
        background: 'white'
    },
    // height: '100%',
    flex: 1,
    overflowAnchor: "none"
});

export const loadingCss = style({
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    justifyItems: 'center',
    alignItems: 'center',
    height: 22,
    marginTop: 10,
    fontSize: 12,
});
