import {useContactsStore} from "@/stores/contacts";
import {defineComponent} from "vue";
import {
    textContentCss,
    timeCss,
    unreadNumberCss,
    unreadNumberCssContainer,
    userAvatarCss,
    userItemContainer,
    userNameContainerCss,
    usersListContainerCss
} from "./users.css";
import {storeToRefs} from "pinia";
import {useRoute, useRouter} from "vue-router";
import {formeateUser, getContactAvatar} from "@/utils";
import {shourtTimeString} from "@/utils/time";
import {useRouteParams} from "@/hooks/useRouteParams";

export default defineComponent({
    props: {
        width: String,
        needSelect: Boolean,
    },
    setup(props) {
        const store = useContactsStore();
        const {contacts, selectContactId} = storeToRefs(store);
        const {lang, type} = useRouteParams();
        const route = useRoute();
        const router = useRouter();

        // 处理用户项点击事件
        const handleItemClick = (id: string, name: string) => {
            if (props.needSelect) {
                store.selectParityAndLoop(id);
            } else {
                router.replace({
                    path: `/h5/message/${route.params.color}`,
                    params: route.params,
                    query: {
                        ...route.query,
                        partyid: id,
                        token: sessionStorage.getItem('online_im_token'),
                        shopName: name,
                        productId: undefined,
                    },
                });
            }
        };

        const textWidth = '180px';//props.needSelect ? '210px' :

        return () => (
            <div class={usersListContainerCss} style={"100%"}>
                {contacts?.value?.map((it) => (
                    <div
                        key={it.id}
                        onClick={() => handleItemClick(it.partyid!, it.username!)}
                        class={userItemContainer}
                        style={{
                            background: props.needSelect && it.partyid === selectContactId?.value ? "#F0F4F9" : "",
                            position: 'relative',
                        }}
                    >
                        <div style={{display: 'flex', flexDirection: "row", alignItems: "center"}}>
                            <img src={getContactAvatar(it)} class={userAvatarCss}/>
                            <div class={userNameContainerCss} style={{fontSize: "12px"}}>
                                <span class={textContentCss} style={{marginBottom: "2px", width: textWidth}}>
                                  {formeateUser(it.username!)}
                                </span>
                                <div class={textContentCss} style={{width: textWidth, paddingRight: '30px'}}>
                                    {it.content}
                                </div>
                            </div>
                        </div>
                        <div class={unreadNumberCssContainer}>
                            {it.unreadmsg ? (
                                <div class={unreadNumberCss}>
                                    <span>{it.unreadmsg}</span>
                                </div>
                            ) : (
                                <div style={{height: '13px',"flex-shrink": 1}}/>
                            )}
                            <div class={timeCss}>
                                {shourtTimeString(it.updatetime!)}
                            </div>
                        </div>
                        <div style={{
                            height: '1px',
                            width: '100%',
                            content: ' ',
                            position: 'absolute',
                            left: 0,
                            bottom: 0,
                            padding: '0 18px'
                        }}>
                            <div style={{
                                height: '100%',
                                width: '100%',
                                content: ' ',
                                position: 'absolute',
                                left: 0,
                                bottom: 0,
                                backgroundColor: '#F3F6F9'
                            }}/>
                        </div>
                    </div>
                ))}
            </div>
        );
    },
});
