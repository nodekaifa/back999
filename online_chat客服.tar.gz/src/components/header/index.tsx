import {themes} from "@/css/app.css";
import {defineComponent, PropType} from "vue";
import {headerContainer} from "./index.css";
import Logo from "../Logo";
import {useContactsStore} from "@/stores/contacts";
import {formeateUser} from "@/utils";

export default defineComponent({
    props: {
        background: Object as PropType<keyof typeof themes>,
        width: String,
        shopName: String
    },
    setup(props) {
        const contactStore = useContactsStore();
        return () => <div class={[headerContainer, themes[props.background!]]} style={{width: props.width || "100%"}}>
            {/* <img src={logoImg} style={{ width: "106.22px", height: "25.67px", marginLeft: "10px" }} /> */}
            <Logo background={props.background}/>
            {/* <img style={{ height: '30px', width: "30px", margin: '0px 10px 0px 0px', borderRadius: '15px' }} src={contactStore.avatar} ></img> */}
            <span style={{
                position: "absolute",
                width: "100%",
                textAlign: "center"
            }}>{props.shopName || formeateUser(contactStore.name!)}</span>
        </div>
    }
})
