import {style} from "@vanilla-extract/css";

export const headerContainer = style({
    display: 'flex',
    flexDirection: "row",
    height: 44,
    color: 'white',
    alignItems: 'center',
    position: "relative",
    paddingLeft: 10,
    paddingRight: 10,
    boxSizing: 'border-box',
})
