import { ElImage } from "element-plus";
import { defineComponent } from "vue";

export default defineComponent({
    name: "ImgMessage",
    props: {
        url: String
    },

    setup({ url }) {
        // const {message }= props;
        return () => {
            return <ElImage previewSrcList={[url!]} style={{ objectFit: "contain", width: "194px", minHeight: '36px' }} src={url} fit='fill'/>
        }
    }
});
