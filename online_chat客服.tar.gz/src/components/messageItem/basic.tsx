import { defineComponent, PropType } from "vue";
import { avatarCss, messageContainerCss, receiveBoxCss, receiveContentCss, sendBoxCss, sendContentCss } from "./item.css";
import userAvatar from '@/assets/useravtar.png'
import ImgMessage from './image'
import dayjs from "dayjs";
import { calculateTime, getSelfAvatar, isUrl } from "@/utils";
import { Message } from "@/hooks/useMessage";
import { useContactsStore } from "@/stores/contacts";
import { useRouteParams } from "@/hooks/useRouteParams";
import ProdcutMessage from "./ProdcutMessage";
export default defineComponent({
    props: {
        message: Object as PropType<Message>,
        lastTime: String
    },



    setup({ message, lastTime }) {
        const noTime = lastTime && dayjs(message?.createtime).unix() - dayjs(lastTime).unix() < 60

        const store = useContactsStore();
        const { lang } = useRouteParams();

        const style: any = {
            marginTop: '15px',

        }

        return () => {
            return <div class={messageContainerCss} style={{ marginTop: '15px', }}>
                {!noTime && <span style={{ fontSize: '12px' }}>{calculateTime(lang as any, message?.createtime)}</span>}
                {message?.send_receive === "send" && <div class={sendBoxCss}>
                    <div class={sendContentCss} style={{ width: message.type === 'product' ? '280px' : '194px', background: message.type === 'product' ? "white" : "#FFEAD1" }}>
                        {/* {isUrl(message.content) ? <ImgMessage url={message.content} />: message.content } */}
                        {message.type === 'text' && message.content}
                        {message.type === 'image' && <ImgMessage url={message.content} />}
                        {message.type === 'product' && <ProdcutMessage infoStr={message.content} />}
                    </div>
                    <img src={getSelfAvatar(store.selectContactId!.toString(), store.selfAvatar)} class={avatarCss} style={{ marginLeft: '10px' }} />
                </div>}
                {message?.send_receive === "receive" && <div class={receiveBoxCss}>
                    <img src={store.avatar} class={avatarCss} style={{ marginRight: "10px" }} />
                    <div class={receiveContentCss} style={{ width: message.type === 'product' ? '280px' : '194px' }}>
                        {/* {isUrl(message.content) ? <ImgMessage url={message.content} />:message.content} */}
                        {message.type === 'text' && message.content}
                        {message.type === 'image' && <ImgMessage url={message.content} />}
                        {message.type === 'product' && <ProdcutMessage infoStr={message.content} />}
                    </div>
                </div>}
            </div>
        }
    }
});
