import { numberFormat } from "@/utils";
import { defineComponent } from "vue";
import { useRoute } from "vue-router";
import { productMessageContent } from "./item.css";

export default defineComponent({


    props: {
        infoStr: String,
    },

    setup({ infoStr }) {

        const data = JSON.parse(infoStr!);
        const route = useRoute();
        // route.query.is

        const handleClick = () => {
            if (route.query.isH5) {
                window.parent.location.href = `${window.location.origin}/wap/#/CommodityDetails?sellerGoodsId=${data.id}`
            } else {
                window.open(`https://${window.location.host}/#/productDetails?id=${data.id}`)
            }
        }

        return () => <div onClick={handleClick} style={{ width: "100%", display: 'flex', flexDirection: 'row', alignItems: 'center', cursor: "pointer" }}>
            <img src={data.img} style={{ height: '62px', width: '62px', objectFit: 'contain' }} />
            <div style={{ marginLeft: '10px', width: "100%" }}>

                <div class={productMessageContent}>
                    {data.name}
                </div>
                <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: '16px', fontWeight: 500, color: '#F89900' }}>
                        ${numberFormat(data.price)}
                    </span>
                </div>
            </div>
        </div>


    }
})