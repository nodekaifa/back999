import { style } from "@vanilla-extract/css";

const boxCss = style({
    display: "flex",
    flexDirection: "row",
    width: "100%",
    marginTop: 10,
    selectors: {
        '&:last-child': {
            marginBottom: 20
        },
    }
});

export const messageContainerCss = style({
    display: "flex",
    flexDirection: 'column',
    alignItems: 'center'
});

export const receiveBoxCss = style([boxCss, {
    justifyContent: 'flex-start',
}]);

export const sendBoxCss = style([boxCss, {
    justifyContent: "flex-end",
}]);


export const avatarCss = style({
    width: 44,
    height: 44,
    marginLeft: 20,
    marginRight: 20,
    borderRadius: 22
});

const messageBoxCss = style({
    // width: '194px',
    padding: 13,
    borderRadius: 5,
    wordBreak: 'break-all'
})

export const receiveContentCss = style([messageBoxCss, {
    background: 'white',
}])

export const sendContentCss = style([messageBoxCss, {
    // background: '#FFEAD1'
    marginLeft: 0,
    marginRight: 0,
}])

export const productMessageContent = style({
    width: "100%",
    display: '-webkit-box',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 3,
    overflow: 'hidden',
    fontWeight: 400,
    fontSize: '12px'
})
