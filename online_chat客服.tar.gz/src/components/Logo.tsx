import { themes } from "@/css/app.css";
import { defineComponent, PropType } from "vue";

import OrangeLogo from '@/assets/orange.svg';
import BlueLogo from '@/assets/blue.svg';
import { logoCss } from "./logo.css";
import { headEnv } from "@/utils/env";
import { base } from "@/utils";

export default defineComponent({
    props: {
        background: Object as PropType<keyof typeof themes>,
    },
    setup(props) {

        return () => {
            if (headEnv.title == 'E-SHOP') {
                // @ts-ignore
                return <div>{props.background == 'blue' ? <BlueLogo class={logoCss} /> : <OrangeLogo class={logoCss} />}</div>
            } else if (typeof headEnv.barIcon === 'object') {
                return <img class={logoCss} style={{ fill: 'white' }} src={`${base}${headEnv.barIcon[props.background!]}`}></img>
            } else {
                return <img class={logoCss} style={{ fill: 'white' }} src={`${base}${headEnv.barIcon}`}></img>
            }

        }
    }
})
