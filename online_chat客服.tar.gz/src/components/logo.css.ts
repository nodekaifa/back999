import { style } from "@vanilla-extract/css";

export const logoCss = style({
    // width: 25.6,
    height: 25.6,
    marginLeft:10,
});