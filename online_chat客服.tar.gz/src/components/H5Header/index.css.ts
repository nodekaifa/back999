import { style } from "@vanilla-extract/css";

export const headerContainer = style({
    display:'flex',
    justifyContent: 'space-between',
    alignContent: 'center',
    height: 44,
    alignItems: 'center',
    position:"relative",
    background: '#fff',
    zIndex: 999,
    paddingLeft: 10,
    paddingRight: 10,
    boxSizing: 'border-box',
})
export const headerTitle = style({
    color: '#333',
    fontWeight: 500,
    fontSize: 16,
    display: 'inline-block',
    width: '67%',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    textAlign: 'center'
})
