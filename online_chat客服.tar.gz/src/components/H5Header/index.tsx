import { themes } from "@/css/app.css";
import { defineComponent, PropType } from "vue";
import { useRouter, useRoute } from "vue-router";
import { ElIcon } from "element-plus";
import { User } from "@element-plus/icons-vue";
import { $t } from "@/utils/lang";
import { headerContainer, headerTitle } from "./index.css";
import backImg from "@/assets/back.png";
export default defineComponent({
  props: {
    background: Object as PropType<keyof typeof themes>,
    width: String,
  },
  setup(props) {
    const router = useRouter();
    const route = useRoute();
    const handelClick = () => {
      router.replace({
        query: { ...route.query, shopName: '' },
        params: route.params,
        path: `/h5/contacts/${route.params.color}`,
      });
    };
    const backPrevious = () => {
      window.parent.postMessage('back', '/')
      // window.parent.postMessage('back', 'http://localhost:8090')
    }
    return () => (
      <div class={headerContainer} style={{ width: props.width || "100%" }}>
        <img
          src={backImg}
          style={{ width: "22px", height: "22px", marginLeft: "10px" }}
          onClick={backPrevious}
        />
        {
          route.query.shopName ? <span class={headerTitle}>{route.query.shopName}</span> :
            <span class={headerTitle}>{$t('message')}</span>
        }

        {route.path == "/h5/contacts/yellow" ? (
          <div style={{ flex: '0 0 20px' }}></div>
        ) : (
          <div style={{ marginRight: "10px" }} onClick={handelClick}>
            <ElIcon size={20}>
              <User />
            </ElIcon>
          </div>
        )}
      </div>
    );
  },
});
