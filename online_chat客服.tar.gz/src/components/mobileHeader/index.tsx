import { themes } from "@/css/app.css";
import { defineComponent, PropType } from "vue";
import { headerContainer } from "./index.css";
import logoImg from '@/assets/logo.png';
// import { Plus } from 'unplugin-icons'
import { User } from '@element-plus/icons-vue'
import { ElIcon } from "element-plus";
import { useRoute, useRouter } from "vue-router";
import Logo from "../Logo";
export default defineComponent({
    props: {
        background: Object as PropType<keyof typeof themes>,
        width: String
    },
    setup(props) {

        const router = useRouter();
        const route = useRoute();
        const handelClick = () => {
            router.replace({ query: route.query, params: route.params, path: `/h5/contacts/${route.params.color}` })
        }

        return () => <div class={[headerContainer, themes[props.background!]]} style={{ width: props.width || "100%" }} >
            <Logo background={props.background} />
            {/* <Plus /> */}
            {!route.query.chatid && <div style={{ marginRight: "10px" }} onClick={handelClick}>
                <ElIcon size={20} >
                    <User />
                </ElIcon>
            </div>}
        </div>
    }
})