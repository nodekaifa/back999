import {sendMessageApi} from "@/service/api";
import {defineComponent, PropType} from "vue";

import closeImg from '@/assets/close.png'
import {themes} from "@/css/app.css";
import {useContactsStore} from "@/stores/contacts";
import {$t} from "@/utils/lang";
import {productMessageContent} from "../messageItem/item.css";
import {numberFormat} from "@/utils";

export default defineComponent({

    props: {
        background: Object as PropType<keyof typeof themes>,
    },


    setup() {

        const contactsStore = useContactsStore();


        const handelClose = () => {
            // router.replace({ query: { ...route.query, productId: undefined } })
            contactsStore.nowProductInfo = {};
        }

        const handelSendProductInfo = async () => {
            contactsStore.isSending = true
            const content = {
                img: contactsStore.nowProductInfo!.productInfo.imgUrl1,
                name: contactsStore.nowProductInfo!.productInfo.name,
                price: contactsStore.nowProductInfo!.productInfo.sellingPrice,
                id: contactsStore.nowProductInfo!.productInfo.id
            }
            const response = await sendMessageApi({
                partyid: contactsStore.selectContactId! as string,
                content: encodeURIComponent(JSON.stringify(content)),
                type: "product"
            })
            contactsStore.isSending = false
            if (response.data.code == '0') {
                handelClose();
            }
        }

        return () => <div style={{width: "100%", display: 'flex', flexDirection: 'row', alignItems: 'center'}}>
            <img src={contactsStore.nowProductInfo!.productInfo.imgUrl1}
                 style={{marginLeft: '10px', height: '68px', width: '68px', objectFit: 'contain'}}/>
            <div style={{padding: '0 12px'}}>

                <div class={productMessageContent} style={{width: "250px"}}>
                    {contactsStore.nowProductInfo!.productInfo.name}
                </div>
                <div style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                }}>
                    <span style={{fontSize: '16px', fontWeight: 500, color: '#F89900'}}>
                        ${numberFormat(contactsStore.nowProductInfo!.productInfo.sellingPrice)}
                    </span>
                    <div
                        onClick={handelSendProductInfo}
                        style={{
                            color: 'white',
                            backgroundColor: '#F89900',
                            padding: "5px 10px",
                            borderRadius: '15px',
                            cursor: 'pointer',
                            fontSize: '13px',
                            fontWeight: 500,
                            marginTop: '5px',
                            marginRight: '5px'
                        }}>
                        {$t('sendProduct')}
                    </div>
                </div>
            </div>
            <img onClick={handelClose} src={closeImg}
                 style={{
                     height: '14px',
                     width: '14px',
                     alignSelf: 'flex-start',
                     cursor: 'pointer',
                     position: 'absolute',
                     right: '5px',
                     top: '5px'
                 }}/>
        </div>
    }


})
