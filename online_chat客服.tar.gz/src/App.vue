<template>
  <router-view></router-view>
</template>

<script lang="ts" setup>
import {useContactsVoice} from './hooks/useContactsVoice';
import {useRoute, useRouter} from 'vue-router';

const route = useRoute();
const router = useRouter();
//chatid=0b3438e58a03051c018a03379c090005-0b3438e5874846490187485346740026&shopName=大大大的店&height=600px
//token=e664315d76954c68aff065c34f0e5fce&selfimg=&type=shop&lang=cn

// // 使用watch监听route.params.color的变化，并根据移动端与否动态改变URL
// watch(
//     () => route.params.color,
//     (newColorParam) => {
//       if (newColorParam) {
//         const ua = navigator.userAgent.toLowerCase();
//         const isMobile = ua.indexOf('mobile') > -1;

//         const basePath = isMobile ? '/h5/contacts' : '/pc';
//         const query = window.location.search;
//         const newPath = `${basePath}/${newColorParam}`;

//         // 使用router.push()将查询参数放在query对象中
//         router.push({
//           path: newPath,
//           query: route.query,
//         });
//       }
//     }
// );

// onMounted(() => {
//   // 初始执行一次动态改变URL
//   if (route.params.color) {
//     const ua = navigator.userAgent.toLowerCase();
//     const isMobile = ua.indexOf('mobile') > -1;
//     if (isMobile) {
//       document.body.style.minWidth = '100%';
//     } else {
//       debugger
//       document.body.style.minWidth = '800px';
//     }
//     const basePath = isMobile ? '/h5/contacts' : '/pc';
//     const query = window.location.search;
//     const newPath = `${basePath}/${route.params.color}`;

//     // 使用router.push()将查询参数放在query对象中
//     router.push({
//       path: newPath,
//       query: route.query,
//     });
//   }
// });

useContactsVoice();
</script>

<style scoped></style>
