type Contacts = {
    content?: string,
    id?: string
    partyid?: string
    unreadmsg?: number
    updatetime?: string
    username?: string
    useravatar?: string
    avatar?: string
}