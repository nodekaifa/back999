import { loadPartyMessage, sendMessageApi, uploadMessageImg } from "@/service/api";
import { useContactsStore } from "@/stores/contacts";
import { showMessage } from "@/utils";
import lang, { LangType } from "@/utils/lang";
import { playAudio } from "@/utils/playaduio";
import { reactive, ref, toRefs } from 'vue'

export interface Message {
    createtime?: string,
    delete_status?: number,
    id: string,
    type: string
    content: string
    send_receive?: string,
    faild?: boolean,
    message_id?: string,
}

export function useMessageHooks(_parityId: string,) {

    const tag = reactive<{
        hasChange: boolean,
        isNotMore: boolean,
        timer?: any,

        completed: boolean,
        scrollToBottom: boolean,
        isLoadingMore?: boolean,
        isSendMessage?: boolean
    }>({ hasChange: false, isNotMore: false, completed: false, scrollToBottom: false })

    const messages = reactive<{ now: Message[], historyMessage: Message[] }>({ now: [], historyMessage: [] });
    const contactsStore = useContactsStore();

    const startLoopGetMessage = () => {
        tag.hasChange = true
        tag.isNotMore = false
        tag.timer && clearInterval(tag.timer)
        _refreshMessage();
        tag.timer = setInterval(_refreshMessage, 1000 * 3)
    }

    const _refreshMessage = async () => {
        if (!_parityId) {
            return;
        }
        if (messages.now.length == 0) {
            messages.now = JSON.parse(sessionStorage.getItem(`online_im_${_parityId}`) || "[]")
        }
        const resp = await loadPartyMessage(_parityId)
        // console.log(messages.now.length)
        if (resp.data.code === '0') {
            if (resp.data.data
                && resp.data.data.length > 0
                && messages.now.length > 0
                && messages.now[messages.now.length - 1].id != resp.data.data[0].id) {
                tag.scrollToBottom = true;
                //获取接受到的新的消息 用于播放 声音
                const newIdx = resp.data.data.findIndex((x: any) => x.id === messages.now[messages.now.length - 1].id);
                const newArray = [...resp.data.data].splice(0, newIdx).filter((x: any) => x.send_receive === 'receive');
                // console.log(newArray)
                playAudio(newArray.length);

            }
            if (resp.data.data.length) {
                messages.now = (resp.data.data as Array<any>).reverse();
            }

        }
        if (tag.hasChange) {
            tag.hasChange = false;
            tag.scrollToBottom = true;
        }
        const newNow = handleMessageNow(messages.now)
        sessionStorage.setItem(`online_im_${_parityId}`, JSON.stringify(newNow))
    }
    // 处理message.now 防止他不是一个数组报错
    const handleMessageNow = (value: any) => {
        if (Array.isArray(value)) {
            return value
        } else {
            handleMessageNow(value.now)
        }
    }
    const loadingMore = async () => {
        if (tag.isLoadingMore || tag.isNotMore) {
            return;
        }
        let updateMessageId = ""
        if (messages.historyMessage.length === 0 && messages.now.length > 0) {
            updateMessageId = messages.now[0].id;
        } else if (messages.historyMessage.length > 0 && !tag.isNotMore) {
            updateMessageId = messages.historyMessage[0].id;
        }
        tag.isLoadingMore = true;
        if (updateMessageId != "") {
            const resp = await loadPartyMessage(_parityId, updateMessageId)
            if (resp.data.code === '0') {
                if (resp.data.data && resp.data.data.length > 0) {
                    messages.historyMessage = [...(resp.data.data as Array<any>).reverse(), ...messages.historyMessage];
                } else {
                    tag.isNotMore = true
                }
            }
        }
        tag.isLoadingMore = false;
    }

    const cancelTimer = () => {
        // console.log('cancelTimer', tag.timer)
        tag.timer && clearInterval(tag.timer);
        tag.timer = undefined;
    }
    const sendTextMessage = async (content: string) => {

        contactsStore.isSending = true
        tag.isSendMessage = true
        cancelTimer();
        // messages.now = [...messages.now, { id: `send_no_send`, type: "text", content, send_receive: "send" }]
        tag.scrollToBottom = true;
        tag.hasChange = true

        await sendMessageApi({ partyid: _parityId, content, type: "text" })
        startLoopGetMessage();

        contactsStore.isSending = false
        // if (response.data.code != '0') {
        //     showMessage(response.data.msg, 'error')
        // }
    }

    const sendImageMessage = async (file: File) => {
        // tag.isSendMessage = true
        contactsStore.isSending = true
        cancelTimer();
        // messages.now.push({
        //     id: `send_iamge_${messages.now.length}`,
        //     content: URL.createObjectURL(file),
        //     send_receive: "send",
        //     type: 'image'
        // })
        const langInstance = lang[sessionStorage.getItem('im_lang') as LangType || 'cn'];
        showMessage(langInstance.sending, 'info', 0)
        tag.scrollToBottom = true;
        tag.hasChange = true
        const resp = await uploadMessageImg(file);
        if (resp.data.code == '0') {
            showMessage(langInstance.sendSuccess, 'success')
            const response = await sendMessageApi({ partyid: _parityId, content: resp.data.data, type: "image" })
            if (response.data.code == '0') {
                startLoopGetMessage();
            }
        }
        contactsStore.isSending = false
        // tag.isSendMessage = false
        //  else {
        //     showMessage(resp.data.msg, 'error')
        // }
    }
    console.log(`messages ::->`, messages);
    return {
        sendImageMessage,
        sendTextMessage,
        loadingMore,
        startLoopGetMessage,
        cancelTimer,
        messages: toRefs(messages),
        tag: toRefs(tag)
    }
}