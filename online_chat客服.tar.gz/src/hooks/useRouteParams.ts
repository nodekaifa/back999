import { themes } from "@/css/app.css";
import { router } from "@/router";
import { useContactsStore } from "@/stores/contacts";
import { LangType } from "@/utils/lang";
import { onMounted, watch, watchEffect } from "vue";
import { useRoute } from "vue-router";

export function useRouteParams() {
    // const lang: "en" | "cn" | "tw" = "cn";
    // const height = '0';
    const route = useRoute();
    const { token,
        name,
        partyid,
        lang = 'cn',
        height,
        chatid,
        selfimg,
        nohead,
        mt,
        isH5,
        productId,
        selectType,
        shopName,
        type = 'user' } = route.query as {
            token: string,
            name?: string,
            partyid?: string,
            lang?: LangType,
            height?: string,
            chatid?: string,
            selfimg?: string,
            nohead?: string,
            mt?: string,
            isH5?: string,
            type?: string
            productId: string
            selectType?: string,
            shopName?: string
        }
    let { color } = route.params as { color: keyof typeof themes, token?: string }

    if (!["blue", "yellow"].includes(color, 0)) {
        color = "blue"
    }
    const contactsStore = useContactsStore();
    contactsStore.selfAvatar = selfimg;
    onMounted(() => {
        sessionStorage.setItem('type', type);
        sessionStorage.setItem('im_lang', lang);
    })

    return {
        token,
        name,
        partyid,
        color,
        height,
        lang,
        chatid,
        nohead,
        mt,
        isH5,
        productId,
        type,
        selectType,
        shopName,
        startLoop: () => contactsStore.selectParityAndLoop(partyid, name, token),
        // sotoryPartyId: contactsStore.selectContactId
    }
}
