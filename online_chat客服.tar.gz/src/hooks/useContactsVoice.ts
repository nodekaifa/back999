// import { useContactsStore } from "@/stores/contacts";
// import { playAudio } from "@/utils/playaduio";


// let cacheMessage: any[] = [];


export function useContactsVoice() {
    // const contactsStore = useContactsStore();

    // contactsStore.$subscribe((mo, state) => {

    //     const filters = state.contacts?.filter(x => x.unreadmsg && x.unreadmsg > 0 && state.selectContactId !== x.partyid);
    //     if (filters) {
    //         for (let un of filters) {
    //             const cache = cacheMessage.find(x => x.id === un.id);
    //             const count = un.unreadmsg! - (cache?.unreadmsg || 0);
    //             console.log('useContactsVoice', count)
    //             if (!cache) {
    //                 cacheMessage.push(un)
    //             } else {
    //                 cache.unreadmsg = un.unreadmsg
    //             }
    //             playAudio(count);
    //         }
    //     } else {
    //         cacheMessage = [];
    //     }
        // if (filters && filters.length > 0) {
        //     const needs = filters.filter(x => !lastMessage.find(m => m.conent == x.content && x.updatetime))
        //     if (needs && needs.length > 0) {
        //         needs.forEach(x => lastMessage.push({
        //             conent: x.content!,
        //             updatetime: x.updatetime!,
        //             unreadmsg: x.unreadmsg
        //         }))

        //         aduio.play();
        //     }

        // } else {
        //     lastMessage = [];
        // }
    // })
}