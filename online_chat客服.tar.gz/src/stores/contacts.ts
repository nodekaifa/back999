import { getContacts, getProductDetail, getUnreadMessage, sendDfaultPartiyMessageApi } from '@/service/api'
import { base, getContactAvatar, isUrl } from '@/utils'
import { defineStore } from 'pinia'

interface ContactsStoresState {
    contacts?: Contacts[],
    token?: string,
    selfAvatar?: string
    selectContactId?: String,
    nowProductInfo: {
        contactId?: string,
        productInfo?: any,
    },
    timerId?: any,
    isSending?: boolean,
    caceContact?: {
        partyId?: string,
        name?: string
    }
}

export const useContactsStore = defineStore('contactsStore', {
    state: (): ContactsStoresState => ({
        contacts: [],
        selectContactId: "",
        nowProductInfo: {}
    }),

    getters: {
        avatar(state) {
            const contact = state.contacts?.find(x => x.partyid === state.selectContactId)
            return getContactAvatar(contact);
        },
        name(state) {

            return state.contacts?.find(x => x.partyid === state.selectContactId)?.username
        },
        showProductInfo(state) {
            return state.nowProductInfo && state.selectContactId === state.nowProductInfo.contactId
        }
    },


    actions: {
        async loopGetContacts() {
            this.timerId && clearInterval(this.timerId);
            const func = async () => {
                const response = await getContacts();
                if (response.data.code == '0' && response.data.data) {
                    this.contacts = response.data.data
                    if (this.selectContactId && !this.contacts?.find(x => x.partyid === this.selectContactId)) {
                        //@ts-ignore
                        this.contacts = [{ partyid: this.selectContactId, username: this.caceContact?.name }, ...this.contacts!]
                    }
                    if (this.selectContactId == "" && this.contacts && this.contacts.length > 0) {
                        this.selectContactId = this.contacts[0].partyid
                    }
                }
            }

            func();
            this.timerId = setInterval(func, 1000 * 6);
        },

        selectParityAndLoop(partyid?: string, sellerName?: string, token?: string,) {

            if (partyid) {
                this.selectContactId = partyid;
                this.caceContact = {
                    name: sellerName,
                    partyId: partyid
                }
            }
            if (token) {
                sessionStorage.setItem('online_im_token', token)
            }
            this.setDefaulMessage();
            this.loopGetContacts()
        },

        async setProductInfo(sellerId: string, productId: string) {
            const res = await getProductDetail({ sellerGoodsId: productId })
            if (res.data.code == '0') {
                this.nowProductInfo = {
                    contactId: sellerId,
                    productInfo: res.data.data
                }
            }
        },

        async setDefaulMessage() {
            const loginType = sessionStorage.getItem('type');
            const partyid = this.selectContactId?.toString();
            if (!partyid || partyid == "") {
                return;
            }
            const param: any = {
            }

            if (loginType === 'user') {

                param['sellerId'] = partyid;
            } else {
                return;
                param['userId'] = partyid;
            }
            console.log('=======setDefaulMessage=============')

            await sendDfaultPartiyMessageApi(param)
        },

        reset() {
            this.timerId && clearInterval(this.timerId);
            this.$reset();
        }
    }
})

