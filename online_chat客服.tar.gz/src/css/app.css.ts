import { globalStyle, styleVariants } from '@vanilla-extract/css'
globalStyle('html', {
    height: '100%',
  })
globalStyle('body', {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  fontSize: '14px',
  width: '100%',
  height: '100%',
  background: '#F5F5F5',
  margin: 0,
})

export const themes = styleVariants({
  yellow: { background: "#F89900" },
  blue: { background: "#1552F0" }
})

