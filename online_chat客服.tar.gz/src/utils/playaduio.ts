
import chatMp3 from '@/assets/chat.mp3';
const aduio = new Audio(chatMp3);

export function playAudio(count: number) {
    if (count <= 0) {
        return;
    }
    aduio.play();
    aduio.addEventListener('ended', () => {
        count -= 1;
        if (count > 0) {
            setTimeout(() => {
                aduio.play();
            }, 400)
        }
    })
}
