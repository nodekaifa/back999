import cn from './locales/cn'
import tw from './locales/tw'
import en from './locales/en'
import af from './locales/af'
import ar from './locales/ar'
import el from './locales/el'
import es from './locales/es'
import fr from './locales/fr'
import it from './locales/it'
import ja from './locales/ja'
import ko from './locales/ko'
import ms from './locales/ms'
import pt from './locales/pt'
import ru from './locales/ru'
import th from './locales/th'
import tr from './locales/tr'
import de from './locales/de'
import ph from './locales/fil'
import id from './locales/id'
import inLang from './locales/in'
import vn from './locales/vn'

const lanuages = {
    ar,
    cn,
    tw,
    en,
    af,
    el,
    es,
    fr,
    it,
    ja,
    ko,
    ms,
    pt,
    ru,
    th,
    tr,
    de,
    ph,
    'in': inLang,
    id,
    vn
}

export default lanuages;

export type LangType =
    "cn" |
    "tw" |
    "en" |
    "af" |
    "el" |
    "es" |
    "fr" |
    "it" |
    "ja" |
    "ko" |
    "ms" |
    "pt" |
    "ru" |
    "th" |
    "tr" |
    "de" |
    'ph' |
    "ar" |
    'in' |
    'id' |
    'vn'

export const $t = (key: any) => {

    let langType: any = sessionStorage.getItem('im_lang') || "en"
    if (langType === 'undefined') {
        console.log('----------')
        langType = 'ar';
    }
    if (['ar'].includes(langType)) {
        document.body.style.direction = 'rtl';
    }
    //@ts-ignore
    return lanuages[langType][key] || key;
}
