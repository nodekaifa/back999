import {getCurrentInstance} from 'vue';
import {ElMessage} from 'element-plus';
import dayjs from 'dayjs';
import lang, {LangType} from './lang';

export const base = process.env.NODE_ENV === "development" ? "/" : "/chat/";

export function showMessage(message: string, type: 'success' | 'warning' | 'info' | 'error', duration = 3000) {
    ElMessage.closeAll();
    ElMessage({
        message,
        type,
        duration
    }, getCurrentInstance()?.appContext);
}

export const calculateTime = (langStr: LangType, date?: string) => {
    const dayTime = dayjs(date);
    const time = dayTime.format('HH:mm');
    if (dayTime.isToday()) {
        return time;
    } else if (dayTime.isYesterday()) {
        return `${lang[langStr]['yesterday']} ${time}`;
    } else {
        return dayTime.format('YYYY-MM-DD HH:mm');
    }
};

export const getUrlVal: (name: string) => LangType = (name: string) => {
    let url = location.href;
    let urlStr = url?.split('?')[1];
    let obj: any = {};
    let paramsArr = urlStr?.split('&');
    if (paramsArr) {
        for (let i = 0, len = paramsArr.length; i < len; i++) {
            let arr = paramsArr[i].split('=');
            obj[arr[0]] = arr[1];
        }
    }
    return obj[name];
};

function getRandomInt(max: number) {
    return Math.floor(Math.random() * max);
}

const cache: { [key: string]: number } = JSON.parse(localStorage.getItem('head_cache') || "{}");

function getAvatarUrl(avatarStr?: string) {
    if (avatarStr && isUrl(avatarStr)) {
        return avatarStr;
    } else if (avatarStr) {
        return `${base}${avatarStr}.png`;
    } else {
        return '';
    }
}

export function isUrl(str: string) {
    try {
        const url = new URL(str);
        return true;
    } catch (error) {
        return false;
    }
}

export function getContactAvatar(contact?: Contacts) {
    const avatarStr = sessionStorage.getItem('type') === 'user' ? contact?.avatar : contact?.useravatar;
    const contactId = contact?.id ?? 'contact_Id';
    return getAvatarUrl(avatarStr) || getSelfAvatar(contactId);
}

export function getSelfAvatar(contactId: string, avatarStr?: string,) {
    if (avatarStr && isUrl(avatarStr)) {
        return avatarStr
    } else if (avatarStr) {
        return `${base}${avatarStr}.png`
    } else {
        if (!cache[contactId]) {
            cache[contactId] = getRandomInt(20)
            localStorage.setItem('head_cache', JSON.stringify(cache))
        }
        return `${base}${cache[contactId]}.png`
    }
}

/**
 * 数字千位符格式化
 * eg:
 * 17267737 -> 17,267,737
 */
export const numberFormat = (num: number) => {
    if (num && Number(num)) {
        const numStr = TtoFixed(num, 2);
        const numPre = numStr.slice(0, numStr.indexOf('.'));
        const numRi = numStr.slice(numStr.indexOf('.') + 1);
        const intStr = numPre.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
        const floatStr = numRi ? `.${numRi.length < 2 ? numRi + '0' : numRi}` : '.00';
        return `${intStr}${floatStr}`;
    } else {
        return 0;
    }
};

const TtoFixed = (num: any, decimal: any) => {
    num = num.toString();
    let index = num.indexOf('.');
    if (index !== -1) {
        num = num.substring(0, decimal + index + 1);
    } else {
        num = num.substring(0);
    }
    return parseFloat(num).toFixed(decimal);
};

export const formeateUser = (name: string) => {
    let evntShort: string;

    if (name && name.length > 0) {
        evntShort = name.substring(0, 2);
    } else {
        evntShort = name;
    }

    if (/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(name)) {
        const split = name.split('@');
        return `${evntShort}***@${split[1]} `;
    } else if (/^-?\d+$/.test(name) && name.length > 3) {
        return `${name.substring(0, 2)}***${name.substring(3, name.length - 1)}`;
    }

    // console.log(name)
    return name;
};

// formeateUser('magio.add@gg.com');
