import { $t } from '@/utils/lang';
import dayjs from 'dayjs';


/**
* 仿照微信中的消息时间显示逻辑，将时间戳（单位：毫秒）转换为友好的显示格式.
*
* 1）7天之内的日期显示逻辑是：今天、昨天(-1d)、前天(-2d)、星期？（只显示总计7天之内的星期数，即<=-4d）；
* 2）7天之外（即>7天）的逻辑：直接显示完整日期时间。
*
* @param  {[long]} timestamp 时间戳（单位：毫秒），形如：1550789954260
* @param {boolean} mustIncludeTime true表示输出的格式里一定会包含“时间:分钟”
* ，否则不包含（参考微信，不包含时分的情况，用于首页“消息”中显示时）
*
* @return {string} 输出格式形如：“刚刚”、“10:30”、“昨天 12:04”、“前天 20:51”、“星期二”、“2019/2/21 12:09”等形式
* @since 1.1
*/
export const shourtTimeString = (date: string) => {

    const dateTime = dayjs(date);
    const diffMinute = (dayjs().unix() - dateTime.unix()) / 60;
    const diffDays = Math.floor(diffMinute / (60 * 24))
    // const utcDay = dateTime.utc().tz();
    if (diffDays === 0) {
        if (diffMinute < 5) {
            return $t('just')
        }
        return dateTime.format('HH:mm');
    } else if (diffDays === 1) {
        return $t('yesterday');
    } else if (diffDays === 2) {
        return $t('beforeYesterday');
    } else if (diffDays >= 3 && diffDays <= 6) {
        const weeks = [
            $t('sunday'),
            $t('monday'),
            $t('tuesday'),
            $t('wednesday'),
            $t('thursday'),
            $t('friday'),
            $t('saturday'),
        ]
        return weeks[dateTime.day()]
    }

    return dateTime.format('MM-DD')

}