const headIcon = {
    "E-Shop": {
        title: "E-SHOP",
        icon: "eshop.png",
        barIcon: "eshop.png"
    },
    Argos: {
        title: "Argos",
        icon: 'argos.png',
        barIcon: 'alogo.png'
    },
    Inchoi: {
        title: "Inchoi",
        icon: "inchoi.png",
        barIcon: 'ilogo.png'

    },
    Mbuy: {
        title: "Mbuy",
        icon: "mbuy.png",
        barIcon: 'mlogo.png'
    },
    Matashop: {
        title: "Matashop",
        icon: 'mateshop.svg',
        barIcon: 'mateshop.svg'
    },
    // Tongda: {
    //     title: "Tongda",
    //     icon: 'tongda.png',
    //     barIcon: {
    //         blue: 'tongda_blue_bar.png',
    //         yellow: 'tongda_yellow_bar.png'
    //     }
    // },
    HIVE: {
        title: 'HIVE',
        icon: 'hive_ico.ico',
        barIcon: 'hive_bar.png'
    },
    FamilyMart: {
        title: 'FamilyMart',
        icon: 'family_mart_logo.svg',
        barIcon: 'famliy_mart_bar.svg'
    },
    FamilyShop: {
        title: 'FamilyShop',
        icon: 'famliy_shop.svg',
        barIcon: 'famliy_shop_bar.svg'
    },
    TikTokMall: {
        title: 'TikTokMall',
        icon: 'titok_icon.ico',
        barIcon:'titok_bar.png'
    },
    // Shopee:{
    //      title:'Shopee',
    //      icon:'shopee_icon.ico',
    //      barIcon:'shopee_title_bar.svg'
    // },
    Shop2U:{
        title:'Shop2U',
        icon: 'shop2u_ico.ico',
        barIcon:'shop2u_bar.png'
    },
    GreenMall:{
        title:'GreenMall',
        icon: 'green_mall_favicon.ico',
        barIcon:'green_mall.svg'
    },
    JustShop:{
        title:'JustShop',
        icon: 'justshop.ico',
        barIcon:'justshop.svg'
    },
    LazShop:{
        title:'LazShop',
        icon: 'laz_ico.ico',
        barIcon:'laz_bar.png'
    },
    Iceland:{
        title:'Iceland',
        icon: 'iceland.ico',
        barIcon:'iceland.svg'
    },
    INT:{
        title:'INT',
        icon: 'int.ico',
        barIcon:'int.svg'
    },
    TikTokWholesale:{
        title:'TikTok-Wholesale',
        icon: 'tiktok_wholesale.ico',
        barIcon:'tiktok_wholesale.svg'
    },
    Wholesale:{
        title:'Wholesale Shop',
        icon: 'wholesale.ico',
        barIcon:'wholesale.svg'
    }
}

type HeadType = keyof typeof headIcon

const key: HeadType = import.meta.env.VITE_APP_TITLE;



export const headEnv = headIcon[key]

