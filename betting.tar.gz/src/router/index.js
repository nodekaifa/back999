import { createRouter, createWebHashHistory } from "vue-router";

const routes = [
  {
    path: "/",
    name: "home-view",
    component: () =>
        import(/* webpackChunkName: "about" */ "../views/GoodsView.vue"),
  },
  {
    path: "/pos-history",
    name: "Pos-History",
    component: () =>
        import(/* webpackChunkName: "about" */ "../views/PostOrderList.vue"),
  },
  {
    path: '/edit-commodity',
    component: () => import('@/views/EditCommodity/EditCommodity')
  },
  {
    path: '/list-commodity',
    component: () => import('@/views/list-commodity/ListCommodity.vue')
  },
  {
    path: '/test-sku',
    component: () => import('@/views/testSku.vue')
  },
  {
    path: '/commodity-library',
    component: () => import('@/views/CommodityLibrary/CommodityLibrary'),
    meta: {
      keepAlive: true
    }
  },
  {
    path: '/comment',
    component: () => import('@/views/Comment/Comment')
  },
  {
    path: '/member-comments',
    component: () => import('@/views/MemberComments/MemberComments')
  },
  {
    path:'/test-form',
    component: () => import('@/views/TestForm.vue')
  }
  // {
  //   path: "/",
  //   name: "home",
  //   redirect: "/home",
  //   component: () =>
  //     import(/* webpackChunkName: "about" */ "../views/MainView.vue"),
  //   children: [
  //     {
  //       path: "/home",
  //       name: "home-view",
  //       component: () =>
  //           import(/* webpackChunkName: "about" */ "../views/GoodsView.vue"),
  //     },
  //     {
  //       path: "/pos-history",
  //       name: "Pos-History",
  //       component: () =>
  //           import(/* webpackChunkName: "about" */ "../views/PostOrderList.vue"),
  //     }
  //   ],
  // },

  // {
  //   path: "/about",
  //   name: "about",
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () =>
  //     import(/* webpackChunkName: "about" */ "../views/AboutView.vue"),
  // },
];

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes,
});

export default router;
