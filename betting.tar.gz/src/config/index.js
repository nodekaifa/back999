// 本地测试跨域
let baseUrl = '';
let baseUrl2 = JSON.parse(localStorage.getItem('baseUrl2') || '{}').baseUrl2 || ''
let baseUrl3 = ''; // 商品上传图片专用
if (process.env.NODE_ENV === 'development') {
    baseUrl = 'https://thsjbvh.site' // pos 和 日志接口 https://tool.thsjbvh.site
    // http://e68v79.natappfree.cc//admin_war_exploded/systemGoods/listSystemComment.action?pageNum=1&pageSize=20&status=1
    // http://ss7gt9.natappfree.cc/admin_war_exploded/systemGoods/listSystemComment.action

    // baseUrl2 = 'http://qgekpj.natappfree.cc/admin_war_exploded' // http://y6r76u.natappfree.cc/admin_war_exploded

    // baseUrl2 = 'https://qfushj.site/9287422421' // http://qgekpj.natappfree.cc/admin_war_exploded // ml.thsjbvh.site/894732342 演示环境 // thsjbvh.site/594732342 测试环境 // http://30q4ur0n6b41.ngrok.xiaomiqiu123.top

    // baseUrl2 = 'http://30q4ur0n6b41.ngrok.xiaomiqiu123.top'
    // baseUrl2 = 'https://ml.thsjbvh.site/894732342' // 演示
    baseUrl2 = 'https://thsjbvh.site/594732342' // 测试
    localStorage.setItem('baseUrl2', JSON.stringify({baseUrl2}))
    baseUrl3 = 'https://thsjbvh.site'
} else {
    if (!baseUrl2) {
        const url = window.location.href.split('url=')[1]
        if (url) {
            baseUrl2 = url // 如果地址中带着url参数，就用url参数
        } else {
            baseUrl2 = 'https://thsjbvh.site/594732342' // 测试网 594732342  ArgosShop 9287422421
        }
        localStorage.setItem('baseUrl2', JSON.stringify({baseUrl2}))
    }
}

function deepClone(obj) {
    // 如果是基本类型，直接返回
    if (typeof obj !== 'object' || obj === null) {
        return obj;
    }

    // 如果是日期类型，返回日期对象的副本
    if (obj instanceof Date) {
        return new Date(obj.getTime());
    }

    // 如果是正则表达式类型，返回正则表达式对象的副本
    if (obj instanceof RegExp) {
        return new RegExp(obj);
    }

    // 如果是函数类型，返回函数对象的副本
    if (typeof obj === 'function') {
        return new Function('return ' + obj.toString())();
    }

    // 如果是对象类型，递归遍历属性并进行深拷贝
    const newObj = new obj.constructor();
    for (const key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
            newObj[key] = deepClone(obj[key]);
        }
    }
    return newObj;
}

export {
    deepClone,
    baseUrl,
    baseUrl3,
    baseUrl2 // 商品属性专用
}
