// 中文简体(cn)
// 中文繁体(tw)
// 英语(en)
// 德语(de)
// 法语(fr)
// 日语(ja)
// 韩语(ko)
// 马来西亚语(ms)
// 泰国语(th)
// 葡萄牙语(pt)
// 西班牙语(es)
// 俄语(ru)
// 希腊语(el)
// 意大利语(it)
// 土耳其语(tr)
// 南非荷兰语(af)


export default [
  {key: 'English', value: 'en', src:require('@/assets/nation/en.png')},
  {key: '中文', value: 'cn',src:require('@/assets/nation/cn.png')},
  {key: '中文繁體', value: 'tw',src:require('@/assets/nation/tw.png')},
  {key: 'Deutsch', value: 'de',src:require('@/assets/nation/de.png')},
  {key: 'Français', value: 'fr',src:require('@/assets/nation/cn.png')},
  {key: '日本', value: 'ja',src:require('@/assets/nation/ja.png')},
  {key: '한국인', value: 'ko',src:require('@/assets/nation/ja.png')},
  {key: 'Malaysian', value: 'ma',src:require('@/assets/nation/ma.png')},
  {key: 'ภาษาไทย', value: 'th',src:require('@/assets/nation/th.png')},
  {key: 'Português', value: 'pt',src:require('@/assets/nation/pt.png')},
  {key: 'espanhol', value: 'es',src:require('@/assets/nation/es.png')},
  {key: 'Русский', value: 'ru',src:require('@/assets/nation/ru.png')},
  {key: 'Ελληνικά', value: 'el',src:require('@/assets/nation/el.png')},
  {key: 'italiano', value: 'it',src:require('@/assets/nation/it.png')},
  {key: 'Türkçe', value: 'tr',src:require('@/assets/nation/tr.png')},
  {key: 'Afrikaans', value: 'af',src:require('@/assets/nation/af.png')},
]