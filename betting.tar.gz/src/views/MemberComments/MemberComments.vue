<template>
  <div class="commodity-library">
    <el-button style="margin-bottom: 10px" type="primary" @click="router.go(-1)">返回</el-button>
    <div class="select-wrapper">
      <el-form class="flex mt-10" label-width="120px">
        <el-form-item label="会员账号：">
          <el-input v-model="info.user" placeholder="会员账号"/>
        </el-form-item>
        <el-form-item label="账号类型：">
          <el-select v-model="info.accountType" class="m-2" placeholder="账号类型">
            <el-option
                v-for="item in statusOption"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="评分：">
          <el-select v-model="info.evaluationType" class="m-2" placeholder="评价">
            <el-option
                v-for="item in comment"
                :key="item.label"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <div style="padding: 5px">
            <el-button type="primary" @click="handleSelect" :loading="selectLoading">查询</el-button>
          </div>
          <div style="padding: 5px">
            <el-button type="primary" @click="handleReset">重置</el-button>
          </div>
        </el-form-item>

      </el-form>
    </div>
    <!--    <div class="my-30">-->
    <!--      <el-button type="primary" @click="addComment">新增评论</el-button>-->
    <!--      <el-button type="danger" style="margin-left: 12px">批量删除</el-button>-->
    <!--    </div>-->
    <div class="my-20">
      <el-button class="mr-15" type="primary" @click="dialogVisible2 = true">一键修改评论时间</el-button>
      <!--      <el-button type="primary" @click="dialogVisible3 = true">新增评论</el-button>-->
    </div>
    <div class="result">
      <div class="font-14">查询结果</div>
      <el-table v-loading="dataLoading" class="mt-15" @selection-change="handleSelectionChange" :data="table" border
                style="width: 100%">
        <el-table-column type="selection" width="55"/>
        <el-table-column prop="userName" label="会员账号" width="260"/>
        <el-table-column label="账号类型" width="100">
          <template #default="scope">
<!--            <el-tag v-if="scope.row.accountType / 1 === 1">全部账号</el-tag>-->

            <el-tag v-if="scope.row.accountType / 1 === 1">正式账号</el-tag>
            <el-tag v-if="scope.row.accountType / 1 === 2" type="warning">演示账号</el-tag>


          </template>
        </el-table-column>
        <el-table-column label="评价" width="80">
          <template #default="scope">
            <el-tag v-if="scope.row.evaluationType / 1 === 1">好评</el-tag>
            <el-tag v-else-if="scope.row.evaluationType / 1 === 2" type="warning">中评</el-tag>
            <el-tag v-else type="danger">差评</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="rating" label="评分" width="80"/>
        <el-table-column prop="sellerName" label="所在店铺"/>
        <el-table-column label="评价内容" min-width="600">
          <template #default="scope">
            <div style="max-height: 200px; overflow: auto">{{ scope.row.content }}</div>
          </template>
        </el-table-column>
        <el-table-column label="评价时间" width="180">
          <template v-slot="scope">
            {{ scope.row.commentTime }}
          </template>
        </el-table-column>
        <el-table-column label="前端展示" width="100">
          <template #default="scope">
            <el-switch
                v-model="scope.row.status"
                :active-value="0"
                :inactive-value="1"
                @change="handleChangeStatus(scope.row.id, $event)"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180">
          <template #default="scope">
            <div class="flex justify-between">
              <el-button @click="viewComments(scope.row)">查看评价</el-button>
              <el-button type="danger" @click="open(scope.row.id)">删除</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="flex justify-center mt-40">
      <el-config-provider :locale="zhCn">
        <el-pagination
            v-model:current-page="currentPage"
            v-model:page-size="pageSize"
            :page-sizes="[10, 20, 30, 50]"
            background
            layout="total, prev, pager, next"
            :total="total"
            @current-change="handleChangePage"
        />
      </el-config-provider>
    </div>
  </div>
  <!-- 评论详情 -->
  <el-dialog
      :show-close="false"
      v-model="dialogVisible"
      title="用户评价详情"
      width="40%"
      :before-close="handleClose"
  >
    <div v-if="Object.keys(currentComment).length > 0">
      <div class="font-16">店铺信息</div>
      <div class="flex">
        <div class="flex-1 message-info">
          <div>店铺名称：{{ currentComment.sellerName }}</div>
          <div>订单标号：{{ currentComment.orderId }}</div>
          <div>商品名称：{{ currentComment.goodsVo.name }}</div>
        </div>
        <div class="logo flex justify-center items-center">logo</div>
      </div>
    </div>
    <div class="user-comment">
      <div class="mb-20 font-16">用户评价</div>
      <div>{{ currentComment.userName }}</div>
      <div class="comment-content">{{ currentComment.content || '无' }}</div>
      <div class="comment-img-wrapper" v-if="currentComment.imgList.length > 0">
        <div
            class="img-wrapper"
            v-for="(src) in currentComment.imgList"
            :key="src"
        >
          <div class="view" @click="handlePictureCardPreview(src)">
            <span class="el-upload-list__item-preview" >
              <el-icon style="font-size: 26px"><zoom-in style="color: #fff"/></el-icon>
            </span>
          </div>
          <el-image
              :src="src"
              :fit="'cover'"/>
        </div>
      </div>
    </div>
    <template #footer>
      <div class="flex justify-between">
        <el-form-item label="前端展示：">
          <el-switch
              v-model="currentComment.status"
              :active-value="0"
              :inactive-value="1"
              @change="handleChangeStatus(currentComment.id, currentComment.status)"
          />
        </el-form-item>
        <div>

          <el-button type="primary" @click="dialogVisible = false">
            {{ $t('确定') }}
          </el-button>
          <el-button style="margin-left: 12px" @click="dialogVisible = false">{{ $t('取消') }}</el-button>
        </div>
      </div>
    </template>
  </el-dialog>

  <!-- 一键修改评论时间 -->
  <el-dialog
      :show-close="false"
      v-model="dialogVisible2"
      title="一键修改评论时间"
      width="30%"
  >
    <el-form :model="form" :rules="formRules" ref="changeTimeForm">
      <el-form-item label="选择店铺">
        <el-select v-model="form.sellerId" filterable class="flex-1" placeholder="请选择店铺">
          <el-option
              v-for="item in selList"
              :key="item.sellerId"
              :label="item.sellerName"
              :value="item.sellerId"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="开始时间">
        <el-date-picker
            class="flex-1"
            v-model="form.fromTime"
            type="datetime"
            value-format="YYYY-MM-DD HH:mm:ss"
            placeholder="选择开始时间"
        />
      </el-form-item>
      <el-form-item label="结束时间">
        <el-date-picker
            class="flex-1"
            v-model="form.toTime"
            type="datetime"
            value-format="YYYY-MM-DD HH:mm:ss"
            placeholder="选择结束时间"
        />
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="flex justify-end">
        <!--        @click="dialogVisible2 = false"-->
        <el-button type="primary" @click="submitForm(changeTimeForm,'change')">
          {{ $t('确定') }}
        </el-button>
        <el-button style="margin-left: 12px" @click="cancel(changeTimeForm, 'change')">{{ $t('取消') }}</el-button>
      </div>
    </template>
  </el-dialog>

  <!-- 新增评论 -->
  <el-dialog
      :show-close="false"
      v-model="dialogVisible3"
      title="新增评论"
      width="40%"
  >
    <el-form
        ref="ruleFormRef"
        :model="addInfo"
        :rules="rules"
        label-width="140"
    >
      <el-form-item class="img-upload" label="用户账号" prop="content">
        <el-input
            disabled
            :model-value="addInfo.userName"
            placeholder="用户账号"
        />
      </el-form-item>
      <el-form-item class="img-upload" label="`评分" prop="rating">
        <el-input type="number" v-model="addInfo.rating" placeholder="请输入1-5分" min="1" max="5">
          <template #suffix>
            <span style="color: #333">{{ $t('分') }}</span>
          </template>
        </el-input>
      </el-form-item>
      <el-form-item class="img-upload" label="商品所属商户id" prop="score">
        <el-input
            disabled
            :model-value="addInfo.sellerId"
            placeholder="商品所属商户id"
        />
      </el-form-item>
      <el-form-item class="img-upload" label="商品id" prop="score">
        <el-input
            disabled
            :model-value="addInfo.sellerGoodsId"
            placeholder="商品id"
        />
      </el-form-item>
      <el-form-item class="img-upload" label="评价内容" prop="content">
        <el-input
            v-model="addInfo.content"
            :autosize="{ minRows: 2, maxRows: 4 }"
            type="textarea"
            placeholder="评价内容"
        />
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="submitForm(ruleFormRef,'add')">
          {{ $t('确定') }}
        </el-button>
                <el-button style="margin-left: 12px" @click="cancel(ruleFormRef,'add')">{{ $t('取消') }}</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 放大图片 -->
  <el-dialog v-model="showImg" width="30%">
    <img style="width: 100%" :src="dialogImageUrl" alt="Preview Image"/>
  </el-dialog>
</template>

<script setup>
import dayjs from 'dayjs'
import {useRouter,useRoute} from "vue-router";
import {ElMessage, ElMessageBox} from 'element-plus'
import {reactive, ref} from 'vue'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {baseUrl2, baseUrl3} from "@/config";
import axios from "axios";
import {ZoomIn} from '@element-plus/icons-vue';

// eslint-disable-next-line
const router = useRouter()

const route = useRoute()

const id = route.query.id;
console.log(id);

const comment = ref([
  {
    value: '',
    label: '全部',
  },
  {
    value: '1',
    label: '好评',
  },
  {
    value: '2',
    label: '全部',
  },
  {
    value: '3',
    label: '差评',
  },
])


const statusOption = ref([
  {
    value: '',
    label: '全部',
  },
  {
    value: '1',
    label: '正式账号',
  },
  {
    value: '2',
    label: '演示账号',
  },
])

const info = ref({
  user: '',
  accountType: '',
  evaluationType: '',
})

const handleSelectionChange = (a) => {
  console.log(a);
}

// 评论详情
const dialogVisible = ref(false)
const handleClose = () => {

}

/**
 * 重置
 */
const handleReset = () => {
  // eslint-disable-next-line
  Object.keys(info.value).forEach(key => {
    info.value[key] = ''
  })
}

// 页码
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)

/**
 * 请求数据
 */
const table = ref([])
const dataLoading = ref(false)
// eslint-disable-next-line
const getData = () => {
  dataLoading.value = true
  // eslint-disable-next-line
  const params = {
    systemGoodsId: id,
    username: info.value.user,
    accountType: info.value.accountType,
    evaluationType: info.value.evaluationType,
    pageNo: currentPage.value,
    pageSize: pageSize.value,
  }

  axios({
    method: "get",
    url: `${baseUrl2}/systemGoods/evaluation/list.action`,
    params,
  }).then((res) => {

    dataLoading.value = false;
    console.log('获取数据', res.data.data)

    table.value = res.data.data.elements

    table.value.forEach(item => {
      console.log(typeof item.status)
    })

    currentPage.value = res.data.data.thisPageNumber
    pageSize.value = res.data.data.pageSize
    total.value = res.data.data.totalElements
  })
}
getData()

const handleChangePage = () => {
  getData();
}

/**
 * 查询
 */
const selectLoading = ref(false);

const handleSelect = () => {
  getData()
}

/**
 * 删除评论
 */
const open = (id) => {
  ElMessageBox.confirm(
      '你确定要删除吗?',
      '警告',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
  )
      .then(() => {
        _deleteGood(id).then(res => {
          console.log(res)

          ElMessage({
            type: 'success',
            message: '删除成功',
          })
        })

      })
      .catch(() => {
        ElMessage({
          type: 'info',
          message: '取消删除',
        })
      })
}

const _deleteGood = (id) => {
  return axios({
    method: "post",
    url: `${baseUrl2}/systemGoods/evaluation/hide.action?id=${id}`,
  })
}

/**
 * 一键修改评论时间
 */
const changeTimeForm = ref(null)
const dialogVisible2 = ref(false)

const form = ref({
  sellerId: '',
  fromTime: '',
  toTime: '',
})

const formRules = reactive({
  sellerId: [
    {
      required: true,
      message: '请选择店铺',
      trigger: 'blur',
    },
  ],
  fromTime: [
    {
      required: true,
      message: '请选择开始时间',
      trigger: 'blur',
    },
  ],
  toTime: [
    {
      required: true,
      message: '请选择开始时间',
      trigger: 'blur',
    },
  ],
})

const changeTime = () => {
  if (dayjs(form.value.fromTime).unix() > dayjs(form.value.toTime).unix()) {
    ElMessage({
      message: '开始时间不能大于结束时间！',
      type: 'error',
    })

    form.value.fromTime = ''
    form.value.toTime = ''

    return
  }

  // eslint-disable-next-line
  const data = new FormData()

  Object.keys(form.value).forEach((key) => {
    data.append(key, form.value[key])

  })
  axios({
    method: 'post',
    url: `${baseUrl2}/systemGoods/evaluation/changeTime.action?`,
    data,
  }).then(res => {
    if (res.data.code == 0) {
      ElMessage({
        message: '修改成功',
        type: 'success',
      })

    }
    dialogVisible2.value = false;

    Object.keys(form.value).forEach(key => {
      form.value[key] = ''
    })

    getData()
  })
}

/**
 * 新增评论
 */
const dialogVisible3 = ref(false)
const ruleFormRef = ref(null)
const addInfo = reactive({
  userName: '',
  rating: '',
  sellerId: '',
  content: '',
  sellerGoodsId: ''
})

const validateNum = (rule, value, callback) => {
  console.log(rule)

  if (value / 1 > 5 || value / 1 < 1 || value.indexOf('.') !== -1) {
    callback(new Error('请输入1-5分, 不能有小数'))
  } else {
    callback()
  }
}

const rules = reactive({
  rating: [
    {required: true, validator: validateNum, trigger: 'blur'}
  ],
  content: [
    {
      required: true,
      message: '请输入评论内容',
      trigger: 'change',
    },
  ],
  userName: [
    {
      required: true,
      type: 'date',
      message: '请输入用户账号',
      trigger: 'change',
    },
  ],
  sellerId: [
    {
      type: 'date',
      required: true,
      message: '请输入商品所属商户id',
      trigger: 'blur',
    },
  ],
  sellerGoodsId: [
    {
      type: 'date',
      required: true,
      message: '请输入商品id',
      trigger: 'blur',
    },
  ],
})

//提交
const submitForm = async (formEl, type) => {
  if (!formEl) return
  await formEl.validate((valid, fields) => {
    if (valid) {
      console.log('submit!')
      // addComment()
    } else {
      console.log('error submit!', fields)
    }
  })


  if (type === 'change') { // 修改时间
    changeTime()
  } else if (type === 'add') {
    console.log(addInfo);
  }

  // resetForm(formEl)
}

// 取消
const cancel = (formEl, type) => {
  if (type === 'change') { // 修改时间
    dialogVisible2.value = false
    console.log(form)
  } else if (type === 'add') {
    console.log(addInfo);
    dialogVisible3.value = false
  }

  resetForm(formEl)
}

// 重置表单验证
const resetForm = (formEl) => {
  if (!formEl) return
  formEl.resetFields()
}

/**
 * 修改评论显示状态
 */
const handleChangeStatus = async (id, val) => {
  dataLoading.value = true
  let res;
  if (val) { // 隐藏
    await hideComment(id)
    res = 1
  } else { // 显示
    await showComment(id)
    res = 0;
  }

  dataLoading.value = false;

  const index = table.value.findIndex(item => item.id === id)
  table.value[index].status = res;

  ElMessage({
    message: '修改成功',
    type: 'success',
  })
}

const hideComment = (id) => {
  const formData = new FormData()

  formData.append('id', id)
  return axios({
    method: "post",
    url: `${baseUrl2}/systemGoods/evaluation/hide.action`,
    data: formData
  })
}

const showComment = (id) => {
  const formData = new FormData()

  formData.append('id', id)
  return axios({
    method: "post",
    url: `${baseUrl2}/systemGoods/evaluation/open.action`,
    data: formData
  })
}

/**
 * 查看评论
 */
const currentComment = ref({});
const viewComments = (data) => {
  data.imgList = [];
  Object.keys(data).forEach(key => {
    if (key.indexOf('imgUrl') !== -1) {
      if (data[key]) {
        console.log(data[key]);
        data.imgList.push(data[key])
      }
    }
  })

  dialogVisible.value = true;

  currentComment.value = data;
  console.log(currentComment.value);
}

/**
 * 放大图片
 */
const dialogImageUrl = ref('')
const showImg = ref(false);

// eslint-disable-next-line
const handlePictureCardPreview = (src) => {
  dialogImageUrl.value = src
  showImg.value = true
}

/**
 * 获取所有商家
 */
const selOptions = ref([]);
const selList = ref([]);
const getAllShop = () => {
  axios({
    method: "post",
    url: `${baseUrl3}/api/item/findSellerList`,
  }).then(function (res) {
    console.log('卖家', res.data.data)
    selOptions.value = res.data.data;
    selList.value = selOptions.value;
  });
};

getAllShop();
</script>

<style lang="scss" scoped>
@import "@/style/commodity-library.scss";

:deep(.el-table th .cell) {
  text-align: center;
}

:deep(.el-button+.el-button) {
  margin-left: 0;
}

:deep(.el-form-item) {
  align-items: center;

}

.result {
  margin-top: 30px;
}

.logo {
  width: 80px;
  height: 80px;
  margin-left: 50px;
  border-radius: 50%;
  border: 1px solid #ccc;
}

.message-info {
  margin-top: 6px;
  font-size: 14px;
  line-height: 26px;
}

.user-comment {
  margin-top: 30px;
}

.comment-content {
  margin: 15px 0;
  padding: 14px;
  background-color: #ddd;
  border-radius: 6px;
}

.comment-img-wrapper {
  display: grid;
  flex-wrap: wrap;
  justify-content: space-between;
  grid-template-columns: repeat(auto-fill, 150px);
  gap: 14px;

  .img-wrapper {
    position: relative;

    &:hover {
      .view {
        opacity: 1;
      }
    }

    .view {
      opacity: 0;
      transition: ease .5s;
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9;
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      background: rgba(0,0,0,.4);
    }
  }

  :deep(.el-image) {
    min-width: 150px;
    min-height: 150px;
  }

}

:deep(.el-form-item.img-upload) {
  align-items: start;
}
</style>
