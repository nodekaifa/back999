<template>
  <div class="order-list">
    <el-table :data="tableData" style="width: 100%; height: 100%;">
      <el-table-column prop="id" label="订单号" />
      <el-table-column prop="contacts" label="收货人" />
      <el-table-column prop="sellerName" label="下单店铺" />
      <el-table-column prop="createTime" label="下单时间" />
    </el-table>
    <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :page-sizes="[10, 20, 30, 50]"
        :small="small"
        :background="background"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
    />
  </div>
</template>

<script setup>
import {ref, onMounted} from "vue";
import axios from "axios";
import {baseUrl} from "@/config";
let tableData = ref([])
let currentPage = ref(1);
let pageSize = ref(8);
let total = ref(0);
const small = ref(false)
const background = ref(false)
onMounted(() => {
  getTabelList()
});
// eslint-disable-next-line no-undef
const props = defineProps({
  id: String
})
const getTabelList = () => {
  const id = props.id;
  axios({
    url: `${baseUrl}/api/orderRecord/details/orderedList`,
    method: "post",
    params: {
      id,
    }
  }).then((res) => {
    if (res.status == 200) {
      const data = res.data;
      tableData.value = data.data;
      total.value = data.data.length;
    }
  })
}
const handleSizeChange = (val) => {
  console.log(`${val} items per page`)
}
const handleCurrentChange = (val) => {
  console.log(`current page: ${val}`)
}
</script>
