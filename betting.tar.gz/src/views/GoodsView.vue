<template>
    <div class="goods">
        <div class="goods-left">
            <div class="goods__select">
                <div class="name">{{ $t('查询条件') }}</div>
                <div class="select">
                    <el-input
                            style="width: 220px; display: inline"
                            v-model="input"
                            :placeholder="$t('请输入关键字')"
                    />

                    <el-input style="width: 220px; display: inline;padding: 0 10px"
                              v-model="sellerId"
                              :placeholder="$t('请输入卖家id')"></el-input>

                    <el-select
                            v-model="sel"
                            filterable
                            remote
                            reserve-keyword
                            remote-show-suffix
                            :remote-method="sellerRemoteMethod"
                            :loading="sellerLoading"
                            class="m-2"
                            style="padding: 0 10px"
                            :placeholder="$t('请选择卖家类型')"
                    >
                        <el-option
                                v-for="item in selList"
                                :key="item.sellerId"
                                :label="item.sellerName"
                                :value="item.sellerId"
                        />
                    </el-select>
                    <el-select v-model="kind" class="m-2" :placeholder="$t('请选择分类类型')">
                        <el-option
                                v-for="item in kindOptions"
                                :key="item.categoryId"
                                :label="item.categoryName"
                                :value="item.categoryId"
                        />
                    </el-select>
                    <!--          <el-select-->
                    <!--              v-model="type"-->
                    <!--              class="m-2"-->
                    <!--              style="padding: 0 10px"-->
                    <!--              placeholder="请选择类型"-->
                    <!--          >-->
                    <!--            <el-option-->
                    <!--                v-for="item in typeOptions"-->
                    <!--                :key="item"-->
                    <!--                :label="item"-->
                    <!--                :value="item"-->
                    <!--            />-->
                    <!--          </el-select>-->
                </div>
            </div>
            <div class="goods__main">
                <div class="main">
                    <div
                            class="main-list"
                            v-for="(item, index) in goodsList"
                            :key="index"
                    >
                        <div class="img" style="cursor: pointer" @click="openSelectGoodsOptions(item)">
                            <img :src="item.imgUrl" alt=""/>

                            <div
                                    href="javascript:void(0)"
                                    class="modal"
                                    style="text-decoration: none"
                            >
                                <div class="content">
                                    <el-icon class="icon" style="">
                                        <CirclePlus/>
                                    </el-icon>
                                    <div class="add">{{ $t('添加') }}</div>
                                </div>
                            </div>
                        </div>
                        <div class="title">{{ item.goodsName }}</div>
                        <div class="price">${{ item.sellingPrice.toFixed(2) }}</div>
                        <!--属性选择弹窗-->
                        <el-dialog
                                style="margin-top: auto!important;"
                                align-center
                                :modal="false"
                                :show-close="false"
                                :close-on-click-modal="false"
                                v-model="showModal"
                                :title="$t('商品属性')">
                            <div class="attributes">
                                <div class="wrap" v-for="(item, index) in attributes.data.attrsValuesVos"
                                     :key="'attributes' + index">
                                    <div class="title2">{{ item.attrName }}</div>
                                    <div class="details">
                                        <el-button @click="handleSelect(item,index, item2, index2)"
                                                   v-for="(item2, index2) in item.attrValues"
                                                   :class="{'active': index2 === item.active}" class="btn"
                                                   :key="'attributes2' + index2">
                                            {{ item2.attrValueName }}
                                        </el-button>
                                    </div>
                                </div>
                            </div>
                            <template #footer>
                <span class="dialog-footer">
                  <el-button @click="handleClose">{{ $t('取消') }}</el-button>
                    <!--        :disabled="disableAdd"            -->
                  <el-button type="primary" @click="handleAdd">
                    {{ $t('加入购物车') }}
                  </el-button>
                </span>
                            </template>
                        </el-dialog>
                    </div>
                </div>
                <div class="flex justify-center" style="width: 100%; margin-top: 12px">
                    <el-config-provider :locale="en">
                        <el-pagination
                                v-model:current-page="currentPage"
                                v-model:page-size="pageSize"
                                :page-sizes="[10, 20, 30, 50]"
                                background
                                layout="total, sizes, prev, pager, next, jumper"
                                :total="total"
                        />
                    </el-config-provider>
                </div>
            </div>
        </div>
        <div class="goods-right">
            <div class="title">{{ $t('已选择商品') }}</div>
            <div class="goods__list">
                <div
                        class="goods__list-item"
                        v-for="item in selectGoodsList"
                        :key="item.sellerGoodsId"
                >
                    <div class="img">
                        <img :src="item.imgUrl" style="height: 100%; width: 100%" alt=""/>
                    </div>
                    <div class="content">
                        <div class="name">
                            {{ item.goodsName }}
                        </div>
                        <div class="attrsValuesVos" v-if="Object.keys(item.attrsValuesVos).length > 0">
                            <div
                                    v-for="attrsObj in item.attrsValuesVos.attrs"
                                    :key="attrsObj.attrValueId"
                            >
                                <span>{{ attrsObj.attrValueName }}</span>
                            </div>
                        </div>
                        <div class="opt">
                            <div class="opt-number">
                                <!--                <el-button type="info" @click="down(item)"-->
                                <!--                >-->
                                <!--                  <el-icon>-->
                                <!--                    <Minus/>-->
                                <!--                  </el-icon>-->
                                <!--                </el-button>-->
                                <!--                <div style="width: 80px; text-align: center">-->
                                <!--                  {{ item.number }}-->
                                <!--                </div>-->
                                <!-- <el-input
                                  v-model="item.number"
                                  style="width: 80px; text-align: center"
                                ></el-input> -->
                                <!--                <el-button type="info" @click="add(item)">-->
                                <!--                  <el-icon>-->
                                <!--                    <Plus/>-->
                                <!--                  </el-icon>-->
                                <!--                </el-button>-->
                                <el-input oninput="value=value.replace(/[^0-9.]/g,'')" v-model="item.number" :min="1"/>
                                <!-- <el-input-number v-model="item.number" :step="2" /> -->
                            </div>
                            <div class="opt-total">
                <span class="price">${{
                    item.discountPrice ? item.discountPrice.toFixed(2) : item.sellingPrice.toFixed(2)
                    }}  </span
                ><span class="number">x{{ item.number }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="del">
                        <el-button type="danger" @click="del(item)" :icon="Delete" circle/>
                    </div>
                </div>
            </div>
            <div class="goods__total">
                <!--        <div class="price">-->
                <!--          <div class="name">{{ $t('小记') }}</div>-->
                <!--          <div class="number">${{ tPrice.toFixed(2) }}</div>-->
                <!--        </div>-->
                <!--        <div class="price">-->
                <!--          <div class="name">税</div>-->
                <!--          <div class="number">0.00</div>-->
                <!--        </div>-->
                <!--        <div class="price">-->
                <!--          <div class="name">运费</div>-->
                <!--          <div class="number">0.00</div>-->
                <!--        </div>-->
                <!--        <div class="price">-->
                <!--          <div class="name">折扣</div>-->
                <!--          <div class="number">0.00</div>-->
                <!--        </div>-->
                <div class="price">
                    <div class="all">{{ $t('合计') }}：${{ tPrice.toLocaleString() }}</div>
                    <div class="btn">
                        <el-button type="primary" @click="morePay">{{ $t('批量下单') }}</el-button>
                        <el-button type="primary" @click="onePay">{{ $t('单笔下单') }}</el-button>
                    </div>
                </div>
            </div>
        </div>
        <!-- 单个下单 -->
        <el-dialog v-model="dialogVisible" @close="singleClose" :title="$t('确定订单')" width="50%">
            <div class="main">
                <div class="main-left">
                    <div class="title">{{ $t('商品信息') }}</div>
                    <div class="list">
                        <div
                                class="main-left__list"
                                v-for="item in selectGoodsList"
                                :key="item.id">
                            <div class="list-img">
                                <img :src="item.imgUrl" alt=""/>
                            </div>
                            <div class="list-info">
                                <div class="name">{{ item.goodsName }}</div>
                                <div class="price-number">
                                    <div class="price">
                                        ${{
                                        item.discountPrice ? item.discountPrice.toFixed(2) : item.sellingPrice.toFixed(2)
                                        }}
                                    </div>
                                    <div class="number">x{{ item.number }}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="main-right">
                    <div class="title">{{ $t('顾客信息') }}</div>
                    <div class="main-info">
                        <el-select
                                v-model="userInfo"
                                filterable
                                remote
                                reserve-keyword
                                remote-show-suffix
                                :remote-method="userRemoteMethod"
                                :loading="userLoading"
                                style="width: calc(100% - 40px)"
                                :placeholder="$t('请选择')"
                                @change="userInfoChange"
                        >
                            <el-option
                                    v-for="(item, index) in userOptions"
                                    :key="item.contacts + index"
                                    :label="item.contacts"
                                    :value="item.userAddressId"
                            />
                        </el-select>
                        <div class="info">
                            <div class="price">
                                <div class="name">{{ $t('姓名') }}</div>
                                <div class="number">{{ userAddressDate.contacts || '' }}</div>
                            </div>
                            <div class="price">
                                <div class="name">{{ $t('电子邮件') }}</div>
                                <div class="number">{{ userAddressDate.email || '' }}</div>
                            </div>
                            <div class="price">
                                <div class="name">{{ $t('地址') }}</div>
                                <div class="number">{{ userAddressDate.address || '' }}</div>
                            </div>
                            <div class="price">
                                <div class="name">{{ $t('国家') }}</div>
                                <div class="number">{{ userAddressDate.country || '' }}</div>
                            </div>
                            <div class="price">
                                <div class="name">{{ $t('州') }}</div>
                                <div class="number">{{ userAddressDate.province || '' }}</div>
                            </div>
                            <div class="price">
                                <div class="name">{{ $t('邮政编码') }}</div>
                                <div class="number">{{ userAddressDate.postCode || '' }}</div>
                            </div>
                        </div>
                        <div class="info">
                            <!--              <div class="price">-->
                            <!--                <div class="name">{{ $t('小记') }}</div>-->
                            <!--                <div class="number">${{ tPrice.toFixed(2) }}</div>-->
                            <!--              </div>-->
                            <!--              <div class="price">-->
                            <!--                <div class="name">税</div>-->
                            <!--                <div class="number">0.00</div>-->
                            <!--              </div>-->
                            <!--              <div class="price">-->
                            <!--                <div class="name">运费</div>-->
                            <!--                <div class="number">0.00</div>-->
                            <!--              </div>-->
                            <!--              <div class="price">-->
                            <!--                <div class="name">折扣</div>-->
                            <!--                <div class="number">0.00</div>-->
                            <!--              </div>-->
                            <div class="price">
                                <div class="name">{{ $t('合计') }}</div>
                                <div class="number">${{ (tPrice.toLocaleString()) }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <template #footer>
                <div class="main-price">
                    <div class="left">{{ $t('余额') }}: <span class="number">${{ tPrice.toLocaleString() }}</span></div>
                    <div class="right">
                        <el-button type="primary" @click="onSubmit" :loading="buying">{{ $t('确定支付') }}</el-button>
                        <el-button @click="singleClose">{{ $t('取消') }}</el-button>
                    </div>
                </div>
            </template>
        </el-dialog>
        <!-- 批量下单 -->
        <el-dialog v-model="moreDialogVisible" :title="$t('确定订单')" width="50%" @close="manyClose">
            <div>
                <div class="main">
                    <div class="main-left">
                        <div class="title">{{ $t('商品信息') }}</div>
                        <div class="list">
                            <div
                                    class="main-left__list"
                                    v-for="item in selectGoodsList"
                                    :key="item.id"
                            >
                                <div class="list-img">
                                    <img :src="item.imgUrl" alt=""/>
                                </div>
                                <div class="list-info">
                                    <div class="name">{{ item.goodsName }}</div>
                                    <div class="price-number">
                                        <div class="price">
                                            ${{
                                            item.discountPrice ? item.discountPrice.toFixed(2) : item.sellingPrice.toFixed(2)
                                            }}
                                        </div>
                                        <div class="number">x{{ item.number }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="main-right">
                        <div class="title">{{ $t('顾客信息') }}</div>
                        <div class="main-info">
                            <el-select
                                    v-model="userInfo"
                                    multiple
                                    filterable
                                    remote
                                    reserve-keyword
                                    remote-show-suffix
                                    :remote-method="userRemoteMethod"
                                    :loading="userLoading"
                                    style="width: calc(100% - 40px)"
                                    :placeholder="$t('请选择')"
                            >
                                <el-option
                                        v-for="item in userOptions"
                                        :key="item.partyId"
                                        :label="item.contacts"
                                        :value="item.userAddressId"
                                />
                            </el-select>
                            <div class="desc">
                                <!-- <div class="tag-group my-2 flex flex-wrap gap-1 items-center">
                                  <el-tag
                                    v-for="item in tagList"
                                    :key="item.partyId"
                                    class="mx-1 item"
                                    effect="dark"
                                    closable
                                  >
                                    {{ item.contacts }}
                                  </el-tag>
                                </div> -->
                            </div>
                            <!--            <div class="form">-->
                            <!--              <el-form-->
                            <!--                ref="ruleFormRef"-->
                            <!--                :model="form"-->
                            <!--                label-width="120px"-->
                            <!--                class="demo-ruleForm"-->
                            <!--                :size="formSize"-->
                            <!--                status-icon-->
                            <!--              >-->
                            <!--                <el-form-item label="下单时间" prop="startTime">-->
                            <!--                  <el-date-picker-->
                            <!--                    value-format="YYYY-MM-DD HH:mm:ss"-->
                            <!--                    v-model="form.startTime"-->
                            <!--                    type="datetime"-->
                            <!--                    placeholder="年/月/日"-->
                            <!--                  />-->
                            <!--                </el-form-item>-->
                            <!--                <el-form-item label="至" prop="endTime">-->
                            <!--                  <el-date-picker-->
                            <!--                    value-format="YYYY-MM-DD HH:mm:ss"-->
                            <!--                    v-model="form.endTime"-->
                            <!--                    type="datetime"-->
                            <!--                    placeholder="年/月/日"-->
                            <!--                  />-->
                            <!--                </el-form-item>-->
                            <!--                <el-form-item label="单笔订单金额" prop="price">-->
                            <!--                  <div class="item">-->
                            <!--                    <el-input v-model="form.startPrice" />-<el-input-->
                            <!--                      v-model="form.endPrice"-->
                            <!--                    />-->
                            <!--                  </div>-->
                            <!--                </el-form-item>-->
                            <!--                <el-form-item label="下单时间间隔" prop="price">-->
                            <!--                  <div class="item">-->
                            <!--                    <el-input v-model="form.startTimeJ" />-<el-input-->
                            <!--                      v-model="form.endTimeJ"-->
                            <!--                    />分钟-->
                            <!--                  </div>-->
                            <!--                </el-form-item>-->
                            <!--                <el-form-item label="单笔订单商品" prop="goods">-->
                            <!--                  <div class="item">-->
                            <!--                    <el-input v-model="form.startNumber" />-<el-input-->
                            <!--                      v-model="form.endNumber"-->
                            <!--                    />-->
                            <!--                  </div>-->
                            <!--                </el-form-item>-->
                            <!--                <el-form-item label="订单总额" prop="goods">-->
                            <!--                  <el-input v-model="form.totalPrice" />-->
                            <!--                </el-form-item>-->
                            <!--              </el-form>-->
                            <!--            </div>-->
                        </div>
                    </div>
                </div>
                <div class="main-bottom">
                    <div class="block">
                        <span class="demonstration">{{ $t('下单时间范围') }}</span>
                        <el-date-picker

                                v-model="placeAnOrderTime"
                                type="datetimerange"
                                range-separator="To"
                                start-placeholder="Start date"
                                end-placeholder="End date"
                        />
                    </div>
                    <div class="block">
                        <span class="demonstration">{{ $t('下单时间间隔') }}</span>
                        <div style="display: flex; flex-direction: column">
                            <div style="display: flex; align-items: center">
                                <el-input v-model="placeAnOrderTimeMin" :placeholder="$t('最小值')"
                                          @blur="handlerTimeBlur"/>
                                <div class="line"></div>
                                <el-input v-model="placeAnOrderTimeMax" :placeholder="$t('最大值')"
                                          @blur="handlerTimeBlur"/>
                            </div>
                            <div class="warn" v-show="isShowTimeText">{{ $t('最小值不能大于或等于最大值') }}</div>
                        </div>
                    </div>
                    <div class="block">
                        <span class="demonstration">{{ $t('单笔订单金额') }}</span>
                        <div style="display: flex; flex-direction: column">
                            <div style="display: flex; align-items: center">
                                <el-input v-model="placeAnOrderAmountMin" :placeholder="$t('最小金额')"
                                          @blur="handlerAmountBlur"/>
                                <div class="line"></div>
                                <el-input v-model="placeAnOrderAmountMax" :placeholder="$t('最大金额')"
                                          @blur="handlerAmountBlur"/>
                            </div>
                            <div class="warn" v-show="isShowAmountText">{{ $t('最小值不能大于或等于最大值') }}</div>
                        </div>
                    </div>
                    <!--          <div class="block">-->
                    <!--            <span class="demonstration">单个订单商品数量</span>-->
                    <!--            <div style="display: flex; flex-direction: column">-->
                    <!--              <div style="display: flex; align-items: center">-->
                    <!--                <el-input v-model="placeAnOrderNumMin" placeholder="最小数量" @focus="isShowNumText = false"-->
                    <!--                          @blur="handlerNumBlur"/>-->
                    <!--                <div class="line"></div>-->
                    <!--                <el-input v-model="placeAnOrderNumMax" placeholder="最大数量" @focus="isShowNumText = false"-->
                    <!--                          @blur="handlerNumBlur"/>-->
                    <!--              </div>-->
                    <!--              <div class="warn" v-show="isShowNumText">最小值不能大于或等于最大值</div>-->
                    <!--            </div>-->
                    <!--          </div>-->
                    <div class="block">
                        <span class="demonstration">{{ $t('订单总金额') }}</span>
                        <el-input v-model="totalAmount" placeholder=""/>
                    </div>
                </div>
            </div>
            <template #footer>
                <div class="main-price">
                    <div class="left"></div>
                    <div class="right">
                        <el-button type="primary" @click="onMoreSubmit" :disabled="isDisabled" :loading="buying">{{
                            $t('开始下单')
                            }}
                        </el-button>
                        <el-button @click="moreDialogVisible = false">{{ $t('取消') }}</el-button>
                    </div>
                </div>
            </template>
        </el-dialog>
    </div>
</template>

<script setup>
// const currentAttributes = ref([
//   {
//     "attrName": "颜色",
//     "attrValue": "红色",
//     "attrNameId": "color",
//     "attrValueId": "red",
//     "goodsId": "ff80808184676a7a018467d1f6ba0002",
//     "sort": null
//   },
//   {
//     "attrName": "内存",
//     "attrValue": "32G",
//     "attrNameId": "memory",
//     "attrValueId": "32",
//     "goodsId": "ff80808184676a7a018467d1f6ba0002",
//     "sort": null
//   }
// ])
// import { uniqBy } from 'lodash'
import {reactive, ref, watch} from "vue";
import date from 'date-php'
// eslint-disable-next-line no-unused-vars
import {CirclePlus, Delete} from "@element-plus/icons-vue";
import {ElMessage} from 'element-plus'
import axios from "axios";

// eslint-disable-next-line
// eslint-disable-next-line
// eslint-disable-next-line
import en from 'element-plus/dist/locale/en.mjs'

import {baseUrl3} from "@/config";
import {deepClone} from "@/utils";
import {useI18n} from "vue-i18n";
// eslint-disable-next-line
const {t} = useI18n()

const disableAdd = ref(true) // 规格必须得选全或者没有规格的清空下 才允许添加如购物车

// 下单中
const buying = ref(false)

const userAddressDate = ref({})
const getUserAddressDate = val => {
    axios({
        method: "post",
        url: `${baseUrl3}/api/item/findUserAddressById`,
        data: {
            userAddressId: val
        }
    }).then(function (res) {
        userAddressDate.value = res.data.data
        console.log(userAddressDate.value);
    });
}

const userInfoChange = val => {
    getUserAddressDate(val);
}

const input = ref("");
const sellerId = ref("");
// const num = ref(5);
const dialogVisible = ref(false);
const userInfo = ref([]);

const sel = ref("所有卖家");
const kind = ref("所有分类");
// const type = ref("全部类型");


// 总费用
const tPrice = ref(0);

// 所有数据
let goodsList = ref([]);
// 选中数据
let selectGoodsList = ref([]);
watch(
    selectGoodsList,
    (val) => {
        tPrice.value = 0;
        if (!val.length) {
            tPrice.value = 0;
        }

        val.forEach((item) => {
            tPrice.value += (item.discountPrice ? item.discountPrice : item.sellingPrice) / 1 * item.number;
        });
    },
    {immediate: true, deep: true}
);
// 分页
const currentPage = ref(1);
const pageSize = ref(10);
const total = ref(10);

const selOptions = ref([]);
const userList = ref([]);
const kindOptions = ref([]);
// 获取商品分类
const allKinds = () => {
    const formData = new FormData()

    formData.append('lang', 'cn')
    axios({
        method: "post",
        url: `${baseUrl3}/api/item/findCategoryList`,
        date: formData,
    }).then(function (res) {
        kindOptions.value = res.data.data;
        kindOptions.value.unshift({
            categoryId: '',
            categoryName: '所有分类'
        })
    });
};
// TODO: 获取所有商家
const selList = ref([]);
const getAllShop = () => {
    axios({
        method: "post",
        url: `${baseUrl3}/api/item/findSellerList`,
    }).then(function (res) {
        console.log('卖家', res.data.data)
        // console.error(res);
        selOptions.value = res.data.data;
        selList.value = selOptions.value;
        selList.value.unshift({
            sellerId: '',
            sellerName: '所有卖家'
        })
    });
};

const clearAttrbutes = () => {
    attributes.data = {}
    SkuId.value = ''
    cacheGood.value = null
}
const handleClose = () => {
    selectArr.value = [];

    showModal.value = false
    disableAdd.value = true
    clearAttrbutes()
}
const handleAdd = () => {
    console.log(123)

    if (SkuId.value) {
        cacheGood.value.skuId = SkuId.value
        cacheGood.value.sellingPrice = attributes.data.skus.find(item => item.skuId === SkuId.value).sellingPrice
        cacheGood.value.discountPrice = attributes.data.skus.find(item => item.skuId === SkuId.value).discountPrice
        addGoods(cacheGood.value)
        handleClose()

        selectArr.value = []
    } else {
        cacheGood.value.skuId = '-1' // 没有属性的商品
        addGoods(cacheGood.value)
        handleClose()

        selectArr.value = []
        // ElMessage.error('该商品没有属性，不能加入购物车。')
    }
}
const SkuId = ref('') // 当前商品弹窗所选择属性以后的SkuId
const len = ref(0) // 当前商品弹窗所选择属性以后的SkuId
const selectArr = ref([]) // 存储激活的商品属性对象
let selectData = {}; // 存储激活的商品属性对象


const handleSelect = (item, index, item2, index2) => { // item是attrsValuesVos数组每一项   item2是attrValues的数组每一项
    console.log('index index2', index, index2);
    attributes.data.attrsValuesVos.splice(index, 1, {...item, active: index2}) // 选中的属性

    console.log(attributes.data.attrsValuesVos);

    const len = attributes.data.attrsValuesVos.length // selectArr 数组得最大长度
    console.log(selectArr.value)
    console.log(item2);

    if (selectArr.value.length === len) {
        selectArr.value.splice(index, 1, item2) // 选中的属性值
    } else {
        selectArr.value[index] = item2;
    }

    let data
    // console.log('selectArr', selectArr.value)

    // const selectData = []

    /*

    if (selectArr.value.length === len) { // 达到最大长度才去寻找组合的skuId
      disableAdd.value = false
      data = attributes.data?.skus.find((sku) => {
        return sku.attrs.every(att => {
          const target = selectArr.value.find((item3) => {
            return att.attrValueId === item3.attrValueId
          })
          // console.log('target', target)
          return !!target;
          // return att.attrValueId === item2.attrValueId
        })
      }) || {};
    } else {
      disableAdd.value = true
    }
     */

    if (selectArr.value.length >= 1 && !selectArr.value.includes()) {
        if (selectArr.value.length === len) {
            disableAdd.value = false

            data = attributes.data?.skus.find((sku) => {
                return sku.attrs.every(att => {
                    const target = selectArr.value.find((item3) => {
                        return att.attrValueId === item3.attrValueId
                    })
                    // console.log('target', target)
                    return !!target;
                    // return att.attrValueId === item2.attrValueId
                })
            }) || {};
        }
    } else { // 禁用
        disableAdd.value = true
    }

    selectData = data;

    console.log(data, '这是data');
    SkuId.value = data?.skuId || -1;
    // let str1 = '' // 从左到右排列的字符串，以防查不到skuId
    // let str2 = ''
    // attributes.data.attrsValuesVos.forEach((item3) => {
    //   str1 += item3.attrValueIds[item3.active] + '_'
    // })
    // for (let j = attributes.data.attrsValuesVos.length - 1;j >= 0; j--) {
    //   str2 += attributes.data.attrsValuesVos[j].attrValueIds[attributes.data.attrsValuesVos[j].active] + '_'
    // }
    // // console.log('str1', str1.substring(0, str1.length - 1))
    // str1 = str1.substring(0, str1.length - 1)
    // // console.log('str2', str2.substring(0, str2.length - 1))
    // str2 = str2.substring(0, str2.length - 1)
    // const idObj =  attributes.data.skus
    //
    // if (Object.prototype.hasOwnProperty.call(idObj,str1)) {
    //   SkuId.value = idObj[str1]
    // } else if (Object.prototype.hasOwnProperty.call(idObj,str2)) {
    //   SkuId.value = idObj[str2]
    // } else {
    //   ElMessage.error('该商品没有该属性')
    //   return
    // }

    console.log('SkuId', SkuId.value)
}


const attributes = reactive({data: {}}) // 当前弹窗商品属性
const showModal = ref(false)
const cacheGood = ref(null)
const openSelectGoodsOptions = (item) => { // 打开选择商品属性弹窗
    console.log(item);
    // 解决对象引用问题
    const data = deepClone(item)
    // const data = JSON.parse( JSON.stringify(item) )

    cacheGood.value = data // 缓存将要加入购物车的商品
    showModal.value = true
    getGoodsAttributes(item)
}
const getGoodsAttributes = (item) => { //
    // const host = window.location.host
    // console.log('host', host)
    axios({
        method: "post",
        url: `${baseUrl3}/wap/api/sellerGoods!info.action?sellerGoodsId=${item.sellerGoodsId}`, // 这个是调用的H5端的接口
    }).then((res) => {
        console.log('当前商品属性', res.data.data.canSelectAttributes)
        attributes.data = res.data.data.canSelectAttributes
        if (!attributes.data) {
            attributes.data = {}
        }
        attributes.data.attrsValuesVos = attributes.data.goodAttrs;
        len.value = attributes.data.skus?.[0].attrs?.length || 0;
        if (len.value === 0) {
            disableAdd.value = false
        }
        // if (attributes.data && Object.prototype.hasOwnProperty.call(attributes.data, 'attrsValuesVos') && attributes.data.attrsValuesVos instanceof Array) {
        //   attributes.data.attrsValuesVos.forEach((item) => {
        //     item.active = 0
        //   })
        //   handleSelect(attributes.data.attrsValuesVos[0], 0, attributes.data.attrsValuesVos[0].attrValues[0], 0)
        // }
        // else {
        //   ElMessage.error('该商品没有属性，不能加入购物车。')
        // }
        // attributes.data = {
        //   systemGoodsId: "ff80808184676a7a018467d1f6ba0002",
        //   attrsValuesVos: [
        //     {
        //       attrName: "颜色",
        //       attrNameId: "color",
        //       attrValues: [
        //         "红色",
        //         "白色"
        //       ],
        //       // active: 0, // 当前哪个激活
        //       attrValueIds: [
        //         "red",
        //         "white"
        //       ]
        //     },
        //     {
        //       attrName: "内存",
        //       attrNameId: "memory",
        //       attrValues: [
        //         "32G",
        //         "16G"
        //       ],
        //       // active: 0, // 当前哪个激活
        //       attrValueIds: [
        //         "32",
        //         "16"
        //       ]
        //     }
        //   ],
        //   attrsIdSkuId: {
        //     "32_white": "sku2",
        //     "16_red": "sku3",
        //     "32_red": "sku1",
        //     "16_white": "sku5"
        //   }}
    })
}

// const typeOptions = ["全部类型", "直通车商品", "非直通车商品"];

// TODO: 添加商品操作
const addGoods = (item) => {
    const data = deepClone(selectData)

    console.log(data);

    item.attrsValuesVos = data;

    console.log(item);

    let res;
    if (selectGoodsList.value.length !== 0) {
        res = selectGoodsList.value.find(it => {
            console.log(it);
            console.log(item)
            if (it.sellerGoodsId === item.sellerGoodsId) {

                if (item.skuId === it.skuId) {
                    it.number++;

                    return it;
                }
            }
        })
    }

    if (res === undefined || res.length === 0) {
        console.log('添加')
        selectGoodsList.value.push(item);
        item.number++;
    }
    // const isExist = selectGoodsList.value.some(
    //     (it) => it.sellerGoodsId === item.sellerGoodsId
    // );
    // item.number++;
    // selectGoodsList.value.splice(1, 0);
    // if (!isExist) {
    //   selectGoodsList.value.push(item);
    // }

    selectData = {}
};

// TODO: 删除选中列表
const del = (value) => {
    const allData = selectGoodsList.value;
    selectGoodsList.value = allData.filter((item) => {
        if (item.skuId !== value.skuId) {
            return true;
        } else {
            item.number = 0;
            return false;
        }
    });
};
watch([input, sellerId, sel, kind, currentPage, pageSize], (val) => {
    console.log(val);
    getGoods();
});

// TODO: 获取商品列表
const getGoods = () => {
    axios({
        method: "post",
        url: `${baseUrl3}/api/item/findSellerGoodsList`,
        data: {
            goodsName: input.value,
            sellerId: sel.value === "所有卖家" ? sellerId.value : sellerId.value ? sellerId.value : sel.value,
            categoryId: kind.value === "所有分类" ? "" : kind.value,
            pageNo: currentPage.value,
            pageSize: pageSize.value,
        },
    }).then(function (res) {
        console.log("商品列表数据", res);
        // console.error(res);
        goodsList.value = res.data.records;
        if (goodsList.value.length > 0) {
            goodsList.value.forEach((item) => (item.number = 0));
        }
        total.value = res.data.totalCount;
    });
};

const userOptions = ref([]);
// TODO: 获取收货人列表
const getTagList = () => {
    axios({
        method: "post",
        url: `${baseUrl3}/api/item/findPartyList`,
    }).then(function (res) {
        console.log(res);
        tagList.value = res.data.data;
        userList.value = res.data.data;
        userOptions.value = userList.value
        // userOptions.value = uniqBy(userList.value, 'partyId')
        console.log(userOptions.value);
    });
};

// eslint-disable-next-line no-unused-vars
const add = (item) => {
    item.number += 1;
};

// eslint-disable-next-line no-unused-vars
const down = (item) => {
    if (item.number > 1) {
        item.number -= 1;
    }
};

// 单笔下单
const onePay = () => {
    if (selectGoodsList.value.length === 0) {
        ElMessage({
            message: `${t('请选择商品')}！`,
            type: 'warning',
        })
        return
    }
    dialogVisible.value = true;
};

// TODO: 确定支付
const onSubmit = () => {
    buying.value = true;
    // 商品id集合
    const items = selectGoodsList.value.map((item) => {
        return {
            itemId: item.sellerGoodsId,
            count: item.number,
            skuId: item.skuId,
        };
    });
    let res = userOptions.value.find((item) => {
        return item.userAddressId === userInfo.value
    })
    if (res) {
        let id = res.partyId
        axios({
            method: "post",
            url: `${baseUrl3}/api/item/order/single`,
            data: {
                secret: "test",
                partyId: id ? id : '', //用户id
                items: items,
            },
        }).then((res) => {
            if (res.data.code === 200 || res.data.code === 0) {
                ElMessage({
                    message: '下单成功！',
                    type: 'success',
                })
                buying.value = false;

                dialogVisible.value = false;

                selectGoodsList.value = [];
            } else {
                ElMessage({
                    message: res.data.msg,
                    type: 'warning',
                })
            }
        }).catch((err) => {
            buying.value = false;

            ElMessage({
                message: err,
                type: 'warning',
            })
        });
    } else {
        ElMessage({
            message: '请选择收货人！',
            type: 'warning',
        })
    }
};
// const form = ref({
//   startTime: null,
//   endTime: null,
//   startPrice: null,
//   endPrice: null,
//   startTimeJ: null,
//   endTimeJ: null,
//   totalPrice: null,
//   startNumber: null,
//   endNumber: null,
// });
// TODO: 批量下单确定事件
const loading = ref(false); // 请求动画
const onMoreSubmit = () => {
    buying.value = true;
    console.log(placeAnOrderTime.value)
    console.log(userInfo.value);
    let arr = [];
    if (userInfo.value.length === 0) {
        ElMessage({
            message: '请选择收货人！',
            type: 'warning',
        })
        buying.value = false
        return
    }
    loading.value = true;
    userInfo.value.forEach((item) => {
        let res = userOptions.value.find((item2) => {
            return item2.userAddressId === item
        })
        arr.push(res.partyId)
    })
    // const data = {
    //   secret: "test",
    //   partyIds: [...userInfo.value], // 用户id集合
    //   items: [...selectGoodsList.value.map((item) => item.sellerGoodsId)], //商品id集合
    //   datetime: [form.value.startTime, form.value.endTime], // 下单开始时间、 结束时间  yyyy-MM-dd HH:mm:ss
    //   time_limit: [form.value.startTimeJ, form.value.endTimeJ], //下单时间间隔
    //   price_limit: [form.value.startPrice, form.value.endPrice], //单个订单金额区间
    //   item_limit: [form.value.startNumber, form.value.endNumber], // 单个订单 商品数量区间
    //   total_amount: form.value.totalPrice, //订单总金额
    // };
    const time = []
    placeAnOrderTime.value.forEach(val => {
        time.push(date('Y-m-d H:i:s', val));
    })
    const data = {
        secret: "test",
        partyIds: [...arr], // 用户id集合
        skuIds: [...selectGoodsList.value.map((item) => item.skuId)], //选择到的属性skuId集合
        items: [...selectGoodsList.value.map((item) => item.sellerGoodsId)], //商品id集合
        datetime: time, // 下单开始时间、 结束时间  yyyy-MM-dd HH:mm:ss
        time_limit: [placeAnOrderTimeMin.value, placeAnOrderTimeMax.value], //下单时间间隔
        price_limit: [placeAnOrderAmountMin.value, placeAnOrderAmountMax.value], //单个订单金额区间
        item_limit: [placeAnOrderNumMin.value, placeAnOrderNumMax.value], // 单个订单 商品数量区间
        total_amount: totalAmount.value, //订单总金额
    };
    // console.log(data);
    axios({
        method: "post",
        url: `${baseUrl3}/api/item/order`,
        data: data,
    }).then((res) => {
        if (res.data.code === 200) {
            ElMessage({
                message: '下单成功！',
                type: 'success',
            })
            moreDialogVisible.value = false
            buying.value = false;

            selectGoodsList.value = []
        } else {
            ElMessage({
                message: res.data.msg,
                type: 'warning',
            })
        }
    }).catch((err) => {
        buying.value = false;
        ElMessage({
            message: err,
            type: 'warning',
        })
    });
};
const moreDialogVisible = ref(false);
// 批量下单
const morePay = () => {
    if (selectGoodsList.value.length === 0) {
        ElMessage({
            message: `${t('请选择商品')}！`,
            type: 'warning',
        })
        return
    }
    moreDialogVisible.value = true;
};

// tagList
const tagList = ref([]);
const int = () => {
    allKinds();
    getAllShop();
    getTagList();
    getGoods();
};
int();

// 下单时间
const placeAnOrderTime = ref('');
// const formatTime = ref('')

// watch(placeAnOrderTime, () => {
//   const time = []
//   placeAnOrderTime.value.forEach(val => {
//     time.push(date('Y-m-d H:i:s',val));
//   })
//   // formatTime.value = time.join('-')
//   console.log(time);
// })
// 下单时间min
const placeAnOrderTimeMin = ref('')
// 下单时间max
const placeAnOrderTimeMax = ref('')
const isShowTimeText = ref(false)
const handlerTimeBlur = () => {
    if (parseInt(placeAnOrderTimeMin.value) >= parseInt(placeAnOrderTimeMax.value)) {
        isShowTimeText.value = true
    } else {
        isShowTimeText.value = false
    }
}

// 单笔订单金额min
const placeAnOrderAmountMin = ref('')
// 单个订单金额max
const placeAnOrderAmountMax = ref('')
const isShowAmountText = ref(false)
const handlerAmountBlur = () => {
    if (parseInt(placeAnOrderAmountMin.value) >= parseInt(placeAnOrderAmountMax.value)) {
        isShowAmountText.value = true
    } else {
        isShowAmountText.value = false
    }
}


// 单个订单商品数量min
const placeAnOrderNumMin = ref('')
// 单个订单商品数量max
const placeAnOrderNumMax = ref('')
// const isShowNumText = ref(false)
// const handlerNumBlur = () => {
//   if (parseInt(placeAnOrderNumMin.value) >= parseInt(placeAnOrderNumMax.value)) {
//     isShowNumText.value = true
//   } else {
//     isShowNumText.value = false
//   }
// }

// 订单总金额
const totalAmount = ref('');

// const handlerTotalAmountBlur = () => {
//
// }

// watch(() => [placeAnOrderNumMax.value, placeAnOrderAmountMax.value], () => {
//   console.log(123);
//   totalAmount.value = (parseInt(placeAnOrderAmountMax.value) * parseInt(placeAnOrderNumMax.value)) || '';
//   console.log(totalAmount.value);
// })

const isDisabled = ref(true);

watch(() => [
    placeAnOrderAmountMin.value,
    placeAnOrderAmountMax.value,
    placeAnOrderTimeMin.value,
    placeAnOrderTimeMax.value,
    totalAmount.value,
    placeAnOrderTime.value
], newVal1 => {

    const isNull = newVal1.filter(item => item === '')
    isDisabled.value = isNull.length > 0;

    watch(() => [
        isShowAmountText.value,
        // isShowNumText.value,
        isShowTimeText.value], (newVal2) => {
        if (placeAnOrderAmountMin.value !== '' && placeAnOrderAmountMax.value !== '' && placeAnOrderTimeMin.value !== '' && placeAnOrderTimeMax.value !== '') {
            const res = newVal2.filter(val => val === true);

            console.log(res);
            isDisabled.value = !(res.length === 0);

        } else {
            isDisabled.value = true;
        }
        // console.log(isShowNumText.value)


    })
}, {
    immediate: true
})


const userLoading = ref(false);
const userRemoteMethod = (query) => {
    if (query) {
        userLoading.value = true
        setTimeout(() => {
            userLoading.value = false
            userOptions.value = userList.value.filter((item) => {
                return item.contacts.toLowerCase().includes(query.toLowerCase())
            })
        }, 200)
    } else {
        userOptions.value = userList.value
    }
}

const sellerLoading = ref(false)
const sellerRemoteMethod = (query) => {
    console.log('触发搜索', query)
    if (query) {
        console.log(query);
        console.log(selOptions.value);
        sellerLoading.value = true
        setTimeout(() => {
            sellerLoading.value = false
            selList.value = selOptions.value.filter((item) => {
                return item.sellerName.toLowerCase().includes(query.toLowerCase())
            })

            if (selList.value[0].sellerId !== '') {
                selList.value.unshift({
                    sellerId: '',
                    sellerName: '所有卖家'
                })
            }
        }, 200)
    } else {
        selList.value = selOptions.value;
        if (selList.value[0].sellerId !== '') {
            selList.value.unshift({
                sellerId: '',
                sellerName: '所有卖家'
            })

        }
    }
}

// eslint-disable-next-line
const singleClose = () => {
    dialogVisible.value = false;
    userInfo.value = '';
    Object.keys(userAddressDate.value).forEach(key => userAddressDate.value[key] = '')
}

const manyClose = () => {
    moreDialogVisible.value = false;
    userInfo.value = ''
}

// const handleChange = (e, item) => {
//   console.log(e)
//   console.log(item)
//   // const res = goodsList.value.find(item => {
//   //   console.log(item.sellerId, id)
//   // })
//
// }
</script>

<style scoped lang="scss">
.attributes {
  font-size: 20px;

  .wrap {
    margin-bottom: 15px;

    .title2 {
      font-size: 18px;
      font-weight: 600;
      background-color: #e5e5e5;
      line-height: 36px;
      text-indent: 12px;
    }

    .details {
      margin-top: 10px;
      display: flex;
      align-items: flex-start;
      flex-wrap: wrap;

      .btn {
        margin: 0 12px 12px 0;
        font-size: 15px;
        cursor: pointer;

        &.active {
          background: #409eff;
          color: #fff;
        }
      }
    }
  }
}

.goods {
  height: calc(100% - 40px);
  width: calc(100% - 40px);
  display: flex;
  padding: 20px;

  &-left {
    width: 70%;
    height: 100%;

    .goods__select {
      margin-bottom: 20px;

      .name {
        font-style: normal;
        font-weight: 700;
        font-size: 16px;
        line-height: 19px;
        color: #000;
        margin-bottom: 10px;
      }
    }

    .goods__main {
      width: 100%;
      height: calc(100% - 62px);

      .main {
        display: flex;
        flex-wrap: wrap;
        align-content: flex-start;
        overflow: auto;
        height: calc(100% - 80px);

        &-list {
          width: 192px;
          //height: 303px;
          overflow: hidden;
          margin-right: 25px;
          margin-bottom: 30px;

          // &:nth-child(5n) {
          //   margin-right: 0;
          // }

          .img {
            width: 180px;
            height: 180px;
            margin-bottom: 12px;
            position: relative;

            img {
              width: 180px;
              height: 100%;
              object-fit: cover;
              //height: 192px;
            }

            .icon {
              font-size: 48px;
              display: none;
              margin: 0 auto;
              color: #fff;
            }

            .content {
              display: flex;
              flex-direction: column;
              justify-content: center;
              width: 100%;
              height: 100%;
              text-align: center;
              //margin-top: 60px;

              .add {
                color: #fff;
                font-weight: 400;
                font-size: 16px;
                line-height: 19px;
                text-decoration: none;
                display: none;
              }
            }

            &:hover {
              .modal {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
              }

              .icon,
              .add {
                display: block;
              }
            }
          }

          .title {
            min-height: 52px;
            color: #000;
            font-size: 12px;
            line-height: 13px;
            font-weight: 400;
            margin-bottom: 6px;
            word-break: break-all;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 4; /* 这里是超出几行省略 */
            overflow: hidden;
          }

          .price {
            font-style: normal;
            font-weight: 700;
            font-size: 16px;
            line-height: 19px;
            color: #000;
          }
        }
      }
    }
  }

  &-right {
    width: 30%;
    height: 100%;
    border-left: 1px solid #ccc;

    .title {
      font-style: normal;
      font-weight: 700;
      font-size: 16px;
      line-height: 19px;
      padding-left: 20px;
      color: #000;
    }

    .goods__list {
      width: 100%;
      height: calc(100% - 260px);
      overflow: auto;
      border-bottom: 1px solid #ccc;

      &-item {
        display: flex;
        width: calc(100% - 40px);
        align-items: center;
        border-bottom: 1px solid #ccc;
        padding: 20px;

        &:last-child {
          border-bottom: 0;
        }

        .img {
          width: 90px;
          height: 90px;

          img {
            object-fit: cover;
          }
        }

        .content {
          width: calc(100% - 152px);
          padding: 0 14px;
          //height: 88px;

          .name {
            font-style: normal;
            font-weight: 400;
            font-size: 16px;
            line-height: 19px;
            color: #000;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
          }

          .opt {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;

            &-number {
              display: flex;
              align-items: center;
            }

            :deep(.el-button) {
              background: #eeeeee;
              color: #000;
              border: 0;
            }

            :deep(.el-input__inner) {
              text-align: center;
            }

            :deep(.el-input__wrapper) {
              box-shadow: unset;

              &:hover {
                box-shadow: unset;
              }
            }

            &-total {
              .price {
                font-style: normal;
                font-weight: 700;
                font-size: 16px;
                line-height: 19px;
                color: #000;
              }

              .number {
                font-style: normal;
                font-weight: 400;
                font-size: 12px;
                line-height: 14px;
                color: #999;
              }
            }
          }
        }

        .del {
          width: 36px;
        }
      }
    }

    .goods__total {
      padding: 20px;

      .price {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 40px;

        .name {
          font-style: normal;
          font-weight: 400;
          font-size: 14px;
          line-height: 16px;
          color: #999;
        }

        .number,
        .all {
          font-style: normal;
          font-weight: 400;
          font-size: 14px;
          line-height: 16px;
          color: #000;
        }

        .btn {
        }
      }
    }
  }
}

.main {
  display: flex;

  &-left {
    height: 100%;
    width: 50%;
    overflow: auto;

    .title {
      font-style: normal;
      font-weight: 400;
      font-size: 16px;
      line-height: 19px;
      color: #000;
      padding-bottom: 20px;
    }

    .list {
      height: calc(62px * 5);
      overflow: auto;
      border: 1px solid #dcdfe6;
    }

    .main-left__list {
      display: flex;
      align-items: center;
      padding: 12px;
      border-bottom: 1px solid #dcdfe6;

      &:last-child {
        border-bottom: 0;
      }

      .list-img {
        width: 40px;
        //height: 88px;
        margin-right: 13px;

        img {
          width: 100%;
        }
      }

      .list-info {
        width: calc(100% - 88px);

        .name {
          font-style: normal;
          font-weight: 400;
          font-size: 14px;
          line-height: 19px;
          color: #000;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }

        .price-number {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 3px;
        }
      }
    }
  }

  &-right {
    width: 50%;

    .title {
      font-style: normal;
      font-weight: 400;
      font-size: 14px;
      line-height: 19px;
      color: #000;
      padding-left: 20px;
    }

    .main-info {
      padding: 20px;
      height: 100%;
      overflow: auto;

      .info {
        padding: 20px 0;
        border-bottom: 1px solid #ccc;

        &:last-child {
          border-bottom: 0;
        }

        .price {
          display: flex;
          justify-content: space-between;
          align-items: center;
          height: 35px;

          .name {
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            line-height: 16px;
            color: #999;
          }

          .number,
          .all {
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            line-height: 16px;
            color: #000;
          }
        }
      }

      .form {
        .item {
          display: flex;
        }
      }
    }
  }
}

.main-price {
  display: flex;
  justify-content: space-between;
  align-items: center;

  .left {
    font-style: normal;
    font-weight: 400;
    font-size: 14px;
    line-height: 16px;
    color: #000000;

    .number {
      font-size: 20px;
      font-weight: 700;
    }
  }
}

.main-bottom {
  padding: 30px 16px;
  margin-top: 20px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;

  .demonstration {
    width: 140px;
  }

  .block {
    display: flex;
    align-items: center;
    margin-bottom: 14px;

    &:last-child {
      margin-bottom: 0;
    }

    .line {
      width: 15px;
      height: 1px;
      margin-right: 8px;
      background: #dcdfe6;
    }

    .warn {
      margin-top: 6px;
      font-size: 12px;
      color: orangered
    }
  }


  .demonstration {
    margin-right: 15px;
  }

  :deep(.el-date-editor) {
    width: 370px;
  }

  :deep(.el-input__wrapper) {
    flex-grow: unset;
  }

  :deep(.el-input) {
    width: 190px;
  }
}

.desc {
  width: 100%;
  padding: 10px 0;

  .item {
    margin-right: 10px;
    margin-bottom: 10px;
  }

  // .desc-name {
  //   display: flex;
  //   flex-wrap: wrap;

  //   &__list {
  //   }
  // }
}

:deep(.el-dialog__body) {
  padding-top: 6px;
}

:deep(.el-dialog) {
  margin-top: 50px;
}

.attrsValuesVos {
  line-height: 36px;
  font-size: 14px;
  color: #666;
}
</style>
