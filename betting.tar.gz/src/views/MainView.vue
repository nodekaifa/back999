<template>
  <el-container class="main">
    <el-header height="40px" style="background-color: #447ded">
      <HeaderView />
    </el-header>
    <el-container>
      <el-aside width="181px">
        <AsideView />
      </el-aside>
      <el-main>
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import HeaderView from "../components/HeaderView.vue";
import AsideView from "../components/AsideView.vue";
</script>

<style scoped lang="scss">
.main {
  height: 100%;
  overflow: hidden;
}
</style>
