<template>
  <div style="border: 1px solid #ccc">
    <Toolbar
        style="border-bottom: 1px solid #ccc"
        :editor="editorRef"
        :defaultConfig="toolbarConfig"
        :mode="mode"
    />
    <Editor
        style="height: 500px; overflow-y: hidden;"
        v-model="valueHtml"
        :defaultConfig="editorConfig"
        :mode="mode"
        @onCreated="handleCreated"
    />
  </div>
</template>

<script>
import '@wangeditor/editor/dist/css/style.css' // 引入 css
import {baseUrl2} from '@/config'
// eslint-disable-next-line no-unused-vars
import { onBeforeUnmount, ref, shallowRef, onMounted, watch } from 'vue'
import { Editor, Toolbar,  } from '@wangeditor/editor-for-vue'

import { i18nChangeLanguage } from '@wangeditor/editor'

// 切换语言 - 'en' 或者 'zh-CN'
i18nChangeLanguage('en')

export default {
  components: { Editor, Toolbar },
  props: {
    content: {
      type: String,
      default: ''
    }
  },
  // eslint-disable-next-line no-unused-vars
  setup(props,{ expose, emit }) {
    // 编辑器实例，必须用 shallowRef
    const editorRef = shallowRef()

    // 内容 HTML
    const valueHtml = ref('')
    watch(() => props.content, (val) => {
      // console.log('富文本传入', val)
      if (val) {
        editorRef.value.setHtml(val.replace('<br>', '\n')) // 换行符转义，以正确在编辑器中显示
        // valueHtml.value = val.toString()
        // console.log('valueHtml.value', valueHtml.value)
      }
    }, {
      deep: true,
      immediate: true
    })
    // eslint-disable-next-line no-unused-vars
    watch(valueHtml, (val) => {
      // console.log('富文本更新', val)
      // emit('update', val)
    })

    // 模拟 ajax 异步获取内容
    onMounted(() => {
      // setTimeout(() => {
      //   valueHtml.value = '<p>模拟 Ajax 异步设置内容</p>'
      // }, 1500)
    })


    const toolbarConfig = {}
    const editorConfig = {
      placeholder: '请输入内容...',
      MENU_CONF: {
        uploadImage: {
          meta: {
            moduleName: 'goods',
          },
          fieldName: 'file', // 上传到服务器的文件字段名
          server: `${baseUrl2}/normal/uploadimg!execute.action`, // 上传图片到服务器
          onSuccess(file, res) {
            console.log('上传成功', res)
          },
          onFailed(file, res) {
            console.log(`${file.name} 上传失败`, res)
          },
          // eslint-disable-next-line no-unused-vars
          customInsert(res, insertFn) {
            // res 即服务端的返回结果
            // 从 res 中找到 url alt href ，然后插入图片
            console.log('res2', res)
            insertFn(res.data)
          },
        }
      }

    }
    // 组件销毁时，也及时销毁编辑器
    onBeforeUnmount(() => {
      const editor = editorRef.value
      if (editor == null) return
      editor.destroy()
    })

    const handleCreated = (editor) => {
      editorRef.value = editor // 记录 editor 实例，重要！
    }
    expose({
      valueHtml
    })
    return {
      editorRef,
      valueHtml,
      mode: 'default', // 或 'simple'
      toolbarConfig,
      editorConfig,
      handleCreated
    };
  }
}
</script>

<style scoped>

</style>
