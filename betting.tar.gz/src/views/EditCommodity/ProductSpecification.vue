<template>
    <div class="specification">
        <div class="label">{{ $t('产品规格') }}</div>
        <div class="right">
            <!--            {{ newGoodAttrs }}-->
            <div v-for="(item, index) in newGoodAttrs" :key="item.attrId">
                <div class="property">
                    <div>
                        <div>{{ item.attrName }}：</div>
                        <div class="select-wrapper">
                            <div class="flex flex-wrap">
                                <div class="mr-15" style="display: flex;align-items: center"
                                     v-for="(item2, index2) in item.attrValues"
                                     :key="index2">
                                    <el-checkbox
                                            :model-value="item2.check"
                                            @change='checkboxChange(item2, index, index2, null, null)'
                                            :label="item2.attrValueName"
                                            size="large"/>
                                </div>
                            </div>
                            <div class="add">
                                <el-input v-model="input[item.attrName]" :placeholder="$t('请输入')"
                                          @change="handleChange(item.attrName,$event)"/>
                                <el-button class="add-btn" type="primary" @click="addAttrCategory({
                                      attrId: item.attrId,
                                      name: input[item.attrName],
                                      key: item.attrName
                                    })" round>{{ $t('增加') }}
                                </el-button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="type">
                <div class="is-icon">
                    <el-checkbox v-model="isIcon" label="规格使用ICON" style="margin-right: 20px" size="large"/>
                    <!--                    {{selectOptions}}-->
                    <el-select v-model="selectValue" @change="handleSelectChange">
                        <el-option
                                v-for="item in selectOptions"
                                :key="item"
                                :label="item"
                                :value="item"
                        />
                    </el-select>
                </div>
                <div class="list mt-10" v-if="currentAttr[selectValue] && currentAttr[selectValue].length">
                    <div class="list-item mt-10 mr-15" v-for="(item, index) in currentAttr[selectValue]"
                         :key="item.attrId + index">
                        <div class="btn">
                            <div v-if="item.iconImg">
                                <img style="width: 100px;height: 100px" class="el-upload-list__item-thumbnail"
                                     :src="item.iconImg ? item.iconImg : ''" alt=""/>
                            </div>
                            <el-upload
                                    :ref="refName(item)"
                                    class="upload-demo"
                                    :data="otherData"
                                    :action="action"
                                    :show-file-list="false"
                                    :before-upload="(e) => handleBeforeUpload(e, item)"
                                    :on-success="(e) => handleOnSuccess(e, item, selectValue, index)"
                                    :on-error="handleOnError"
                                    :limit="1">
                                <el-button type="primary">点击上传</el-button>
                            </el-upload>
                            <div class="text mt-10"><span
                                    style="color: red;font-weight: bold">{{ item.attrValueName }}</span></div>
                        </div>
                    </div>
                    <div style="margin-top: 24px;font-size: 12px;color: #F56C6C;">
                        *只能上传{{ iconInfo }}文件，且不超过4MB
                    </div>
                </div>
            </div>
            <div class="mt-20">
                <!--                {{newGoodAttrs}}-->
                <el-table border v-if="skus&&newGoodAttrs&&newGoodAttrs.length>0" :data="skus">
                    <el-table-column :label="item.attrName" width="120" v-for="(item, index) in newGoodAttrs"
                                     :key="item.attrId">
                        <template #default="scope">
                            <div>{{ scope.row.attrs[index].attrValueName }}</div>
                        </template>
                    </el-table-column>
                    <el-table-column :label="$t('价格')" width="180">
                        <template #default="scope">
                            <div>
                                <!--                                {{skus[scope.$index]}}-->
                                <el-input :key="1" v-model="skus[scope.$index].price" :min="1"
                                          oninput="value=value.replace(/[^0-9.]/g,'')"/>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column :label="$t('操作')" width="220">
                        <template #default="scope">
                            <el-button type="primary" @click="edit(scope.row, scope.$index)">{{
                                $t('编辑')
                                }}
                            </el-button>
                            <el-button type="primary" @click="remove(scope.row)">{{ $t('删除') }}</el-button>
                        </template>
                    </el-table-column>
                </el-table>

            </div>

        </div>
    </div>
    <el-dialog
            v-model="dialogEditVisible"
            :title="dialogTitle"
            width="50%"
    >
        <EditUploadImg @coverImg="handleCoverImg" :img="firstImg" :imgs="imgs" @img="handleImg"/>
        <template #footer>
          <span class="dialog-footer">
             <el-button type="primary" @click="dialogEditVisible = false">
             {{ $t('确定') }}
            </el-button>
            <el-button @click="dialogEditVisible = false">{{ $t('取消') }}</el-button>
          </span>
        </template>
    </el-dialog>
    <el-dialog v-model="dialogVisible">
        <img style="width: 100%" :src="cuurentIconImg" alt="Preview Image"/>
    </el-dialog>
</template>

<script setup>
import {defineEmits, defineExpose, defineProps, nextTick, ref, watch} from 'vue'
import axios from "axios";
import {baseUrl2} from "@/config";
import {ElLoading, ElMessage} from "element-plus";
import EditUploadImg from './EditUploadImg.vue'

const props = defineProps(['goodAttrs', 'goodSkuAttrDto', 'lang', 'initData'])
const emit = defineEmits(['changeValue'])

let itemRefs = {}

const input = ref({})
const priceInput = ref({})
const dialogEditVisible = ref(false)
const dialogTitle = ref('')
const isIcon = ref(props.initData.icon)
const selectValue = ref('')
const selectOptions = ref([])
const iconInfo = ref('jpg/png')
const otherData = ref({moduleName: 'goods',})
const action = ref(`${baseUrl2}/normal/uploadimg!execute.action`)
const coverImg = ref('')//封面
const img = ref([])//照片
const newGoodAttrs = ref([]); // 商品属性
const currentAttr = ref({}) // 当前选中的规格集合
const chunks = ref([])
const skus = ref([])
const otherSkus = ref([])
const editIndex = ref(0)
const firstImg = ref('')//封面
const imgs = ref([])// 列表图


/**
 * 获取属性的分类
 * @param categoryId
 */
watch(() => props.initData, (val) => {

    setTimeout(() => {
        nextTick(() => {
            isIcon.value = val.icon
            selectValue.value = val.attrName
        })
    }, 800)
}, {
    immediate: true,
    deep: true
})
watch(() => props.goodAttrs, (val) => {
    selectValue.value = '';
    newGoodAttrs.value = val
    selectOptions.value = val.map(item => item.attrName)
})
watch(() => props.goodSkuAttrDto, (val) => {
    skus.value = val.skus
})
watch(()=>isIcon.value, (val) => {
    console.log(val)
    dealSkus()
})
watch(()=>newGoodAttrs.value, (val) => {
    currentAttr.value = {}
    val.forEach(item => {
        currentAttr.value[item.attrName] = item.attrValues.filter(att => att.check)
        if (props.goodSkuAttrDto && props.goodSkuAttrDto.skus instanceof Array) {
            item.attrValues.forEach(att3 => {
                props.goodSkuAttrDto.skus.forEach(sku => { // 从skus里把已经上传过的图片赋值给对应的属性, 取消勾选，也会触发newGoodAttrs的变更
                    sku.attrs.forEach(attr => {
                        if (attr.attrValueId === att3.attrValueId) {
                            const index = currentAttr.value[item.attrName].findIndex(att4 => att4.attrValueId === att3.attrValueId)
                            if (index >= 0 && !currentAttr.value[item.attrName][index].iconImg) { // 已经赋值过了,就不要赋值，避免大量渲染,造成页面卡死
                                currentAttr.value[item.attrName][index].iconImg = attr.iconImg
                            }
                        }
                    })
                })
            })
        }
    })
})

const checkboxChange = (val, index, index2, goodAttrs, ownSkus) => {
    if (goodAttrs) {
        newGoodAttrs.value = goodAttrs;
    }
    const attrValues = newGoodAttrs.value[index].attrValues
    attrValues.splice(index2, 1, {
        ...val, check: !val.check,
        attrId: newGoodAttrs.value[index].attrId,
        attrName: newGoodAttrs.value[index].attrName
    })
    chunks.value = []
    newGoodAttrs.value.forEach((res) => {
        let arr = res.attrValues.filter((res2) => {
            return res2.check
        })
        if (arr.length > 0) {
            chunks.value.push(arr)
        }
    })
    if (chunks.value.length < newGoodAttrs.value.length) {
        skus.value = []
        return
    }
    const arr = combine(chunks.value) // 全部排列组合
    skus.value = []
    if (ownSkus?.length) {
        skus.value = ownSkus
    } else {
        arr.forEach((item) => {
            skus.value.push({
                attrs: item
            })
        })
    }
}
const combine = (chunks) => {
    let res = []

    let helper = function (chunkIndex, prev) {
        let chunk = chunks[chunkIndex]
        // console.log('chunk', chunk)
        let isLast = chunkIndex === chunks.length - 1
        for (let val of chunk) {
            let cur = prev.concat(val)
            if (isLast) {
                // 如果已经处理到数组的最后一项了 则把拼接的结果放入返回值中
                res.push(cur)
            } else {
                helper(chunkIndex + 1, cur)
            }
        }
    }

    // 从属性数组下标为 0 开始处理
    // 并且此时的 prev 是个空数组
    helper(0, [])

    return res
}
const handleChange = (key, val) => {
    if (!isNaN(val)) {

        if (val.split('.').length >= 2) { // 输入的是小数
            input.value[key] = (val / 1).toFixed(2);
        }
    }
}

/**
 * 新增属性分类
 */
const addAttrCategory = (item) => {
    console.log('新增属性分类', item)
    if (!item.name) {
        ElMessage({
            type: 'error',
            message: '无法新增，请输入。',
        })
        return
    }
    const data = new FormData
    data.append('lang', props.lang)
    data.append('attrId', item.attrId)
    data.append('name', item.name)
    axios({
        method: "post",
        'Content-Type': 'multipart/form-data',
        url: `${baseUrl2}/systemGoods/addAttributeValue.action`,
        data
    }).then((res) => {
        console.log('新增属性分类', res);
        input.value[item.key] = ''
        emit('refresh')
    });
}
const remove = (item) => {
    if (item.skuId) {
        const data = new FormData
        data.append('skuId', item.skuId)
        axios({
            method: "post",
            'Content-Type': 'multipart/form-data',
            url: `${baseUrl2}/systemGoods/delete/sku`,
            data
        }).then((res) => {
            console.log('删除sku', res);
            skus.value = skus.value.filter(sku => {
                return !(sku.attrs[0].attrValueId == item.attrs[0].attrValueId && sku.attrs[1].attrValueId == item.attrs[1].attrValueId)
            })
        });
    }
}

/**
 * 类型下拉事件
 * @param val
 */
// eslint-disable-next-line no-unused-vars
const handleSelectChange = (val) => {
    dealSkus()
}

const dealSkus = (img, id) => {
    skus.value?.forEach(item => {
        item.attrs?.forEach(it => {
            if (it.attrName === selectValue.value) {
                it.icon = isIcon.value
                if (img && id === it.attrValueId) {
                    it.iconImg = img
                }
            } else {
                it.icon = false
            }
        })
    })
}

defineExpose({
    test: [1, 2],
    checkboxChange,
    skus,
    otherSkus: otherSkus.value,
    priceInput: priceInput.value
})

const edit = (row, index) => {
    firstImg.value = row.coverImg
    imgs.value = row.img
    editIndex.value = index;
    dialogTitle.value = '';
    dialogEditVisible.value = true;
    row.attrs.forEach((item, index) => {
        dialogTitle.value += index > 0 ? '/' + item.attrValueName : item.attrValueName
    })
}

const loading = ref(false)
// eslint-disable-next-line no-unused-vars
const handleBeforeUpload = (rawFile, item) => {
    loading.value = ElLoading.service({
        lock: true,
        text: '上传图片中',
        background: 'rgba(0, 0, 0, 0.7)',
    })
}
// eslint-disable-next-line no-unused-vars
const handleOnSuccess = (res, current, selectValue, index) => {
    loading.value.close()
    if (res.code === '0') {
        ElMessage({
            message: '图片添加成功',
            type: 'success',
        })
        currentAttr.value[selectValue].splice(index, 1, {...currentAttr.value[selectValue][index], iconImg: res.data})
        itemRefs[current.attrValueId].value[0].clearFiles()
        dealSkus(res.data, current.attrValueId)
    } else {
        ElMessage({
            message: res.msg,
            type: 'error',
        })
    }
}
const refName = (item) => { // 动态设置ref。当规格使用icon，下拉选择属性行，并勾选相应得属性以后，会动态生成对应于勾选属性的上传组件的ref
    if (!itemRefs[item.attrValueId]) {
        itemRefs[item.attrValueId] = ref(null);
    }
    return itemRefs[item.attrValueId];
}
const handleOnError = () => {
    loading.value.close()
}
// 处理上传获取的封面图
const handleCoverImg = (val) => {
    coverImg.value = val;
    skus.value[editIndex.value].coverImg = val
}

// 处理上传的图片
const handleImg = (list) => {
    skus.value[editIndex.value].img = list
    img.value = list
}
// 预览图片
const cuurentIconImg = ref('')
//弹窗
const dialogVisible = ref(false)

</script>

<style lang="scss" scoped>
.flex {
  display: flex;
}

.flex-wrap {
  flex-wrap: wrap;
}

.mt-20 {
  margin-top: 20px;
}

.is-icon {
  height: 40px;
  line-height: 40px;
  margin: 10px 0;
}

.specification {
  display: flex;
  font-size: 14px;
  padding: 16px;

  .label {
    min-width: 100px;
    margin-right: 20px;
  }

  .right {
    flex: 1;
    color: #666666;
    min-width: 300px;

    .property {
      padding: 16px;
      border: 1px solid #dcdfe6;
      border-radius: 4px;
      margin-bottom: 20px;
    }

    .select-wrapper {
      display: flex;
      justify-content: space-between;
      margin-top: 15px;

      .add {
        display: flex;
        align-items: center;
        width: 200px;

        .add-btn {
          margin-left: 10px;
        }
      }
    }
  }
}

.list {
  padding: 16px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  margin-bottom: 20px;
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;

  .list-item {
    display: flex;

    .btn {
      display: flex;
      flex-direction: column;
      align-items: center;
    }
  }
}

.btn {
  display: flex;
}
</style>
