<template>
  <el-upload
      v-model:file-list="fileList"
      :limit="9"
      :data="otherData"
      :action="action"
      list-type="picture-card"
      :on-error="handleError"
      :on-success="handleSuccess"
      :before-upload="handleBeforeUpload"
  >
    <el-icon>
      <Plus/>
    </el-icon>
    <template #file="{ file }">
      <div>
        <img class="el-upload-list__item-thumbnail" :src="file.url" alt=""/>
        <span class="el-upload-list__item-actions">
          <span
              class="el-upload-list__item-preview"
              @click="handlePictureCardPreview(file)"
          >
            <el-icon><zoom-in/></el-icon>
          </span>
          <span
              v-if="!disabled"
              class="el-upload-list__item-delete"
              @click="handleDownload(file)"
          >
            <el-icon><Download/></el-icon>
          </span>
          <span
              v-if="!disabled"
              class="el-upload-list__item-delete"
              @click="handleRemove(file)"
          >
            <el-icon><Delete/></el-icon>
          </span>
        </span>
      </div>
    </template>
  </el-upload>

  <el-dialog v-model="dialogVisible">
    <img style="width: 100%" :src="dialogImageUrl" alt="Preview Image"/>
  </el-dialog>
</template>

<script setup>
import {baseUrl2} from '@/config'
// eslint-disable-next-line
import {ref, watch, defineExpose, defineEmits, onMounted} from 'vue'
import {Delete, Download, Plus, ZoomIn} from '@element-plus/icons-vue';
import {ElMessage, ElLoading} from "element-plus";
// import {baseUrl} from "@/config";

// eslint-disable-next-line no-undef
// eslint-disable-next-line
const props = defineProps({
  imgList: Array,
})

console.log(props.imgList,'props-imgList')
const otherData = ref({
  moduleName: 'goods',
})
const action = ref(`${baseUrl2}/normal/uploadimg!execute.action`)
// const action = ref(`${baseUrl}/normal/uploadimg!execute1.action`)
const dialogImageUrl = ref('')
const dialogVisible = ref(false)
const disabled = ref(false)
const fileList = ref([])
const emit = defineEmits(['delImg'])
const handleRemove = (file) => {
  console.log(file)
  const targrtIndex = fileList.value.findIndex(item => item.uid === file.uid)
  emit('delImg', fileList.value[targrtIndex])
  fileList.value.splice(targrtIndex, 1)
}

const removeFileList = () => {
  fileList.value = []
}

onMounted(() => {
  fileList.value = props.imgList;
})

// watch(props.imgList, (val) => {
//
//   console.log('imgList', val)
// }, {
//   deep: true,
// })
const handlePictureCardPreview = (file) => {
  dialogImageUrl.value = file.url
  dialogVisible.value = true
}

defineExpose({
  fileList,
  removeFileList
})

const handleDownload = (file) => {
  console.log(file)
}

const handleError = () => {
  loading.value.close()
}
/**
 * 上传成功操作
 */
const handleSuccess = (res) => {
  console.log('success', res)
  loading.value.close()
  if (res.code === '0') {
    ElMessage({
      message: '图片添加成功',
      type: 'success',
    })
  } else {
    ElMessage({
      message: res.msg,
      type: 'error',
    })
  }
  // eslint-disable-next-line no-undef
  emit('addImg', res.data)
}
const loading = ref(null)
const handleBeforeUpload = () => {
  loading.value = ElLoading.service({
    lock: true,
    text: '上传图片中',
    background: 'rgba(0, 0, 0, 0.7)',
  })
  emit('beforeUpload');
}
</script>

<style scoped>

</style>
