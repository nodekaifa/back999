<template>
    <el-cascader :options="options" clearable :value="value" filterable :props="cascaderProps" @change="changeValue">
    </el-cascader>
</template>

<script setup>
import {defineEmits, defineExpose, defineProps, ref} from "vue";
import axios from "axios";
import {baseUrl3} from "@/config";
import {useI18n} from "vue-i18n";

const {t} = useI18n()

const props = defineProps({
    value: {
        type: Array,
        default: () => []
    },
    all: {
        type: Boolean,
        default: false
    },
    lang: {
        type: String,
        default: 'zh'
    }
})

const emit = defineEmits(['input'])
// const {categoryId, secondaryCategoryId} = useVModels(props, emits)

const kinds = ref([])
const options = ref([])
const cascaderProps = ref({})
const getProductCategories = () => {
    axios({
        method: "get",
        url: `${baseUrl3}/wap/api/category!tree.action?lang=${props.lang}`,
    }).then((res) => {
        kinds.value = res.data.data
        let data = getChildren(res.data.data)
        data.unshift({
            value: null,
            label: t('全部'),
            children: null
        });
        options.value = data
    });
}

const getChildren = (data) => {
    let arr = [];
    data.forEach(item => {
        let obj = {
            value: item.id,
            label: item.name,
            children: null
        };
        if (item?.subList?.length > 0) {
            obj.children = getChildren(item.subList);
            obj.children.unshift({
                value: '0',
                label: t('全部'),
                children: null
            })
        }
        arr.push(obj);
    });
    return arr;
}

const changeValue = (val) => {
    emit('input', val)
}

defineExpose({
    getProductCategories,
    kinds,
})
</script>
<style lang="scss" scoped>

</style>