<template>
    <div class="edit-commodity">
        <el-button style="margin-bottom: 10px" type="primary" @click="router.go(-1)">{{ $t('返回') }}</el-button>
        <div class="font-600">
            {{ type === 'add' ? $t('新增') : $t('修改') }}{{ $t('您的产品') }}
        </div>
        <div class="flex justify-between edit-commodity-main">
            <div class="left">
                <div class="language">
                    <div :style="{'width': `200%`}">
                        <div
                                class="item"
                                v-for="(item, index) in language"
                                :key="index"
                                :class="{'active': info.lang === item.value}"
                                @click="changeLanguage(item)"
                        >
                            <img :src="item.src" alt="">
                            <div>{{ item.key }}</div>
                        </div>
                    </div>
                </div>
                <div class="font-600 info-title">{{ $t('基本信息') }}</div>
                <div>
                    <LibraryCell :label="$t('产品名称')" v-model:value="info.name"/>
                    <LibraryCell :label="$t('产品分类')">
                        <BCategory
                                style="width: 100%"
                                ref="BCategoryRef"
                                v-model="categoryId"
                                :lang="info.lang"
                        />
                    </LibraryCell>
                    <LibraryCell :type="'number'" :label="$t('排序')" v-model:value="info.goodsSort"/>
                    <LibraryCell :label="$t('单位')" v-model:value="info.unit"/>
                    <LibraryCell :label="$t('产品属性')">
                        <el-select
                                v-model="info.attributeCategoryId"
                                filterable
                                remote
                                :teleported="false"
                                reserve-keyword
                                :remote-method="handleRemote"
                                class="m-2"
                                :placeholder="$t('请选择')"
                                size="large"
                        >
                            <recycle-scroller
                                    :items="attributes"
                                    :item-size="33"
                                    style="height: 165px;overflow-y: auto"
                                    v-slot="{ item }"
                            >
                                <!-- 在这里定义每一项列表项的渲染内容 -->
                                <el-option
                                        :key="item.id"
                                        :label="item.name"
                                        :value="item.id"
                                />
                            </recycle-scroller>


                        </el-select>
                    </LibraryCell>
                    <ProductSpecification :lang="info.lang" @refresh="handleRefresh" :goodAttrs="goodAttrs"
                                          :initData="initData"
                                          :goodSkuAttrDto="goodSkuAttrDto" ref="productSpecification"
                                          @changeValue="changeValue"/>
                    <LibraryCell :type="'number'" :label="$t('最小采购数量')" v-model:value="info.buyMin"/>

                    <LibraryCell :label="$t('可否退款')">
                        <el-switch v-model="info.isRefund"
                                   :active-value="0"
                                   :inactive-value="1"/>
                    </LibraryCell>

                    <div style="padding: 16px;display: flex;align-items: center">
                        <div class="label">{{ $t('进货价格') }}</div>
                        <el-input oninput="value=value.replace(/[^0-9.]/g,'')" v-model="info.systemPrice" :min="1"
                                  :precision="2" :step="1"/>
                    </div>
                    <div>
                        <LibraryCell :label="`${$t('封面图')}(*)`">
<!--                            {{imgListObj}}-->
                            <div style="display: grid;grid-template-columns: repeat(5,1fr);gap: 30px;padding: 0 60px">
                                <UploadImg
                                        v-for="(img, index) in imgListObj"
                                        :key="index"
                                        :img="img"
                                        @handleRemove="handleRemove"
                                        @addImg="handleAddImg"
                                />
                            </div>
                        </LibraryCell>
                        <div class="img-tips">{{ $t('图片尺寸') }}：(750 * 750)</div>
                    </div>
                    <LibraryCell :label="$t('外部商品链接')" v-model:value="info.link"/>
                </div>
                <div>
                    <div class="font-600 info-title">{{ $t('商品描述') }}</div>
                    <div style="padding: 20px">
                        <RichText @update="updateDes" ref="richDesc" :content="info.des ? info.des : ''"/>
                    </div>
                </div>
                <div>
                    <div class="font-600 info-title">{{ $t('图片介绍') }}</div>
                    <div style="padding: 20px">
                        <!--            <vue3-tinymce v-model="state.content" :setting="state.setting" />-->
                        <RichText @update="updateImgDes" ref="richImgDesc" :content="info.imgDes ? info.imgDes : ''"/>
                    </div>
                </div>
            </div>
            <div class="right">
                <div class="font-600 info-title border-top-none">{{ $t('运费设置') }}</div>
                <div>
                    <LibraryCell :label="$t('运费设置')">
                        <el-switch v-model="info.freightType"
                                   :active-value="0"
                                   :inactive-value="1"/>
                    </LibraryCell>
                    <LibraryCell :type="'number'" :label="$t('运费设置')" v-model:value="info.freightAmount"
                                 :disable="(info.freightType /1 === 1)"/>
                </div>
                <div class="font-600 info-title">{{ $t('增值税和税收') }}</div>
                <div>
                    <LibraryCell :type="'number'" :label="$t('税收费用')" v-model:value="info.goodsTax"/>
                </div>
            </div>
        </div>
        <div class="button">
            <el-button type="primary" :loading="btnLoading" @click="saveForm">{{
                type === 'add' ? $t('新增') : $t('保存')
                }}
            </el-button>
        </div>
    </div>
</template>

<script setup>
import BCategory from './BCategory'
import "vue3-virtual-scroller/dist/vue3-virtual-scroller.css";
import {RecycleScroller} from 'vue3-virtual-scroller';
import {useI18n} from "vue-i18n";
import {useThrottleFn} from '@vueuse/core'
// eslint-disable-next-line
import {ElMessage, ElNotification} from 'element-plus'
import {onMounted, ref, watch, watchEffect} from 'vue'
import {baseUrl2} from "@/config";
import axios from "axios";
import LibraryCell from './LibraryCell'

import ProductSpecification from './ProductSpecification'
import UploadImg from './UploadImg'
import RichText from "@/views/EditCommodity/RichText";
import {useRoute} from 'vue-router'
import router from "@/router";
import language from "@/config/language";

const route = useRoute()
const {t} = useI18n()
const BCategoryRef = ref(null)
const btnLoading = ref(false)

const richDesc = ref(null);
const richImgDesc = ref(null);
const productSpecification = ref(null)
const productSkus = ref([])

console.log('res111')
const categoryId = ref('')

const info = ref({
    name: '',
    lang: 'en',
    categoryId: '',
    secondaryCategoryId: '',
    goodsSort: '',
    attributeCategoryId: '',
    unit: '',
    // 可退款（0可以 1不可以）
    isRefund: 0,
    purchasePrice: '',
    freightType: 1,
    putOnShelves: false,
    link: '',
    // 运费设置 0-开启 1-关闭
    freightAmount: 0,
    goodsTax: '',
    systemPrice: '',
    // 描述
    des: '',
    // 图片描述
    imgDe: '',

    buyMin: '',
    // 预警数量
    remindNum: '',

})

watch(() => info.value, (val) => {
    categoryId.value = [val.categoryId]
    if (val.secondaryCategoryId) {
        categoryId.value.push(val.secondaryCategoryId)
    }
})
watch(() => categoryId.value, (val) => {
    info.value.categoryId = val[0]
    if (val.length > 1) {
        info.value.secondaryCategoryId = val[1]
    } else {
        info.value.secondaryCategoryId = ''
    }
})
//照片墙
const imgList = ref([])
const imgListObj = ref({
    imgUrl1: {name: 'imgUrl1', url: ''},
    imgUrl2: {name: 'imgUrl2', url: ''},
    imgUrl3: {name: 'imgUrl3', url: ''},
    imgUrl4: {name: 'imgUrl4', url: ''},
    imgUrl5: {name: 'imgUrl5', url: ''},
    imgUrl6: {name: 'imgUrl6', url: ''},
    imgUrl7: {name: 'imgUrl7', url: ''},
    imgUrl8: {name: 'imgUrl8', url: ''},
    imgUrl9: {name: 'imgUrl9', url: ''},
    imgUrl10: {name: 'imgUrl10', url: ''},
})
const aa = ref([])
const kinds = ref([])

const attributes = ref([])
const attributesList = ref([{
    createTime: '',
    entityVersion: 0,
    id: "",
    name: '无',
    sort: 0,
    timestamp: null,
}])
/**
 * 删除图片
 */
const handleRemove = (key) => {
    console.log(key);
    console.log(imgListObj.value[key])
    imgListObj.value[key].url = ''
    info.value[key] = ''
}
/**
 * 添加图片
 */
const handleAddImg = (res) => {
    console.log(res);
    info.value[res.key] = res.src;
    imgListObj.value[res.key].url = res.src;
}

watch(() => info.value.attributeCategoryId, (val) => {
    if (val) { // 先下拉选取产品属性，再去获取规格
        getAttrCategoryList(info.value.attributeCategoryId)
    } else {
        goodAttrs.value = []
    }
})

watchEffect(() => { // 监听分类变化
    if (!info.value.categoryId) { // 不存在分类id
        console.log('不存在分类id')
    } else {
        console.log('存在分类id', info.value.categoryId)
    }
})

// 产品属性模糊搜索
const sellerLoading = ref(false)
const handleRemote = (query) => {
    if (query) {
        sellerLoading.value = true
        setTimeout(() => {
            sellerLoading.value = false
            attributes.value = attributesList.value.filter((item) => {
                return item.name.toLowerCase().includes(query.toLowerCase())
            })
        }, 200)
    } else {
        attributes.value = attributesList.value
    }
}

// eslint-disable-next-line


const updateDes = (val) => {
    info.value.des = val
    console.log('updateDes', val)
}
const updateImgDes = (val) => {
    info.value.imgDes = val
}
const goodSkuAttrDto = ref(null);

const id = ref('') // 域名带过来的商品的id
// eslint-disable-next-line
const token = ref('')
const type = ref(route.query.type || false)

/**
 * 获取商品信息
 */
const initData = ref({
    icon: false,
    attrName: ''
})
const getDatas = () => {

    axios({
        method: "post",
        url: `${baseUrl2}/systemGoods/getDesc.action?lang=${info.value.lang}&goodsId=${id.value}`, // ff808081846c7cb9018476237e070000
    }).then(async (res) => {
        console.log(res, '商品详情数据')
        const data = res.data.data
        info.value = {...info.value, ...data};

        // findSecondCategory(info.value.categoryId)
        // console.log('data.des', data.des)
        // console.log('...data', info.value)
        goodSkuAttrDto.value = info.value?.goodSkuAttrDto || {}
        if (info.value.isRefund == null) {
            info.value.isRefund = 1
        }
        goodSkuAttrDto.value?.skus?.forEach(sku => {
            sku.attrs?.forEach(item => {
                if (item.icon) {
                    // console.log('进来了', item)
                    initData.value.icon = true
                    initData.value.attrName = item.attrName
                }
            })
        })

        for (let i = 1; i <= 10; i++) {
            if (data[`imgUrl${i}`]) {
                imgList.value.push({
                    name: i,
                    url: data[`imgUrl${i}`]
                })
            }

            // if (`imgUrl${i}`.indexOf('imgUrl')) {
            //   console.log('我反问')
            // }


            // if (data[`imgUrl${i}`]) {
            //   console.log(`imgUrl${i}`);
            //   console.log(data[`imgUrl${i}`])
            //   imgListObj.value[`imgUrl${i}`] = {
            //     name: i,
            //     url: data[`imgUrl${i}`]
            //   }
            //
            // }
        }

        Object.keys(data).forEach(key => {
            // console.log(key,'是key');
            if (key.indexOf('imgUrl') !== -1) {
                imgListObj.value[key] = {
                    name: key,
                    url: data[key]
                }
            }
        })

        aa.value.push(
            imgList.value[0]
        )

        console.log('请求imgList', imgListObj)

        console.log('商品详情数据', info.value)
        getAttrCategory(info.value.categoryId)
        // getAttrCategoryList() // 要选取了属性 才能去获取
        BCategoryRef.value.getProductCategories()
    });
}


/**
 * 获取产品分类
 */
/*
const getProductCategories = () => {
  axios({
    method: "post",
    url: `${baseUrl2}/systemGoods/getGoodCategory.action?lang=${info.value.lang}`,

  }).then((res) => {
    const data = res.data.data
    kinds.value = data

    kinds.value.find(item => {
      console.log(item);
      if (item.categoryId === 'ff8080818604394d01860564d5670026') {
        console.log(item);
      }
    })
    // if (!info.value.categoryId) { // 如果不存在分类，就默认给一个
    //   info.value.categoryId = kinds.value[0].categoryId
    // }
  });
}
getProductCategories()
*/


/**
 * 获取属性分类
 */
const getAttrCategory = (id) => {
    axios({
        method: "post",
        url: `${baseUrl2}/systemGoods/getAllAttributeCategory.action?lang=${info.value.lang}&categoryId=${id}`,

    }).then((res) => {
        console.log('获取产品属性', res.data.data)
        const data = res.data.data
        attributesList.value = attributesList.value.concat(data)
        attributes.value = attributesList.value
    });
}

const goodAttrs = ref([])
const handleRefresh = () => {
    if (info.value.attributeCategoryId) {
        getAttrCategoryList(info.value.attributeCategoryId)
    }
}
/**
 * 获取产品规格
 */
const getAttrCategoryList = (id) => {
    axios({
        method: "post",
        url: `${baseUrl2}/systemGoods/getAttrCategoryList.action?lang=${info.value.lang}&categoryId=${id}`,
    }).then((res) => {
        console.log('获取产品规格', res.data.data)
        const data = res.data.data

        goodAttrs.value = data

        if (type.value && type.value !== 'add' && goodSkuAttrDto.value && goodSkuAttrDto.value.skus) { // 如果是编辑的话
            let allData = [];
            let result = [];
            let obj = {}
            goodSkuAttrDto.value.skus.forEach(item => {
                allData = [...allData, ...(item.attrs || [])]
            });
            allData.forEach(item => {
                if (!obj[item.attrId + item.attrValueId]) {
                    obj[item.attrId + item.attrValueId] = true
                    result.push(item);
                }
            })
            console.log('最终剩余数据', result)
            result.forEach(sku => {
                goodAttrs.value.forEach((item, index) => {
                    // console.log(item, index)
                    if (item.attrId === sku.attrId) {
                        item.attrValues.forEach(((item2, index2) => {
                            if (item2.attrValueId === sku.attrValueId) {
                                productSpecification.value.checkboxChange(item2, index, index2, goodAttrs.value, goodSkuAttrDto.value.skus)
                            }
                        }))
                    }
                })
            })
        }
        // info.
    });
}

const clear = () => { // 切换英语时清空数据
    info.value = {
        name: '',
        lang: 'en',
        categoryId: '',
        goodsSort: '',
        attributeCategoryId: '',
        unit: '',
        // 可退款（0可以 1不可以）
        isRefund: 0,
        purchasePrice: '',
        freightType: 1,
        putOnShelves: false,
        link: '',
        // 运费设置 0-开启 1-关闭
        freightAmount: 0,
        goodsTax: '',
        systemPrice: '',
        // 描述
        des: '',
        // 图片描述
        imgDe: '',

        buyMin: '',
        // 预警数量
        remindNum: '',

    }
    imgList.value = []
    goodAttrs.value = []
    goodSkuAttrDto.value = {}
    kinds.value = []
    attributesList.value.value = [{
        createTime: '',
        entityVersion: 0,
        id: "",
        name: '无',
        sort: 0,
        timestamp: null,
    }]

    attributes.value = attributesList.value
}

/**
 * 修改语言
 * @param item
 */
const changeLanguage = (item) => {
    clear()
    info.value.lang = item.value

    if (type.value && type.value === 'add') {
        getAttrCategory()
        BCategoryRef.value.getProductCategories()
    } else {
        getDatas()
    }
}
/**
 * 自组件传递数据
 * @param val
 */
const changeValue = (val) => {
    productSkus.value = val;
}
/**
 * 更新商品信息接口
 */

// eslint-disable-next-line
const upload = ref(null)

const saveForm = useThrottleFn(() => {
    console.log(info);

    // const list = upload.value.fileList // 图片列表
    //
    // for (let i = 0; i < list.length; i++) {
    //   const checkAlreadyExit = Object.keys(info.value).some(key => {
    //     return info.value[key] === list[i].url
    //   })
    //   if (checkAlreadyExit) { // 检查之前有没有
    //     continue
    //   }
    //   info.value[`imgUrl${i + 1}`] = list[i].response?.data
    // }
    // list.forEach((item, index) => {
    //   if (item.url.indexOf('https') > 0) {
    //     const checkAlreadyExit = Object.keys(info.value).some(key => {
    //       return info.value[key] === item.url
    //     })
    //     info.value[`imgUrl${index + 1}`] = item.url
    //   } else {
    //     info.value[`imgUrl${index + 1}`] = item.response?.data
    //   }
    // })
    // return
    // eslint-disable-next-line no-unreachable
    if (!info.value.name || !info.value.categoryId || !info.value.systemPrice) {
        ElMessage({
            message: t('产品缺少名称、分类、价格等信息'),
            type: 'warning',
        })
        return
    }

    const skus = productSpecification.value.skus; // 不是响应式的
    console.log('skus skus', skus)
    // const priceInput = productSpecification.value.priceInput
    if (skus && skus instanceof Array) {
        skus.forEach((item, index) => {
            // const key = item.attrs.reduce((sum, item2) => {
            //   return sum + item2.attrValueId
            // }, '')
            skus[index] = {
                ...item,
                skuId: item.skuId ? item.skuId : null,
                coverImg: item.coverImg ? item.coverImg : null,
                img: item.img ? item.img : null,
            }
            // skus.push({
            //   price: priceInput[key] / 1,
            //   attrs: productSkus.value[index].attrs,
            //   skuId: productSkus.value[index].skuId ? productSkus.value[index].skuId : '',
            //   coverImg: productSkus.value[index].coverImg,
            //   img: productSkus.value[index].img,
            // })
        })
    }
    console.log('skus', skus)
    // eslint-disable-next-line no-unreachable
    info.value.skus = skus;
    info.value.imgDes = richImgDesc.value.valueHtml
    info.value.des = richDesc.value.valueHtml
    let cache = {...info.value}
    delete cache.goodSkuAttrDto
    console.log('最终上传数据', cache)
    btnLoading.value = true
    console.log(cache);

    axios({
        method: "post",
        url: `${baseUrl2}/systemGoods/update.action?lang=${info.value.lang}`,
        data: cache
    }).then((res) => {
        btnLoading.value = false
        // ElMessage({
        //   message: '保存成功。',
        //   type: 'success',
        // })
        console.log('res ddd', res)
        if (res.data.code === '0') {
            ElNotification.success({
                title: 'Success',
                message: t('保存成功'),
                type: 'success',
                duration: 2000,
                offset: 100,
                onClose: () => {
                    router.go(-1)
                }
            })
            console.log('res', res)
            type.value === 'add' ? clear() : ''
        } else {
            ElNotification({
                message: t('保存失败'),
                type: 'error',
                offset: 100,
            })
        }

    }).catch(() => {
        // ElMessage({
        //   message: '保存失败。',
        //   type: 'warning',
        // })
        ElNotification({
            message: t('保存失败'),
            type: 'error',
            offset: 100,
        })
        btnLoading.value = false
    })
}, 1000)


onMounted(() => {
    if (type.value && type.value === 'add') {
        getAttrCategory()
        console.log('BCategoryRef', BCategoryRef)
        BCategoryRef.value.getProductCategories()
    } else {
        if (route.query.id) {
            id.value = route.query.id
        } else {
            ElMessage.error(t('请传递正确的商品id'))
        }
        // if (route.query.token) {
        //   token.value = route.query.token
        // } else {
        //   ElMessage.error('请传递token')
        // }
        getDatas()
    }
})

</script>

<style lang="scss" scoped>
@import "@/style/edit-commodity";

.label {
  width: 120px;
  margin-right: 20px;
  font-size: 14px;
}
</style>
