<template>
  <div class="container">
    <div class="left">
      <div class="title">封面图</div>
      <el-upload
          class="avatar-uploader"
          :data="otherData"
          :action="action"
          :show-file-list="false"
          :before-upload="handleBeforeUpload"
          :on-error="handleError"
          :on-success="e => handleAvatarSuccess(e, 'coverImg')"
      >
        <img v-if="imageUrl" sty :src="imageUrl" class="avatar" />
        <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
      </el-upload>
    </div>
    <div class="right">
      <div class="title">展示列表</div>
      <el-upload
          v-model:file-list="fileList"
          :data="otherData"
          :limit="9"
          :before-upload="handleBeforeUpload"
          :action="action"
          list-type="picture-card"
          :on-error="handleError"
          :on-success="e => handleAvatarSuccess(e, 'img')"
      >
        <el-icon><Plus /></el-icon>

        <template #file="{ file }">
          <div>
            <img class="el-upload-list__item-thumbnail" :src="file.url" alt=""/>
            <span class="el-upload-list__item-actions">
          <span
              class="el-upload-list__item-preview"
              @click="handlePictureCardPreview(file)"
          >
            <el-icon><zoom-in/></el-icon>
          </span>
          <span
              v-if="!disabled"
              class="el-upload-list__item-delete"
              @click="handleRemove(file)"
          >
            <el-icon><Delete/></el-icon>
          </span>
        </span>
          </div>
        </template>
      </el-upload>
    </div>
  </div>
  <el-dialog v-model="dialogVisible">
    <img style="width: 100%" :src="dialogImageUrl" alt="Preview Image"/>
  </el-dialog>
</template>

<script setup>
import { Delete, Plus, ZoomIn } from '@element-plus/icons-vue'
import {ElMessage, ElLoading} from "element-plus";

import {defineEmits, ref, watch} from "vue";
import {baseUrl2} from "@/config";

// eslint-disable-next-line no-undef
const props = defineProps({
  img: {
    type: String,
    default: ""
  },
  imgs: {
    type: Array,
    default: () => []
  }
})

// eslint-disable-next-line no-undef
const emits = defineEmits(['coverImg', 'img'])
const disabled = ref(false)
const dialogImageUrl = ref('')
const dialogVisible = ref(false)
const action = ref(`${baseUrl2}/normal/uploadimg!execute.action`)
const otherData = ref({
  moduleName: 'goods',
})
// 列表图
const fileList = ref([])
// 封面图
const imageUrl = ref('')
const loading = ref(null)
watch(() => props.imgs, (val) => {
    fileList.value = val?.map(item => {
      return {
        url: item
      }
    }) || []
}, {
  immediate: true
})
watch(() => props.img, (val) => {
    imageUrl.value = val
}, {
  immediate: true
})
const handleAvatarSuccess = (res, emitName) => {
  loading.value.close()
  loading.value = null
  if (res.code === '0') {
    ElMessage({
      message: '图片添加成功',
      type: 'success',
    })
    if (emitName === 'coverImg') {
      imageUrl.value = res.data
      emits('coverImg', res.data)
    } else {
      console.log('上传完', fileList.value)
      fileList.value[fileList.value.length - 1].url = res.data
      // fileList.value.push(res.data)
      const imgs = fileList.value.map(item => item?.url)
      console.log(imgs)
      emits('img', imgs)
    }
    console.log(fileList.value)
  } else {
    ElMessage({
      message: res.msg,
      type: 'error',
    })
  }
}
const handleBeforeUpload = () => {
  loading.value = ElLoading.service({
    lock: true,
    text: '上传图片中',
    background: 'rgba(0, 0, 0, 0.7)',
  })
}

const handleError = () => {
  loading.value.close()
  loading.value = null
}
const handlePictureCardPreview = (file) => {
  dialogImageUrl.value = file.url
  dialogVisible.value = true
}
const handleRemove = (file) => {
  const targrtIndex = fileList.value.findIndex(item => item.uid === file.uid)
  fileList.value.splice(targrtIndex, 1)
  const imgs = fileList.value.map(item => item?.url)
  //  TODO: 传出数据emit
  emits('img', imgs)
}
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  .left {
    margin-right: 20px;
  }
}
.avatar {
  width: 148px;
  height: 148px;
  display: block;
  object-fit: contain;
}

.avatar-uploader .el-upload {
  border: 1px dashed black;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: var(--el-transition-duration-fast);
}

.avatar-uploader .el-upload:hover {
  border-color: var(--el-color-primary);
}

.el-icon.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 148px;
  height: 148px;
  text-align: center;
  border: 1px solid #ccc;
}

.title {
  font-size: 18px;
  font-weight: bold;
  color: #000;
  height: 30px;
  margin-left: 34px;
}
</style>
