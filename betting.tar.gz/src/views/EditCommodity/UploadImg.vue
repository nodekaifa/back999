<template>
  <div class="btn">
    <div v-if="props.img.url" class="img-wrapper" @mouseenter="isShow = true" @mouseleave="isShow = false">
      <img style="width: 100%;height: 144px;object-fit: cover" class="el-upload-list__item-thumbnail"
           :src="props.img.url ? props.img.url : ''" alt=""/>
      <div class="mask" v-show="isShow">
        <el-icon>
          <zoom-in @click="handlePictureCardPreview"/>
        </el-icon>
        <el-icon>
          <Delete @click="handleDelImg"/>
        </el-icon>
      </div>
    </div>
    <div class="no-img" v-else>
      <el-icon>
        <Plus/>
      </el-icon>
    </div>
    <el-upload
        ref="uploadRef"
        class="upload-demo"
        :on-success="(e) => handleSuccess(e)"
        :before-upload="(e) => handleBeforeUpload(e)"
        :data="otherData"
        :action="action"
        :show-file-list="false"
        :limit="1">
      <!--                <el-icon v-if="!item.iconImg">-->
      <!--                  <Plus/>-->
      <!--                </el-icon>-->
      <el-button type="primary">点击上传</el-button>


      <!--                <el-button type="primary">点击上传</el-button>-->
    </el-upload>
    <!--    <div v-if="props.img.url" style="display: flex;justify-content: center;margin-top: 10px">-->
    <!--      <el-button type="danger" @click="handleDelImg">删除</el-button>-->
    <!--    </div>-->
  </div>

  <!--  <CommodityImgUpload-->
  <!--      @addImg="handleAddImg"-->
  <!--      @delImg="handleDelImg"-->
  <!--      ref="upload"-->
  <!--      @success="handleUpload"-->
  <!--      :imgList="img"-->
  <!--  />-->

  <el-dialog v-model="dialogVisible" style="width: 50%">
    <img style="width: 100%" :src="dialogImageUrl" alt="Preview Image"/>
  </el-dialog>
</template>

<script setup>
import {defineProps, defineEmits, ref, onMounted} from 'vue'
import {Plus, ZoomIn, Delete} from '@element-plus/icons-vue';
import {baseUrl2} from "@/config";
import {ElLoading, ElMessage} from "element-plus";
// import CommodityImgUpload from './CommodityImgUpload'
const props = defineProps(['img'])
const emits = defineEmits(['handleRemove', 'addImg'])

// console.log(props.img, 'props.img')
const uploadRef = ref(null)

const isShow = ref(false)
const dialogImageUrl = ref('')
const dialogVisible = ref(false)
const handlePictureCardPreview = () => {
  dialogImageUrl.value = props.img.url
  dialogVisible.value = true
}

const fileList = ref([])
// eslint-disable-next-line

onMounted(() => {
  fileList.value = [
    props.img
  ]
})

const loading = ref(false)
// eslint-disable-next-line no-unused-vars
const handleBeforeUpload = (rawFile) => {
  console.log(rawFile)
  loading.value = ElLoading.service({
    lock: true,
    text: '上传图片中',
    background: 'rgba(0, 0, 0, 0.7)',
  })
}

// eslint-disable-next-line
const handleDelImg = () => { // 删除图片
  fileList.value = [];
  emits('handleRemove', props.img.name)
  uploadRef.value.clearFiles()
}

// eslint-disable-next-line
const handleUpload = (val) => {
  console.log(val)
}

/**
 * 上传成功操作
 */
const handleSuccess = (res) => {
  loading.value.close()
  console.log('success', res)
  // loading.value.close()
  if (res.code === '0') {
    ElMessage({
      message: '图片添加成功',
      type: 'success',
    })
  } else {
    ElMessage({
      message: res.msg,
      type: 'error',
    })
  }
  isShow.value = false
  // eslint-disable-next-line no-undef
  emits('addImg', {
    src: res.data,
    key: props.img.name
  })
}

const otherData = ref({
  moduleName: 'goods',
})
const action = ref(`${baseUrl2}/normal/uploadimg!execute.action`)

</script>

<style lang="scss" scoped>
img {
  display: block;
}

.btn {
  margin: 20px 10px;
}

:deep(.upload-demo) {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}

.no-img {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 140px;
  border: 2px dashed #ccc;

  i {
    font-size: 30px;
    color: #999;
  }
}

.img-wrapper {
  position: relative;

  .mask {
    z-index: 99;
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    background: rgba(0, 0, 0, .4);

    i {
      margin: 0 8px;
      font-size: 24px;
      color: #fff;
    }
  }
}


</style>