<template>
  <div class="cell-item">
    <div class="label">{{ props.label }}</div>
    <div style="width: 100%">
      <slot>
        <template v-if="props.type === 'number'">
          <el-input
              :type="props.type"
              v-model="value"
              :placeholder="$t(props.placeholder)"
              @change="handleChange"
              :disabled="disable"
              min="0"
          />
        </template>
        <template v-else>
          <el-input
              :type="props.type"
              v-model="value"
              :placeholder="$t(props.placeholder)"
              @change="handleChange"
              :disabled="disable"
          />
        </template>
      </slot>
    </div>
  </div>
</template>

<script setup>
import {defineProps, defineEmits} from 'vue'
import {useVModels} from '@vueuse/core'

const emits = defineEmits(['update:value'])

const props = defineProps({
  label: {},
  value: {},
  type: {
    default() {
      return ''
    }
  },
  placeholder: {
    default() {
      return '请输入'
    }
  },
  disable: {
    type: Boolean,
    default() {
      return false
    }
  }
})

const {value} = useVModels(props, emits)

const handleChange = val => {
  value.value = val
}
</script>

<style lang="scss" scoped>
.cell-item {
  display: flex;
  //justify-content: space-between;
  align-items: center;
  padding: 16px;

  .label {
    width: 120px;
    margin-right: 20px;
    font-size: 14px;
  }
}

:deep(.el-select) {
  width: 100%;
}
</style>