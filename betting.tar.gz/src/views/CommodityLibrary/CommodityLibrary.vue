<template>
    <div class="commodity-library">
        <div class="font-18">{{ $t('商品列表') }}</div>
        <div class="mt-15 select-wrapper">
            <div class="font-14">{{ $t('查询条件') }}</div>
            <el-form class="flex flex-wrap mt-10">
                <el-form-item class="mr-50" :label="`${$t('商品名称')}：`">
                    <el-input v-model="info.commodityName" :placeholder="$t('商品名称')"/>
                </el-form-item>
                <el-form-item class="mr-50" :label="`${$t('商品ID')}：`">
                    <el-input v-model="info.commodityId" :placeholder="$t('商品ID')"/>
                </el-form-item>
                <el-form-item class="mr-50" :label="`${$t('商品分类')}：`">
                    <BCategory
                            ref="BCategoryRef"
                            v-model="info.categoryId"
                            :lang="lang"
                    />
                </el-form-item>
                <el-form-item class="mr-50" :label="`${$t('商品状态')}：`">
                    <el-select v-model="info.isShelf" class="m-2" :placeholder="$t('商品状态')">
                        <el-option
                                v-for="item in shelfOptions"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value"
                        />
                    </el-select>
                </el-form-item>
                <el-form-item class="mr-50" :label="`${$t('锁定状态')}：`">
                    <el-select v-model="info.updateStatus" class="m-2" :placeholder="$t('锁定状态')">
                        <el-option
                                v-for="item in lockedState"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value"
                        />
                    </el-select>
                </el-form-item>
                <!--        <el-form-item label="时间：">-->
                <!--          <el-date-picker-->
                <!--              v-model="info.time"-->
                <!--              type="daterange"-->
                <!--              range-separator="至"-->
                <!--              start-placeholder="开始日期"-->
                <!--              end-placeholder="结束日期"-->
                <!--          />-->
                <!--        </el-form-item>-->
                <el-form-item>
                    <div style="padding: 5px">
                        <el-button type="primary" @click="handleSelect" :loading="selectLoading">{{
                            $t('查询')
                            }}
                        </el-button>
                    </div>
                    <div style="padding: 5px">
                        <el-button type="primary" @click="handleReset">{{ $t('重置') }}</el-button>
                    </div>
                </el-form-item>

            </el-form>
        </div>
        <div class="my-30">
            <el-button type="primary" @click="addCommodity">{{ $t('新增商品') }}</el-button>
            <!--      <el-button style="margin-left: 12px" type="primary" @click="dialogVisible = true">{{ $t('导入链接') }}</el-button>-->
        </div>
        <div class="result">
            <div class="font-14">{{ $t('查询结果') }}</div>
            <el-table v-loading="dataLoading" class="mt-15" max-height="800" :data="tableData.elements" border
                      style="width: 100%">
                <el-table-column prop="id" :label="$t('商品ID')" width="130"/>
                <el-table-column :label="$t('封面图')" width="200">
                    <template #default="scope">
                        <div style="display: flex; align-items: center; justify-content: center; overflow: hidden;height: 80px">
                            <el-image style="width: 100px;height: 100%;" :src="scope.row.imgUrl1" fit="cover">
                                <template #error>
                                    <div class="image-slot">
                                        <el-icon>
                                            <icon-picture/>
                                        </el-icon>
                                    </div>
                                </template>
                            </el-image>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column prop="goodName" :label="$t('商品名称')">
                    <template #default="scope">
                        <div style="overflow: hidden;
                        text-overflow: ellipsis;
                        display: -webkit-box;
                        -webkit-line-clamp: 2;
                        -webkit-box-orient: vertical;">
                            {{ scope.row.goodName }}
                        </div>
                    </template>
                </el-table-column>
                <el-table-column prop="categoryName" :label="$t('商品分类')" width="200" class-name="category"/>
                <el-table-column prop="secondCategoryName" label="二级分类" width="100" class-name="category"/>
                <el-table-column prop="systemPrice" :label="$t('进货价格')" width="180">
                    <template #default="scope">
                        <div>${{ scope.row.systemPrice.toFixed(2) }}</div>
                    </template>
                </el-table-column>
                <el-table-column prop="putOnShelves" :label="$t('是否上架')" width="100">
                    <template #default="scope">
                        <!--            <el-tag v-if="scope.row.isShelf / 1 === 1">上架</el-tag>-->
                        <!--            <el-tag v-else type="danger">下架</el-tag>-->
                        <el-switch :active-value="1" :inactive-value="0" :disabled="tableDataLoading"
                                   v-model="scope.row.isShelf"
                                   @change="handleChangeSwitch(scope.row)"/>
                    </template>
                </el-table-column>
                <el-table-column :label="$t('解锁状态')" width="84">
                    <!--          updateStatus-->
                    <template #default="scope">
                        <div class="flex justify-center" style="cursor: pointer"
                             @click="handleChangeLockedState(scope.row)">
                            <el-tag size="large" v-if="scope.row.updateStatus">{{ $t('已锁定') }}</el-tag>
                            <el-tag size="large" type="danger" v-else>{{ $t('未锁定') }}</el-tag>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column :label="$t('排序')" width="80"/>
                <!--        <el-table-column prop="buyMin" label="最小购买数量"/>-->
                <!--        <el-table-column prop="time" label="创建时间"/>-->
                <el-table-column :label="$t('销量')" width="100"/>
                <el-table-column :label="$t('操作')" width="250">
                    <template #default="scope">
                        <div class="flex">
                            <div class="flex align-center flex-col mr-15">
                                <el-button @click="toPage('/comment', scope.row)">{{ $t('评价库') }}</el-button>
                                <el-button class="mt-10" @click="toPage('/member-comments', scope.row)">会员评价
                                </el-button>
                            </div>
                            <div class="flex align-center flex-col" v-if="!scope.row.updateStatus">
                                <el-button type="primary" @click="editCommodity(scope.row.id)">{{
                                    $t('编辑')
                                    }}
                                </el-button>
                                <!--                <el-button class="mt-10" type="danger" @click="open(scope.row)">删除</el-button>-->
                            </div>
                        </div>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div class="flex justify-center mt-40" v-if="Object.keys(tableData).length > 0">
            <el-config-provider :locale="zhCn">
                <el-pagination
                        @size-change="pageSizeChange"
                        v-model:current-page="currentPage"
                        v-model:page-size="pageSize"
                        :page-sizes="[10, 20, 30, 50]"
                        background
                        layout="total, prev, pager, next, jumper"
                        :total="total"
                        @current-change="handleChangePage"
                />
            </el-config-provider>
        </div>
    </div>
  <!-- 导入链接 -->
    <el-dialog
            v-model="dialogVisible"
            :title="$t('导入链接')"
            width="40%"
            @close="handleClose"
    >
        <div>
            <div class="font-16">{{ $t('商品类型') }}</div>
            <el-select v-model="type" class="w-full mt-15" placeholder="Select">
                <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                />
            </el-select>
        </div>
        <div class="mt-40">
            <div class="font-16">{{ $t('商品链接') }}</div>
            <el-input class="mt-15" v-model="link" :placeholder="$t('商品链接')"/>
        </div>
        <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogVisible = false" style="margin-right: 12px">{{ $t('关闭') }}</el-button>
        <el-button type="primary" @click="handleConfirm">
          {{ $t('确认') }}
        </el-button>
      </span>
        </template>
    </el-dialog>
</template>

<script setup>
import {Picture as IconPicture} from '@element-plus/icons-vue'
import BCategory from '@/views/EditCommodity/BCategory'
import {useRouter} from "vue-router";
import {ElMessage, ElMessageBox} from 'element-plus'
import {onMounted, ref} from 'vue'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {baseUrl2} from "@/config";
import axios from "axios";
import {useI18n} from "vue-i18n";

const {t} = useI18n()

const router = useRouter()

const BCategoryRef = ref(null)
const dataLoading = ref(true);
const lang = ref('en')
const info = ref({
    commodityId: '', // ff808081847b9b2001847bb9cd7a0000
    commodityName: '', // 商品名称
    categoryId: '', // 项目分类
    state: '', // 商品状态
    isShelf: '', // 上下架
    updateStatus: '', // 锁定状态
    secondaryCategoryId: '',
})

const lockedState = ref([
    {
        value: '',
        label: t('全部'),
    },
    {
        value: '0',
        label: t('未锁定'),
    },
    {
        value: '1',
        label: t('已锁定'),
    },
])

const toPage = (path, data) => {

    router.push({
        path,
        query: {
            id: data.id
        }
    })
}

/**
 * 重置
 */
const handleReset = () => {
    // eslint-disable-next-line
    Object.keys(info.value).forEach(key => {
        info.value[key] = ''
    })
    _getTableData()
}

/**
 * 获取产品分类
 */
// const categoriesList = ref('')
// const getProductCategories = () => {
//   axios({
//     method: "post",
//     url: `${baseUrl2}/systemGoods/getGoodCategory.action?lang=${lang.value}`,
//
//   }).then((res) => {
//     categoriesList.value = res.data.data
//
//
//   });
// }

// getProductCategories()

// 页码
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref()
const handleChangePage = () => {
    _getTableData()
}

// 修改每页显示数据
const pageSizeChange = () => {
    _getTableData()
}

// 导入链接
const dialogVisible = ref(false)
const type = ref('')
const link = ref('')
const handleClose = () => {
    console.log('close')
}
const handleConfirm = () => {
    dialogVisible.value = false
}

const shelfOptions = [
    {
        value: '1',
        label: t('上架'),
    },
    {
        value: '0',
        label: t('下架'),
    },
]

/**
 * 查询
 */
const selectLoading = ref(false);
const tableData = ref({
    elements: [
        // {
        //   id: '123',
        //   name: '视频',
        //   goodName: 'segfs'
        // }
    ]
});
const handleSelect = () => {
    _getTableData()
}
const tableDataLoading = ref(false); // 列表数据是否在加载

// 请求分类数据
onMounted(() => {
    BCategoryRef.value.getProductCategories()
    _getTableData()
})

const _getTableData = () => {
    dataLoading.value = true
    tableDataLoading.value = true
    const params = {
        ...info.value,
        id: info.value.commodityId,
        name: info.value.commodityName,
        isShelf: info.value.isShelf,
        categoryId: info.value.categoryId,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
        updateStatus: info.value.updateStatus,
    }
    params.categoryId = info.value.categoryId ? info.value.categoryId[0] : undefined
    params.secondaryCategoryId = info.value.categoryId && info.value.categoryId.length > 1 ? info.value.categoryId[1] : undefined
    selectLoading.value = true
    axios({
        method: "post",
        url: `${baseUrl2}/systemGoods/list.action`,
        params
    }).then(res => {
        selectLoading.value = false
        if (res.data.data !== null) {
            tableData.value = res.data.data
            setTimeout(() => {
                // 获取商品分类
                BCategoryRef.value.kinds.length > 0 && tableData.value.elements.forEach(item => {
                    if (item.categoryId) {
                        const res = BCategoryRef.value.kinds.find(category => category.categoryId === item.categoryId)
                        if (res) {
                            item.categoryName = res.name
                            if (res.subList.length > 0) {
                                console.log(item);
                                res.subList.forEach(item2 => {
                                    if (item2.id === item.secondaryCategoryId) {
                                        item.secondCategoryName = item2.name
                                    }
                                })
                            }
                        }
                    }
                })
                total.value = tableData.value.totalElements
            }, 300)
        }

        setTimeout(() => {
            tableDataLoading.value = false
        }, 1000)
        dataLoading.value = false
    })
}

/**
 * 删除
 */
const deleteLoading = ref(false);
// eslint-disable-next-line no-unused-vars
const open = (data) => {
    ElMessageBox.confirm(
        `${t('你确定要删除吗')}?`,
        t('警告'),
        {
            confirmButtonText: t('确定'),
            cancelButtonText: t('取消'),
            type: 'warning',
        }
    )
        .then(() => {
            _deleteGood(data.id).then(res => {
                console.log(res)

                deleteLoading.value = false
                if (res.data.code === '0') {
                    _getTableData()
                    ElMessage({
                        type: 'success',
                        message: t('删除成功'),
                    })
                } else {
                    ElMessage({
                        type: 'error',
                        message: res.data.msg,
                    })
                }
            })

        })
        .catch(() => {
            ElMessage({
                type: 'info',
                message: t('取消删除'),
            })
        })
}
const _deleteGood = (id) => {
    const data = new FormData()
    data.append('id', id)
    deleteLoading.value = true
    return axios({
        method: "post",
        url: `${baseUrl2}/systemGoods/delete.action`,
        data: data
    })
}

// 新增商品
const addCommodity = () => {
    router.push({
        path: '/edit-commodity',
        query: {
            type: 'add' // 标识新增
        }
    })
}

// 编辑商品
const editCommodity = (id) => {
    router.push({
        path: '/edit-commodity',
        query: {
            type: 'edit', // 标识编辑
            id,
        }
    })
}

//
const handleChangeSwitch = (data) => {
    console.log(data);
    // eslint-disable-next-line
    const isShelf = data.isShelf ? 0 : 1;

    const formData = new FormData()
    formData.append('isShelf', data.isShelf)
    formData.append('id', data.id)
    axios({
        method: 'post',
        url: `${baseUrl2}/systemGoods/updateShelf.action`,
        data: formData
        // eslint-disable-next-line
    }).then(res => {
        // _getTableData()
        if (data.isShelf / 1 === 1) {

            ElMessage({
                type: 'success',
                message: t('上架成功'),
            })
        } else {

            ElMessage({
                type: 'success',
                message: t('下架成功'),
            })
        }
    })
}

/**
 * 修改解锁状态
 */
const handleChangeLockedState = (val) => {
    //  0-解锁 1-锁定
    const text = parseInt(val.updateStatus) ? '未锁定' : '已锁定';
    ElMessageBox.confirm(
        t(`你确定要修改状态为${text}吗?`),
        t('警告'),
        {
            confirmButtonText: t('确认'),
            cancelButtonText: t('取消'),
            type: 'warning',
        }
    )
        .then(() => {
            dataLoading.value = true

            const status = val.updateStatus ? 0 : 1;
            const formData = new FormData()
            formData.append('updateStatus', status);
            formData.append('id', val.id)
            axios({
                url: `${baseUrl2}/systemGoods/updateUpdateStatus.action`,
                method: 'post',
                data: formData
            }).then(res => {
                console.log(res.data);

                const index = tableData.value.elements.findIndex(item => item.id === val.id)
                tableData.value.elements[index].updateStatus = status;

                ElMessage({
                    type: 'success',
                    message: t('修改成功'),
                })

                dataLoading.value = false
            })
        })
        .catch(() => {
            ElMessage({
                type: 'info',
                message: t('取消修改'),
            })
        })
}
</script>

<style scoped>
@import "@/style/commodity-library.scss";

:deep(.image-slot) {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 36px;
    background-color: #e5e5e5;
    color: #ffffff;
}

:deep(.el-button+.el-button) {
    margin-left: 0;
}

:deep(.el-form-item ) {
    align-items: center;

}

:deep(.category) {
    white-space: nowrap;
}
</style>