<template>
  <div class="commodity-library">
    <el-button style="margin-bottom: 10px" type="primary" @click="router.go(-1)">{{ $t('返回') }}</el-button>
    <div class="select-wrapper">
      <el-form class="flex mt-10" label-width="120px">
<!--        <el-form-item label="会员账号：">-->
<!--          <el-input v-model="info.user" placeholder="会员账号"/>-->
<!--        </el-form-item>-->
        <!--        <el-form-item label="评分：">-->
        <!--          <el-select v-model="info.score" class="m-2" placeholder="评价">-->
        <!--            <el-option-->
        <!--                v-for="item in comment"-->
        <!--                :key="item.label"-->
        <!--                :label="item.value"-->
        <!--                :value="item.value"-->
        <!--            />-->
        <!--          </el-select>-->
        <!--        </el-form-item>-->
        <el-form-item label="状态：">
          <el-select v-model="info.status" class="m-2" placeholder="状态">
            <el-option
                v-for="item in statusOption"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <div style="padding: 5px">
            <el-button type="primary" @click="handleSelect" :loading="selectLoading">查询</el-button>
          </div>
          <div style="padding: 5px">
            <el-button type="primary" @click="handleReset">重置</el-button>
          </div>
        </el-form-item>

      </el-form>
    </div>
    <div class="my-30">
      <el-button type="primary" @click="dialogVisible = true;currentTitle = '新增评论'">{{ $t('新增评论') }}</el-button>
      <el-button type="danger" style="margin-left: 12px" @click="batchDelete">{{ $t('批量删除') }}</el-button>
    </div>
    <div class="result">
      <div class="font-14">{{ $t('查询结果') }}</div>
      <el-table v-loading="dataLoading" class="mt-15" @selection-change="handleSelectionChange" :data="table" border style="width: 100%">
        <el-table-column type="selection" width="55"/>
        <!--        <el-table-column label="评价" width="80">-->
        <!--          <template #default="scope">-->
        <!--            <el-tag v-if="scope.row.commentStatus / 1 === 1">好评</el-tag>-->
        <!--            <el-tag v-else-if="scope.row.commentStatus / 1 === 2" type="warning">中评</el-tag>-->
        <!--            <el-tag v-else type="danger">差评</el-tag>-->
        <!--          </template>-->
        <!--        </el-table-column>-->
        <el-table-column prop="score" :label="$t('评分')" width="80"/>
        <el-table-column prop="img" :label="$t('图片')" width="120">
          <template #default="scope">
            {{ scope.row.imgCount || 0 }} 张
          </template>
        </el-table-column>
        <el-table-column :label="$t('评价内容')">
          <template #default="scope">
            <div class="content" style="text-align: left">{{ scope.row.content }}</div>
          </template>
        </el-table-column>
        <el-table-column :label="$t('禁用评论')" width="180">
          <template #default="scope">
            <el-switch v-model="scope.row.status" @change="handleChangeSwitch(scope.row)" style="margin-left: 10px"/>
          </template>
        </el-table-column>
        <el-table-column :label="$t('操作')" width="300">
          <template #default="scope">
            <div class="flex">
              <div style="padding: 5px">
                <el-button @click="handleViewComment(scope.row)">{{ $t('查看评价') }}</el-button>
              </div>
              <div style="padding: 5px">
                <el-button type="danger" @click="open(scope.row.id)">{{ $t('删除') }}</el-button>
              </div>
              <div style="padding: 5px">
                <el-button type="primary" @click="editComment">{{ $t('编辑') }}</el-button>
              </div>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="flex justify-center mt-40">
      <el-config-provider :locale="zhCn">
        <el-pagination
            @size-change="pageSizeChange"
            v-model:current-page="currentPage"
            v-model:page-size="pageSize"
            :page-sizes="[10, 20, 30, 50]"
            background
            layout="total, prev, pager, next, jumper"
            :total="total"
            @current-change="handleChangePage"
        />
      </el-config-provider>
    </div>
  </div>
  <!-- 新增评论 -->
  <el-dialog
      :show-close="false"
      v-model="dialogVisible"
      :title="$t(currentTitle)"
      width="50%"
      :before-close="handleClose"
  >
    <el-form
        ref="ruleFormRef"
        :model="addInfo"
        :rules="rules"
    >
      <el-form-item class="img-upload" :label="$t('评论图片：')">
        <commodity-img-upload ref="imgLoad" @addImg="addImg" @beforeUpload="handleBeforeUpload"/>
        <div class="img-upload-tips">
          {{ $t('tips') }}
        </div>
      </el-form-item>
      <el-form-item class="img-upload" :label="`${$t('评价内容')}：`" prop="content">
        <el-input
            v-model="addInfo.content"
            :autosize="{ minRows: 2, maxRows: 4 }"
            type="textarea"
            :placeholder="$t('评价内容')"
        />
      </el-form-item>
      <el-form-item class="img-upload" :label="`${$t('会员评分')}：`" prop="score">
        <el-input type="number" v-model="addInfo.score" :placeholder="$t('请输入1-5分')" min="1" max="5">
          <template #suffix>
            <span style="color: #333">{{ $t('分') }}</span>
          </template>
        </el-input>
      </el-form-item>
<!--      <el-form-item :label="`${$t('选择时间')}：`" prop="createTime">-->
<!--        <el-date-picker-->
<!--            v-model="addInfo.createTime"-->
<!--            type="datetime"-->
<!--            :placeholder="$t('请选择时间')"-->
<!--            value-format="YYYY-MM-DD HH:mm:ss"-->
<!--        />-->
<!--      </el-form-item>-->
      <el-form-item :label="`${$t('禁用评论')}：`">
        <el-switch v-model="addInfo.status"/>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="submitForm(ruleFormRef)" :disabled="imgLoading">
          {{ $t('确定') }}
        </el-button>
                <el-button style="margin-left: 12px" @click="cancelAddComment(ruleFormRef)">{{ $t('取消') }}</el-button>
      </span>
    </template>
  </el-dialog>

  <!-- 查看评论 -->
  <el-dialog
      :show-close="false"
      v-model="viewComment"
      :title="$t('评论详情')"
      width="40%"
      :before-close="handleViewCommentClose"
  >
    <div>{{ currentComment.score }}分</div>
    <div class="comment-content">{{ currentComment.content }}</div>
    <div class="comment-img-wrapper" v-if="currentComment.imgList.length > 0">
      <el-image
          v-for="(item) in currentComment.imgList"
          :src="item"
          :key="item"
          :fit="'cover'"
      />
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="viewComment = false">
          {{ $t('确定') }}
        </el-button>
                <el-button style="margin-left: 12px" @click="viewComment = false">{{ $t('取消') }}</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import qs from 'qs'
import {useRouter, useRoute} from "vue-router";
import {ElMessage, ElMessageBox} from 'element-plus'
import {ref, reactive} from 'vue'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import {baseUrl, baseUrl2} from "@/config";
import axios from "axios";
import CommodityImgUpload from '../EditCommodity/CommodityImgUpload'

const route = useRoute()
// eslint-disable-next-line
const router = useRouter()

// 新增评论/编辑评论
const currentTitle = ref('');

const imgLoad = ref(null)

const goodId = route.query.id || '';

const lang = ref('en')

// eslint-disable-next-line
const comment = ref([
  {
    value: '全部',
    label: '全部',
  },
  {
    value: '好评',
    label: '好评',
  },
  {
    value: '中评',
    label: '全部',
  },
  {
    value: '差评',
    label: '差评',
  },
])

const statusOption = ref([
  {
    value: '',
    label: '全部',
  },
  {
    value: '1',
    label: '禁用',
  },
  {
    value: '0',
    label: '启用',
  },
])

const info = ref({
  user: '',
  status: '',
  score: '',
})

// 清空属性值
const clearVal = (obj) => {
  Object.keys(obj).forEach(key => obj[key] = '')

  addInfo.systemGoodId = goodId

  addInfo.status = false

  addImgCount.value = 0;

  // 清空图片
  imgLoad.value.removeFileList()
}

// 新增评论
const ruleFormRef = ref(null)
const addInfo = reactive({
  score: '',
  content: '',
  // createTime: '',
  status: false, //
  systemGoodId: goodId
})

// eslint-disable-next-line no-unused-vars
const validateNum = (rule, value, callback) => {
  if (value / 1 > 5 || value / 1 < 1 || value.indexOf('.') !== -1) {
    callback(new Error('请输入1-5分, 不能有小数'))
  } else {
    callback()
  }
}
const rules = reactive({
  score: [
    {required: true, message: '请输入会员评分', trigger: 'blur'},
    { validator: validateNum, trigger: 'blur' }
  ],
  content: [
    {
      required: true,
      message: '请输入评论内容',
      trigger: 'change',
    },
  ],
  createTime: [
    {
      type: 'date',
      required: true,
      message: '请选择时间',
      trigger: 'change',
    },
  ],
})

const addImgCount = ref(0)
const addImg = (data) => {
  addImgCount.value++
  addInfo['imgUrl' + addImgCount.value] = data
  imgLoading.value = false
}

// 图片上传时不能点击确定
const imgLoading = ref(false);
const handleBeforeUpload = () => {
  imgLoading.value = true
}

const submitForm = async (formEl) => {
  if (!formEl) return
  await formEl.validate((valid, fields) => {
    if (valid) {
      console.log('submit!')
      addComment()
      resetForm(formEl)
    } else {
      console.log('error submit!', fields)
    }
  })

  console.log(addInfo);
}

// 重置表单验证
const resetForm = (formEl) => {
  if (!formEl) return
  formEl.resetFields()
}

const addComment = () => {
  // 0启用 1禁用
  addInfo.status = addInfo.status ? 1 : 0;
  const formData = createFormData(addInfo)

  axios({
    method: 'post',
    url: `${baseUrl2}/systemGoods/addUpdateSystemComment.action`,
    // data: addInfo,
    data: formData,
  }).then(res => {
    console.log(res.data.data);
    dialogVisible.value = false
    getData()
    clearVal(addInfo)
  })
}

// 页码
const currentPage = ref(1)
const pageSize = ref(20)
const total = ref(0)
const handleChangePage = () => {
  console.log(currentPage.value)
  getData()
}

const table = ref([])

const imgCount = ref(0); // 图片数量

const dataLoading = ref(false)
const getData = () => {
  dataLoading.value = true
  // console.log(currentPage.value)
  // const data = {
  //   pageNum: currentPage.value,
  //   pageSize: pageSize.value,
  //   status: info.value.status,
  // }
  // const formData = new FormData()
  //
  // for (const key in data) {
  //   formData.append(key, data[key])
  // }

  let obj = {
    pageNum: currentPage.value,
    pageSize: pageSize.value,
    status: info.value.status,
    systemGoodId: goodId,
  }
  if (!obj.status) { // 全部的状态 不传该字段
    delete obj.status
  }
  axios({
    method: "post",
    url: `${baseUrl2}/systemGoods/listSystemComment.action?` + qs.stringify(obj),
  }).then(res => {
    dataLoading.value = false;
    console.log('获取数据', res.data.data)
    total.value = res.data.data.totalElements;
    // pageSize.value = res.data.data.pageSize;
    // currentPage.value = res.data.data.thisPageNumber
    const data = res.data.data.elements;
    data.forEach(item => {
      const keys = Object.keys(item)

      item.status = (item.status / 1) === 1

      keys.forEach(key => {
        if (key.indexOf('imgUrl') > -1) {
          if (item[key]) {
            imgCount.value++
          }
        }
      })

      item.imgCount = imgCount.value

      imgCount.value = 0
    })

    table.value = data;

    console.log(table.value);
  })
}
getData()

// 修改每页显示数据
const pageSizeChange = () => {
  getData()
}

// 批量删除
const batchDeleteIds = ref([])
const handleSelectionChange = (val) => {
  batchDeleteIds.value = []
  val.forEach(item => {
    batchDeleteIds.value.push(item.id)
  })
}

const batchDelete = () => {
  if (batchDeleteIds.value.length === 0) {
    ElMessage({
      message: '请选择要删除的评论',
      type: 'warning',
      duration: 3 * 1000
    })
    return
  }
  open(batchDeleteIds.value)
}

// 新增评论
const dialogVisible = ref(false);
const handleClose = () => {

}

// 查看评论
const viewComment = ref(false);
// eslint-disable-next-line
const currentComment = ref({});
// eslint-disable-next-line
const handleViewComment = (comment) => {
  const data = {
    ...comment,
    imgList: []
  }

  Object.keys(comment).forEach(key => {
    if (key.indexOf('imgUrl') > -1) {
      if (comment[key]) {
        data.imgList.push(comment[key])
      }
    }
  })

  currentComment.value = data

  viewComment.value = true
}
const handleViewCommentClose = () => {

}

/**
 * 重置
 */
const handleReset = () => {
  // eslint-disable-next-line
  Object.keys(info.value).forEach(key => {
    info.value[key] = ''
  })
}

/**
 * 获取产品分类
 */
const categoriesList = ref('')
// eslint-disable-next-line
const getProductCategories = () => {
  axios({
    method: "post",
    url: `${baseUrl}/systemGoods/getGoodCategory.action?lang=${lang.value}`,

  }).then((res) => {
    categoriesList.value = res.data.data
  });
}

// getProductCategories()

/**
 * 查询
 */
const selectLoading = ref(false);

const handleSelect = () => {
  getData()
}

/**
 * 删除
 */
const deleteLoading = ref(false);
const open = (id) => {
  ElMessageBox.confirm(
      '你确定要删除吗?',
      '警告',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
  )
      .then(() => {
        _deleteGood(id).then(res => {
          console.log(res)

          deleteLoading.value = false

          ElMessage({
            type: 'success',
            message: '删除成功',
          })

          getData()
        })

      })
      .catch(() => {
        ElMessage({
          type: 'info',
          message: '取消删除',
        })
      })
}

const _deleteGood = (ids) => {
  console.log('ids', ids)
  if (!Array.isArray(ids)) ids = [ids];

  ids = ids.join(',')
  deleteLoading.value = true

  const formData = createFormData({id: ids})

  console.log(formData.get('ids'));

  return axios({
    method: "post",
    url: `${baseUrl2}/systemGoods/deleteSystemComment.action`,
    data: formData
  })
}

// 取消新增评论
const cancelAddComment = (formEl) => {
  clearVal(addInfo)
  dialogVisible.value = false

  resetForm(formEl)
}

// 状态切换
const handleChangeSwitch = (comment) => {
  // 0启用 1禁用
  const status = comment.status ? 1 : 0;

  axios({
    method: 'post',
    url: `${baseUrl2}/systemGoods/updateSystemCommentStatus.action?id=${comment.id}&status=${status}`,
  }).then(res => {
    console.log(res);

    getData()
  })
}

const createFormData = data => {
  const formData = new FormData()

  for (const key in data) {
    formData.append(key, data[key])
  }

  return formData
}

// 编辑评论
const editComment = () => {
  currentTitle.value = '编辑评论'
  dialogVisible.value = true
}
</script>

<style lang="scss" scoped>
@import "@/style/commodity-library.scss";

:deep(.el-table th .cell) {
  text-align: center;
}

:deep(.el-button+.el-button) {
  margin-left: 0;
}

:deep(.el-form-item) {
  align-items: center;

}

:deep(.el-form-item.img-upload) {
  align-items: start;
}

.img-upload-tips {
  margin-top: 14px;
  line-height: 20px;
  font-size: 14px;
  color: #999;
}

.comment-content {
  margin: 15px 0;
  padding: 14px;
  background-color: #ddd;
  border-radius: 6px;
}

.comment-img-wrapper {
  display: grid;
  grid-template-columns: repeat(auto-fill, 150px);
  gap: 14px;

  :deep(.el-image) {
    min-width: 150px;
    min-height: 150px;
  }
}

:deep(.el-table .cell) {
  text-align: center;
}

.content {
  text-overflow: -o-ellipsis-lastline;
  overflow: hidden; //溢出内容隐藏
  text-overflow: ellipsis; //文本溢出部分用省略号表示
  display: -webkit-box; //特别显示模式
  -webkit-line-clamp: 6; //行数
  line-clamp: 6;
  -webkit-box-orient: vertical; //盒子中内容竖直排列
}

:deep(.el-form-item__label) {
  width: 170px;
  justify-content: flex-start;
}
</style>
