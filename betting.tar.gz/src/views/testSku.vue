
<template>
  <div  v-for="(item, index) in goodAttrs" :key="index">
    <div>{{ item.attrName }}</div>
    <el-checkbox
        :model-value="item2.check"
        v-for="(item2, index2) in item.attrValues"
        :key="index2"
        @change='checkboxChange(item2, index, index2)'
        :label="item2.attrValueName"
        size="large"
    />
  </div>
  <div>test i18n</div>
  <div>{{ $t('你好') }}</div>
  <button @click="changeLanguage">change language</button>
</template>

<script setup>
/* eslint-disable */
import { ref } from 'vue'
// eslint-disable-next-line no-unused-vars
import axios from "axios";
// eslint-disable-next-line no-unused-vars
import {baseUrl} from "@/config";
// eslint-disable-next-line no-unused-vars
import { useI18n } from 'vue-i18n'
// eslint-disable-next-line no-unused-vars

const {locale, t} = useI18n();

const changeLanguage = () => {
  locale.value = 'en-US'
}

const goodAttrs = ref([ //
  {
    attrId: "1",
    attrName: "颜色",
    attrValues: [
      {
        attrValueId: "aa",
        attrValueName: "中国红",
        check: false,
      },
      {
        attrValueId: "bb",
        attrValueName: "冰川蓝",
        check: false,
      }
    ]
  },
  {
    attrId: "2",
    attrName: "内存",
    attrValues: [
      {
        attrValueId: "cc",
        attrValueName: "6+64",
        check: false,
      },
      {
        attrValueId: "dd",
        attrValueName: "8+128",
        check: false,
      },
      {
        attrValueId: "ee",
        attrValueName: "12+256",
        check: false,
      },
    ]
  }
])

const checkboxChange = (val, index, index2) => {
  console.log('val', val)
  console.log(goodAttrs.value)
  goodAttrs.value[index].attrValues.splice(index2, 1, {...val ,check: !val.check,
    attrId: goodAttrs.value[index].attrId,
    attrName:goodAttrs.value[index].attrName})
  console.log(goodAttrs.value)
  chunks.value = []
  goodAttrs.value.forEach((res) => {
    let arr = res.attrValues.filter((res2) => {
      return res2.check
    })
    if (arr.length > 0) {
      chunks.value.push(arr)
    }
  })

  const arr = combine(chunks.value) // 全部排列组合
  console.log('chunks', arr)
  if (chunks.value.length === goodAttrs.value.length) {
    skus.value = []
    arr.forEach((item) => {
      console.log('push')
      skus.value.push({
        attrs: item
      })
    })

  }


  console.log('skus', skus.value)
}

const combine =  (chunks) => {
  let res = []

  let helper = function (chunkIndex, prev) {
    let chunk = chunks[chunkIndex]
    let isLast = chunkIndex === chunks.length - 1
    for (let val of chunk) {
      let cur = prev.concat(val)
      if (isLast) {
        // 如果已经处理到数组的最后一项了 则把拼接的结果放入返回值中
        res.push(cur)
      } else {
        helper(chunkIndex + 1, cur)
      }
    }
  }

  // 从属性数组下标为 0 开始处理
  // 并且此时的 prev 是个空数组
  helper(0, [])

  return res
}
const chunks = ref([])
const skus = ref([])

// const skus = ref([
//   {
//     "attrs": [
//       {
//         "attrId": "ff808081861d646401861db8c643004b",
//         "attrValueId": "ff808081861d646401861db8c644004f",
//         "attrName": "颜色",
//         "attrValueName": "中国红"
//       },
//       {
//         "attrId": "ff808081861d646401861db5ce760037",
//         "attrValueId": "ff808081861d646401861db5ce87003b",
//         "attrName": "内存",
//         "attrValueName": "6+64"
//       }
//     ],
//     "skuId": "ff808081861d64a801861db9e3f30053"
//   },
//   {
//     "attrs": [
//       {
//         "attrId": "ff808081861d646401861db8c643004b",
//         "attrValueId": "ff808081861d646401861db8c644004f",
//         "attrName": "颜色",
//         "attrValueName": "冰川蓝"
//       },
//       {
//         "attrId": "ff808081861d646401861db5ce760037",
//         "attrValueId": "ff808081861d646401861db5ce87003b",
//         "attrName": "内存",
//         "attrValueName": "8+128"
//       }
//     ],
//     "skuId": "ff808081861d64a801861db9e3f30053"
//   },
// ])


</script>
