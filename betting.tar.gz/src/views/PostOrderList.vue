<template>
  <div class="post-order-list">
    <div class="select">
      <el-form :inline="true" :model="formInline" class="demo-form-inline">
        <el-form-item :label="`${$t('任务编码')}:`">
          <el-input v-model="formInline.id" :placeholder="$t('任务编码')"></el-input>
        </el-form-item>
        <el-form-item :label="`${$t('状态')}:`">
          <el-select v-model="formInline.status" :placeholder="$t('状态')">
            <el-option :label="$t('全部')" value="-2"></el-option>
            <el-option :label="$t('进行中')" value="1"></el-option>
            <el-option :label="$t('系统结束')" value="2"></el-option>
            <el-option :label="$t('异常中断')" value="3"></el-option>
            <el-option :label="$t('已暂停')" value="4"></el-option>
            <el-option :label="$t('人工结束')" value="5"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="`${$t('创建时间')}:`">
          <el-date-picker
              v-model="formInline.time"
              type="daterange"
              value-format="YYYY-MM-DD"
              :range-separator="$t('至')"
              :start-placeholder="$t('开始日期')"
              :end-placeholder="$t('结束日期')">
          </el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">{{ $t('查询') }}</el-button>
          <el-button type="primary" @click="reset">{{ $t('重置') }}</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="table">
      <div class="opt">
        <!--        <el-button type="primary">一键执行</el-button>-->
        <el-button type="primary" @click="onBantchRemove">{{ $t('一键结束') }}</el-button>
      </div>
      <el-table :data="tableData" @selection-change="handleSelectionChange" style="width: 100%; height: 100%;">
        <el-table-column type="selection" width="55"/>
        <el-table-column prop="id" :label="$t('任务编码')">
          <template #default="scope">
            <el-link type="primary" @click="openOrderDetails(scope.row.id)">{{ scope.row.id }}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="startTime" :label="$t('开始日期')"/>
        <el-table-column prop="endTime" :label="$t('结束日期')"/>
        <el-table-column prop="orderNumAll" :label="$t('总订单')"/>
        <el-table-column prop="lumpAmount" :label="$t('订单总额')">
          <template #default="scope">
            {{ scope.row.lumpAmount.toFixed(2) }}
          </template>
        </el-table-column>
        <el-table-column prop="orderedNum" :label="$t('已下单')"/>
        <el-table-column prop="orderAmount" :label="$t('下单金额')">
          <template #default="scope">
            {{ scope.row.orderAmount.toFixed(2) }}
          </template>
        </el-table-column>
        <el-table-column prop="status" :label="$t('状态')">
          <template #default="scope">
            <div :style="{color: handleText(scope.row.status, '')}">{{ handleText(scope.row.status, 'text') }}</div>
          </template>
        </el-table-column>
        <el-table-column :label="$t('下单时间间隔')">
          <template #default="scope">
            {{ scope.row.orderSpacingEnd - scope.row.orderSpacingStart }}分钟
          </template>
        </el-table-column>
        <el-table-column :label="$t('单笔订单金额')">
          <template #default="scope">
            {{ (scope.row.buyAmountStart - scope.row.buyAmountEnd).toFixed(2) }}
          </template>
        </el-table-column>
        <el-table-column :label="$t('单个用户购买订单数量')">
          <template #default="scope">
            {{ scope.row.buyNumStart - scope.row.buyNumEnd }}
          </template>
        </el-table-column>
        <el-table-column prop="createUser" :label="$t('创建人')"/>

        <el-table-column fixed="right" :label="$t('操作')" width="120">
          <template #default="scope">
            <!--            <el-button-->
            <!--                link-->
            <!--                type="primary"-->
            <!--                size="small"-->
            <!--                @click.prevent="stopRow(scope.$index)"-->
            <!--            >-->
            <!--              暂停任务-->
            <!--            </el-button>-->
            <el-popconfirm :title="`${$t('即将结束任务')}?`" @confirm="removeRow(scope.row)">
              <template #reference>
                <el-button
                    link
                    type="primary"
                    size="small"
                    :disabled="tableLoading || scope.row.status / 1 === 5 || scope.row.status / 1 === 2 || scope.row.status / 1 === 3">
                  {{ $t('结束任务') }}
                </el-button>
              </template>
            </el-popconfirm>

          </template>
        </el-table-column>
      </el-table>
      <div class="flex justify-center mt-15">
        <el-config-provider :locale="zhCn">
          <el-pagination
              v-model:current-page="currentPage"
              v-model:page-size="pageSize"
              :page-sizes="[10, 20, 30, 50]"
              :small="small"
              :background="background"
              layout="total, prev, pager, next, jumper"
              :total="total"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
          />
        </el-config-provider>
      </div>
    </div>
  </div>
  <el-dialog
      v-model="dialogVisible"
      :title="$t('下单记录')"
      width="40%"
  >
    <OrderList :id="currentId"/>
  </el-dialog>
</template>
<script setup>
import {ref} from "vue";
import axios from "axios";
// import qs from "qs";
import {ElMessage} from 'element-plus'
import OrderList from "./OrderList.vue";
import {baseUrl} from "@/config";

// eslint-disable-next-line
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
// eslint-disable-next-line
import tw from 'element-plus/dist/locale/zh-tw.mjs'
// eslint-disable-next-line
import en from 'element-plus/dist/locale/en.mjs'

import {useI18n} from "vue-i18n";

const {t} = useI18n()


const formInline = ref({
  id: "",
  status: "",
  time: []
});
let currentId = ref("");
let tableData = ref([])
let currentPage = ref(1);
let total = ref(0);
let pageSize = ref(8);
const small = ref(false);
const background = ref(false);
let dialogVisible = ref(false);
let selectList = ref([]);

const tableLoading = ref(false)
const getTabelList = () => {
  const data = {
    pageNo: currentPage.value,
    pageSize: pageSize.value,
    status: formInline.value.status || -2,
    startTime: formInline.value.time?.length ? formInline.value.time[0] : '',
    endTime: formInline.value.time?.length ? formInline.value.time[1] : '',
    id: formInline.value.id
  }
  Object.keys(data).forEach(key => {
    if (!data[key]) {
      delete data[key];
    }
  })
  tableLoading.value = true
  axios({
    url: `${baseUrl}/api/orderRecord/list`,
    method: "post",
    contentType: "application/json",
    data
  }).then((res) => {
    if (res.status == 200) {
      tableLoading.value = false
      const data = res.data
      tableData.value = data.records;
      total.value = data.totalCount;
      console.log(tableData.value)
    }

  })
}
console.log('第一次加载数据')
getTabelList()
//查询
const onSubmit = () => {
  getTabelList()
}
//重置
const reset = () => {
  formInline.value.id = "";
  formInline.value.status = "";
  formInline.value.time = [];
}
const handleSelectionChange = (list) => {
  selectList.value = list;
}
//结束任务
const removeRow = (row) => {
  // console.log('row', row.status)
  // if ( row.status / 1 === 5) {
  //   ElMessage({
  //     type: 'error',
  //     message: `不能结束任务`,
  //   })
  //   return
  // }

  // eslint-disable-next-line no-unreachable
  axios({
    url: `${baseUrl}/api/item/cancel`,
    method: "post",
    data: {
      secret: "string",
      orderId: row.id,
    }
  }).then((res) => {
    console.log(res.data)
    if (res.status === 200) {
      ElMessage({
        type: 'success',
        message: t('操纵成功'),
      })
      console.log('结束加载数据')
      getTabelList()
    }
  })
}
const onBantchRemove = () => {
  const ids = selectList.value.map(item => item.id);
  axios({
    url: `${baseUrl}/api/item/cancelBatch`,
    method: "post",
    data: {
      secret: "dolor",
      orderId: ids,
    }
  }).then((res) => {
    if (res.status === 200) {
      ElMessage({
        type: 'success',
        message: t('操纵成功'),
      })
      getTabelList()
    }
  })
}
const handleSizeChange = (val) => {
  pageSize.value = val;
  getTabelList()
}
const handleCurrentChange = (val) => {
  currentPage.value = val;
  getTabelList()
}
/**
 * 打开订单弹窗，并且获取id
 * @param id
 */
const openOrderDetails = (id) => {
  currentId.value = id;
  dialogVisible.value = true;
}
const handleText = (index, type) => {
  switch (index) {
    case 1:
      return type === 'text' ? t('进行中') : '#e99d42';
    case 2:
      return type === 'text' ? t('系统结束') : '#ccc';
    case 3:
      return type === 'text' ? t('异常中断') : 'red';
    case 4:
      return type === 'text' ? t('已暂停') : 'red';
    case 5:
      return type === 'text' ? t('人工结束') : '#ccc';
    default:
      return type === 'text' ? '' : '';
  }
}
</script>
<style scoped lang="scss">
.mt-15 {
  margin-top: 15px;
}

.post-order-list {
  margin-top: 20px;
  margin-left: 20px;
}
</style>
