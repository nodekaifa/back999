<template>
  <div class="main">
    <div class="select">
      <el-form :inline="true" :model="formInline" class="demo-form-inline">
        <el-form-item :label="$t('商品名称')">
          <el-input v-model="formInline.goodName" :placeholder="$t('商品名称')" />
        </el-form-item>
        <el-form-item :label="$t('商品ID')">
          <el-input v-model="formInline.id" :placeholder="$t('商品ID')" />
        </el-form-item>
        <el-form-item :label="$t('商品分类')">
          <el-select v-model="formInline.categoryId" :placeholder="$t('商品分类')">
            <el-option v-for="item in attributes" :label="item.name" :key="item.id" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">{{ $t('查询') }}</el-button>
          <el-button type="primary" @click="onReset">{{ $t('重置') }}</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="opt">
      <el-button type="primary" @click="onAdd">{{ $t('新增商品') }}</el-button>
    </div>
    <div class="table">
      <el-table :data="tableData" style="width: 100%">
        <el-table-column prop="id" :label="$t('商品ID')" width="180" />
        <el-table-column :label="$t('封面图')" width="180" />
        <el-table-column prop="goodName" :label="$t('商品名称')" width="180" />
        <el-table-column prop="categoryName" :label="$t('商品分类')" width="180" />
        <el-table-column prop="systemPrice" :label="$t('进货价格')" width="180" />
        <el-table-column prop="isShelf" :label="$t('标签')" width="180" />
        <el-table-column prop="date" :label="$t('排序')" width="180" />
        <el-table-column prop="date" :label="$t('销量')" width="180" />
        <el-table-column  :label="$t('操作')" width="180">
          <template #default="scope">
            <el-button @click="onEdit(scope.row)">{{ $t('编辑') }}</el-button>
            <el-button type="danger" @click="onRemove(scope.row)">$t('删除')</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
          class="mt-15"
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 30, 50]"
          :small="small"
          :background="background"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
      />
    </div>
  </div>

</template>

<script setup>
import {ref} from "vue";
import axios from "axios";
import {baseUrl2} from "@/config";

const formInline = ref({
  id: "",
  goodName: "",
  categoryId: ""
})
const attributes = ref([]);

const tableData = ref([])
let currentPage = ref(1);
const background = ref(false);

let total = ref(0);
let pageSize = ref(8);
const small = ref(false);

/**
 * 获取表格数据
 */
const getData = () => {
  const data = {
    thisPageNumber: currentPage.value,
    pageSize: pageSize.value,
    id: formInline.value.id
  }
  Object.keys(data).forEach(key => {
    if(!data[key]) {
      delete data[key];
    }
  })
  axios({
    method: "post",
    url: `${baseUrl2}/admin_war_exploded/systemGoods/list.action`,
    data
  }).then(async (res) => {
    tableData.value = res.data.data.elements
    console.log('列表数据', res)
    total.value = res.data.data.totalElements;
  })
}
/**
 * 获取商品分类
 */
const getCategories = () => {
  axios({
    method: "post",
    url: `${baseUrl2}/admin_war_exploded/systemGoods/getAllAttributeCategory.action`,

  }).then((res) => {
    const data = res.data.data
    attributes.value = data
  });
}
getData()

getCategories()

const handleSizeChange = (val) => {
  pageSize.value = val;
  getData()
}
const handleCurrentChange = (val) => {
  currentPage.value = val;
  getData()
}

/**
 *  新增商品
 */
const onAdd = () => {

}
/**
 * 删除商品
 * @param row
 */
const onRemove = (row) => {
  axios({
    method: "post",
    url: `${baseUrl2}/admin_war_exploded/systemGoods/delete.action`,
    data: {
      id: row.id
    }
  }).then((res) => {
    getData()
    console.log(res)
  });
}

/**
 * 编辑商品
 * @param row
 */
const onEdit = (row) => {
  console.log(row);
}
/**
 * 搜索
 */
const onSubmit = () => {
  getData()
}

/**
 * 重置表单
 */
const onReset = () => {
 formInline.value = {
   id: "",
   goodName: "",
   categoryId: ""
 }
  getData()
}

</script>
