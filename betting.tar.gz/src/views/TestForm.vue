<template>
  <el-form
      ref="ruleFormRef"
      :model="add"
      :rules="rules"
      label-width="120px"
      class="demo-ruleForm"
      :size="formSize"
      status-icon
  >
    <el-form-item label="Activity name" prop="name">
      <el-input v-model="add.name"/>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm(ruleFormRef)">
        Create
      </el-button>
      <el-button @click="resetForm(ruleFormRef)">Reset</el-button>
    </el-form-item>
  </el-form>
</template>

<script setup>
import {reactive, ref} from 'vue'

const formSize = 'default'
const ruleFormRef = ref(false)
const add = reactive({
  nameA: '',
  region: '',
  count: '',
  date1: '',
  date2: '',
  delivery: false,
  type: [],
  resource: '',
  desc: '',
})

// eslint-disable-next-line
const validateNum = (rule, value, callback) => {
  if (value / 1 > 5 || value / 1 < 1 || value.indexOf('.') !== -1) {
    callback(new Error('请输入1-5分, 不能有小数'))
  } else {
    callback()
  }
}

const rules = reactive({

  name: [
    {required: true, message: 'Please input Activity name', trigger: 'blur'},
    {min: 3, max: 5, message: 'Length should be 3 to 5', trigger: 'blur'},
  ],
})

const submitForm = async (formEl) => {
  if (!formEl) return
  await formEl.validate((valid, fields) => {
    if (valid) {
      console.log('submit!')
    } else {
      console.log('error submit!', fields)
    }
  })
}

const resetForm = (formEl) => {
  if (!formEl) return
  formEl.resetFields()
}
</script>