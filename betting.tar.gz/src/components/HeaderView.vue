<template>
  <div class="header">
    <div class="left"></div>
    <div class="right">
      <el-dropdown>
        <span class="el-dropdown-link">
          root
          <el-icon class="el-icon--right">
            <arrow-down />
          </el-icon>
        </span>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item>退出</el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
</template>

<script setup>
import { ArrowDown } from "@element-plus/icons-vue";
</script>

<style scoped lang="scss">
.header {
  height: 100%;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  .el-dropdown-link {
    cursor: pointer;
    color: #fff;
    display: flex;
    align-items: center;
  }
}
</style>
