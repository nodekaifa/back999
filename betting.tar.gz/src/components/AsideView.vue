<template>
  <div class="aside">
    <div class="aside-menu">
      <div class="aside-menu__header">业务</div>
      <div :class="['aside-menu__list', current === 0 ? 'active' :'']" @click="go()">
        <el-icon style="margin-right: 10px"><IconMenu /></el-icon>商品库
      </div>
      <div :class="['aside-menu__list', current === 1 ? 'active' :'']"  @click="goOrder()">
        <el-icon style="margin-right: 10px"><IconMenu /></el-icon>订单库
      </div>
    </div>
  </div>
</template>

<script setup>
import { Menu as IconMenu } from "@element-plus/icons-vue";
import {useRouter} from "vue-router"
import {ref} from "vue";
const router = useRouter();
let current = ref(0);
const go = () => {
  current.value = 0;
  router.push('/')
};
const goOrder = () => {
  current.value = 1;
  router.push('/pos-history')
}
</script>

<style scoped lang="scss">
.aside {
  height: 100%;
  width: 100%;
  background-color: #f5f7f8;
  padding-top: 20px;

  &-menu {
    height: 100%;

    &__header {
      height: 20px;
      line-height: 20px;
      padding: 10px 20px;
    }

    &__list {
      height: 20px;
      line-height: 20px;
      color: #333;
      padding: 10px 20px;
      display: flex;
      align-items: center;

      &:hover {
        background-color: #c4c6c6;
        color: #fff;
        cursor: pointer;
      }
    }
    .active {
      background-color: #c4c6c6;
      color: #fff;
    }
  }
}
</style>
