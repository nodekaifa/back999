import { createApp } from "vue";
import App from "./App.vue";
import ElementPlus from "element-plus";
import "element-plus/dist/index.css";
import "./style/global.scss";
import i18n from "@/i18n";
import '@/style/init.scss'
import store from "@/store"

import router from "./router";

const app = createApp(App);
app.use(store)
app.use(i18n)
app.use(ElementPlus);
app.use(router).mount("#app");
