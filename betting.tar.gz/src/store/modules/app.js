import {defineStore} from "pinia"
import {useStorage} from "@vueuse/core"


export const useAppStore = defineStore('app', {
    state: () => useStorage('baseUrl2', {
        baseUrl2: ''
    }),
    actions: {
        getBaseUrl2() {
          //获取地址栏上的url参数，赋值给baseUrl2
            let url = window.location.href
            let index = url.indexOf('?')
            let str = url.substring(index + 1)
            let arr = str.split('&')
            let obj = {}
            for (let i = 0; i < arr.length; i++) {
                let arr2 = arr[i].split('=')
                obj[arr2[0]] = arr2[1]
            }
            this.baseUrl2 = obj.url
        }
    }
})
