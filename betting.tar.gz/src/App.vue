<template>
    <router-view v-slot="{Component}">
        <keep-alive>
            <component :is="Component" v-if="route.meta.keepAlive"/>
        </keep-alive>
        <component :is="Component" v-if="!route.meta.keepAlive"/>
    </router-view>
  <!--  <PostOrderList />-->
</template>
<script setup>
import {useRoute} from "vue-router";
import {useAppStore} from "@/store/modules/app.js";
const appStore = useAppStore()
const route = useRoute()


appStore.getBaseUrl2()

console.log(appStore.baseUrl2)

</script>
<style lang="scss">
.edit-commodity {
  .el-select-dropdown__wrap {
    max-height: none !important;
    height: 165px;
    overflow: hidden;
  }
}
</style>
