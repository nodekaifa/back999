import { createI18n } from 'vue-i18n'
// import { getStorage } from '@/utils/index.js'

import enLocale from './en'
import cnLocale from './cn'
import zhCnLocale from './zh-cn'
const lang = 'zh-CN'

const messages = {
  'en-US': {
    ...enLocale
  },
  'CN': {
    ...cnLocale
  },
  'zh-CN': {
    ...zhCnLocale
  },
}

const i18n = createI18n({
  legacy: false,
  locale: lang, // 首先从缓存里拿，没有的话就用浏览器语言，
  fallbackLocale: 'en', // 设置备用语言
  messages,
})

export default i18n