const { defineConfig } = require("@vue/cli-service");
module.exports = defineConfig({
  transpileDependencies: true,
  publicPath:'/download/',
  devServer: {
    proxy: {
      "/api": {
        changeOrigin: true,
        target: "https://tool.thsjbvh.site/", // 这是除产品规格编辑以外的测试域名
      },
      // "/systemGoods": {
      //   changeOrigin: true,
      //   target: "http://7s77pa.natappfree.cc/admin_war_exploded/", // https://tool.thsjbvh.site/
      // },
    },
  },
});
