import { createApp } from 'vue'
import './assets/css/index.css'
import './assets/css/init.css'
import 'vant/lib/index.css'
import fxHeader from '@/components/fx-header'
import 'default-passive-events'
// import './assets/css/init.scss'
// import 'amfe-flexible'
import App from './App.vue'
import i18n from '@/i18n'
import 'vant/es/toast/style';
import router from '@/router'
import pinia from '@/store'

const app = createApp(App)
app.use(fxHeader)

app.use(i18n)
app.use(router)
app.use(pinia)


app.mount('#app')
