import axios from 'axios'
// import qs from 'qs'
import { Toast, Notify } from 'vant'
import { BASE_URL, REQUEST_TIMEOUT, CONTENT_TYPE, CONTENT_TYPES, WITH_CREDENTIALS, METHODS } from '@/config'
import router from '../router';

// import store from '@/store'
import { useUserStore } from "@/store/user.js";


const logout = () => {
  let userStore = useUserStore()
  userStore.logout() // 恢复初始化
}


const service = axios.create({
  baseURL: BASE_URL,
  withCredentials: WITH_CREDENTIALS,
  timeout: REQUEST_TIMEOUT, // 请求超时时间
  headers: {
    [CONTENT_TYPE]: CONTENT_TYPES.URL_ENCODED
  }
})

// 请求拦截
service.interceptors.request.use(config => {
  if (!config) {
    config = {}
  }
  if (!config.headers) {
    config.headers = {}
  }
  if (config.method === METHODS.POST) {
    if (config.data) {
      // config.data = qs.stringify(config.data)
    }
  }
  const userStore = useUserStore()
  const TOKEN = userStore?.userInfo?.token
  if (TOKEN) { // 携带token
    // if (!config.headers['Authorization']) {
    //   config.headers['Authorization'] = `bearer ${TOKEN}`
    // }
    if (!config.params) {
      config.params = {}
    }
    config.params['token'] = TOKEN
  }
  if (config.loading) {
    Toast.loading({ forbidClick: true, duration: 0 })
  }
  return config
}, error => {
  return Promise.reject(error)
})

// 响应拦截
service.interceptors.response.use(res => {
  Toast.clear()
  // console.log(res.config.returnType)
  const { data: { code, data, msg, token } } = res
  if (res.config['returnType'] === 'origin') { // 原样返回
    return Promise.resolve(res.data)
  }

  if (code / 1 === 403) {
    logout()  // 登录状态已过期，您可以继续留在该页面，或者重新登录
  }
  switch (code / 1) {
    case 0: // 正确响应
      return Promise.resolve(data)
    // case 401:
    // case 402:
    // case 407:
    // case 424:   // 登录状态已过期，您可以继续留在该页面，或者重新登录
    //   logout()
    // break
    // case 403:   // 登录状态已过期，您可以继续留在该页面，或者重新登录
    //   logout()
    //   break
    default: // 直接弹出消息
      Toast(msg)
      return Promise.reject(msg);
  }
},
  error => { // 网络状态监控
    if (error && error.request) {
      const status = error.request['status']
      switch (status) {
        case 424:
          logout()
          break
        case 404:
          Toast({ message: '接口未找到', type: 'fail', duration: 2000 })
          break
        case 415:
          Toast({ message: 'HTTP协议不匹配，请确认', type: 'fail', duration: 2000 })
          break
        case 428:
          Toast({ message: '验证码不合法', type: 'fail', duration: 2000 })
          break
        // case 500:
        //   Toast({ message: '服务未启动', type: 'fail', duration: 2000 })
        //   break
        // default:
        //   Toast({ message: '服务错误', type: 'fail', duration: 2000 })
        //   break
        default:
          // console.log(error)
          Toast({ message: error.message || '服务错误', type: 'fail', duration: 2000 })

      }
    } else {
      Toast({ message: error.message || '服务错误', type: 'fail', duration: 2000 })
    }

    return Promise.reject(error)
  }
)

export default service