import axios from "axios";
import {METHODS} from "@/config/index.js";
import {useUserStore} from "@/store/user.js";
const userStore = useUserStore();

const service = axios.create({
  baseURL: '/wap/seller/report!head.action'
})


const _getSellerReport = params => {
  return service({
    method: METHODS.POST,
    params: {
      token: userStore.userInfo.token,
      ...params,
    }
  })
}

export {
  _getSellerReport,
}

