import request from './request'
import {METHODS} from "../config/index.js";

/**
 * 退货列表
 * @param token
 * @returns {Promise<axios.AxiosResponse<any>>}
 * @private
 */
export const _returnApply = () => {
    return request({
        url: "/wap/seller/orders!list-returns.action",
        method: METHODS.POST
    })
}
