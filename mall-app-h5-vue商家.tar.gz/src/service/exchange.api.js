import request from './request'
import { METHODS } from '@/config'

/**
 * 获取所有链地址
 */
export const exchangeGetBlockChain = () => request({ url: '/wap/api/channelBlockchain!list.action', method: METHODS.POST })


/**
 * 提现费率
 */
export const exchangeGetWithdrawFee = () => request({ url: '/wap/api/withdraw!fee.action', method: METHODS.POST })

/**
 * 提现 首次进入页面，传递session_token
 */
export const exchangeSetWithdrawToken = (params) => request({ url: '/wap/api/withdraw!withdraw_open.action', method: METHODS.POST, data: params })
/**
 * 提现申请
 */
export const exchangeGetWithdrawApply = (params) => request({ url: '/wap/api/withdraw!apply.action', method: METHODS.POST, data: params })


/**
 * 充值 首次进入页面，传递session_token
 */
export const exchangeSetRechargeToken = (params) => request({ url: '/wap/api/rechargeBlockchain!recharge_open.action', method: METHODS.POST, data: params })
/**
 * 充值申请
 */
export const exchangeGetRechargeApply = (params) => request({ url: '/wap/api/rechargeBlockchain!recharge.action', method: METHODS.POST, data: params })



/**
 * 充值记录
 */
export const exchangeGetRechargeRecord = (params) => request({ url: '/wap/api/rechargeBlockchain!list.action', method: METHODS.POST, data: params })


/**
 * 提现记录
 */
export const exchangeGetWithdrawRecord = (params) => request({ url: '/wap/api/withdraw!list.action', method: METHODS.POST, data: params })