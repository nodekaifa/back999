import request from './request'
import { METHODS } from '@/config'

//修改登录密码 用旧密码
export const _changePassword = (params) => {
    return request({
        url: "/wap/api/user!updateOldAndNewPsw.action",
        method: METHODS.POST,
        data: params
    })
};
//修改登录密码 用验证码
export const _updatepsw = (params) => {
    return request({
        url: "/wap/api/user!updatepsw.action",
        method: METHODS.POST,
        data: params
    })
};

//重置登录密码 用验证码 （用于忘记密码）
export const _resetpsw = (params) => {
    return request({
        url: "/wap/api/user!resetpsw.action",
        method: METHODS.POST,
        data: params
    })
};


//设置资金密码
export const _setSafewordReg = (params) => {
    return request({
        url: "/wap/api/user!setSafewordReg.action",
        method: METHODS.POST,
        data: params
    })
};
//修改资金密码 用旧密码
export const _changeFundsPassword = (params) => {
    return request({
        url: "/wap/api/user!updateOldAndNewSafeword.action",
        method: METHODS.POST,
        data: params
    })
};
//修改资金密码 用验证码
export const _setSafeword = (params) => {
    return request({
        url: "/wap/api/user!setSafeword.action",
        method: METHODS.POST,
        data: params
    })
};

//绑定邮箱
export const _bindEmail = (params) => {
    return request({
        url: "/wap/api/localuser!save_email.action",
        method: METHODS.POST,
        data: params
    })
};
//绑定手机
export const _bindPhone = (params) => {
    return request({
        url: "/wap/api/localuser!save_phone.action",
        method: METHODS.POST,
        data: params
    })
};
//获取验证方式(token)
export const _getVerifTarget = (params) => {
    return request({
        url: "/wap/api/user!getVerifTarget.action",
        method: METHODS.POST,
        data: params
    })
};

//获取验证方式（用户名）
export const _getUserNameVerifTarget = (params) => {
    return request({
        url: "/wap/api/user!getUserNameVerifTarget.action",
        method: METHODS.POST,
        data: params
    })
};


//获取谷歌验证器绑定信息
export const _getGoogleauth = (params) => {
    return request({
        url: "/wap/api/googleauth!get.action",
        method: METHODS.POST,
        data: params
    })
};

//谷歌验证器绑定
export const _bindGoogleauth = (params) => {
    return request({
        url: "/wap/api/googleauth!bind.action",
        method: METHODS.POST,
        data: params
    })
};

//获取人工重置信息
export const _getSafewordApply = (params) => {
    return request({
        url: "/wap/api/user!get_safeword_apply.action",

        method: METHODS.POST,
        data: params
    })
};
//人工重置申请
export const _setSafewordApply = (params) => {
    return request({
        url: "/wap/api/user!set_safeword_apply.action",
        method: METHODS.POST,
        data: params
    })
};


//高级认证申请
export const _kycHighLevelApply = (params) => {
    return request({
        url: "/wap/api/kycHighLevel!apply.action",
        method: METHODS.POST,
        data: params
    })
};
//高级认证信息
export const _getKycHighLevel = (params) => {
    return request({
        url: "/wap/api/kycHighLevel!get.action",
        method: METHODS.POST,
        data: params
    })
};

//轮播
export const _getBanner = (params) => {
    return request({
        url: "/wap/api/banner!list.action",
        method: METHODS.POST,
        data: params
    })
};

//服务条款
export const _getCms = (params) => {
    return request({
        url: "/wap/api/cms!get.action",
        method: METHODS.POST,
        data: params
    })
};


//获取新闻列表
export const _getNewsList = (params) => {
    return request({
        url: "/wap/api/news!list_v2.action",
        method: METHODS.POST,
        data: params,
    })
};

//获取新闻
export const _getNews = (params) => {
    return request({
        url: "/wap/api/news!get.action",
        method: METHODS.POST,
        data: params,
    })
};

//获取用户信息
export const _info = (params) => {
    return request({
        url: "/wap/api/localuser!get.action",
        method: "GET",
        data: params,
    })
}

// 获取余额
export const _getBalance = () => {
    return request({
        url: "/wap/api/wallet!getUsdt.action",
        method: "GET",
    })
};

// 申请认证
export const _applyIdentify = data => {
    return request({
        url: '/wap/api/kyc!apply.action',
        method: 'GET',
        loading: true,
        duration: 0,
        params: {
            nationality: data.countryName, // 国籍
            idname: data.idname || 'id/passpost', // 证件名称
            idnumber: data.idnumber, // 证件号码
            name: data.name, // 姓名
            idimg_1: data.frontFile.length && data.frontFile[0].resURL || '',
            idimg_2: data.reverseFile.length && data.reverseFile[0].resURL || '',
            idimg_3: data.fileList.length && data.fileList[0].resURL || ''
        }
    })
}

// 认证信息
export const _getIdentify = () => {
    return request({
        url: '/wap/api/kyc!get.action',
        method: 'GET'
    })
}

