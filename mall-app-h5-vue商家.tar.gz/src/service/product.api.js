import request from './request'
import {METHODS} from "../config/index.js";

//商品库
export const getSystemGoods = (data) => {
    return request({
        url: "/wap/seller/systemGoods!list.action",
        method: METHODS.POST,
        data
    })
}
//商家商品
export const merchantGoodsList = (data) => {
    return request({
        url: "/wap/seller/goods!list.action",
        method: METHODS.POST,
        data
    })
}
//商品分类
export const categoryList = (data) => {
    return request({
        url: "/wap/api/category!list.action",
        method: METHODS.POST,
        data
    })
}
//评论列表
export const getEvaluation = (data) => {
    return request({
        url: "/wap/seller/evaluation!list.action",
        method: METHODS.POST,
        data
    })
}
//商品库搜索
export const searchKeyword= (data) => {
    return request({
        url: "/wap/seller/systemGoods!search-keyword.action",
        method: METHODS.POST,
        data
    })
}
//商家商品搜索
export const searchSllerKeyword= (data) => {
    return request({
        url: "/wap/api/sellerGoods!search-keyword.action",
        method: METHODS.POST,
        data
    })
}
//修改商品信息
export const goodsUpdate= (data) => {
    return request({
        url: "/wap/seller/goods!update.action",
        method: METHODS.POST,
        data
    })
}
//商品库添加商品
export const goodsaddOrUpdate= (data) => {
    return request({
        url: "/wap/seller/goods!addOrUpdate.action",
        method: METHODS.POST,
        data
    })
}
//搜索后的商品列表
export const sellerGoodsList= (data) => {
    return request({
        url: "/wap/api/sellerGoods!search-goods.action",
        method: METHODS.POST,
        data
    })
}
