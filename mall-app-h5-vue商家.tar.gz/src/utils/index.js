import router from '@/router'

export function getImageUrl(path) {
  return new URL(path, import.meta.url).href
}

// 设置localStorage
export const setStorage = function (key, obj) {
  let json = JSON.stringify(obj)
  window.localStorage.setItem(key, json)
  // console.log('设置语言', key, json)
}

// 获取localStorage
export const getStorage = function (key) {
  const str = window.localStorage.getItem(key)
  if (!str) {
    return null
  }
  return JSON.parse(str)
}
// 获取浏览器默认语言
export const getBrowserLang = function () {
  let browserLang = navigator.language ? navigator.language : navigator.browserLanguage
  let defaultBrowserLang = ''
  if (browserLang.toLowerCase() === 'cn' || browserLang.toLowerCase() === 'zh' || browserLang.toLowerCase() === 'zh-cn') {
    defaultBrowserLang = 'CN'
  } else {
    defaultBrowserLang = 'en-US'
  }
  return defaultBrowserLang
}

export const dataTime = (data, isTrue) => {
  var date = new Date(data);
  let Y = date.getFullYear() + '-';
  let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
  let D = date.getDate() + ' ';
  let h = date.getHours() + ':';
  let m = date.getMinutes() + ':';
  let s = date.getSeconds();
  let str = Y + M + D
  if (isTrue) {
    str = Y + M + D + h + m + s
  } else {
    str = Y + M + D
  }
  return str
}

// 路由跳转
export function openPage(data, blank) {
  if (blank) {
    if (typeof data === 'string') {
      window.open(data)
    } else {
      const routeData = router.resolve(data)
      window.open(routeData.href)
    }
  } else {
    router.push(data)
  }
}
