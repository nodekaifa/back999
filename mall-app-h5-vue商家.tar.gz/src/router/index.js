// index.js
import { createRouter, createWebHashHistory } from 'vue-router'
import App from '@/App.vue'
import { useUserStore } from "@/store/user.js";
// const userStore = useUserStore()
// 路由规则
const routes = [
  {
    path: '/',
    component: App,
    children: [
      { path: '', redirect: '/shop' },
      {
        path: '/login',
        name: 'Login',
        component: () => import(/* webpackChunkName: "verify" */ /* webpackPrefetch: true */'@/views/login/index.vue'),
      },
      {
        path: '/shop',
        name: 'Shop',
        meta: {
          tarbar: true
        },
        component: () => import('@/views/shop/index.vue'),
      },
      {
        path: '/product',
        name: 'Product',
        meta: {
          tarbar: true
        },
        component: () => import('@/views/product/index.vue'),
      },
      {
        path: '/shop/basicInfo',
        name: 'BasicInfo',
        meta: {
          tarbar: false
        },
        component: () => import('@/views/shop/basicInfo/index.vue')
      },
      {
        path: '/shop/banner',
        name: 'ShopBanner',
        meta: {
          tarbar: false
        },
        component: () => import('@/views/shop/banner/index.vue')
      },
      {
        path: '/shop/social',
        name: 'ShopSocial',
        meta: {
          tarbar: false
        },
        component: () => import('@/views/shop/social/index.vue')
      },
      {
        path: '/shop/promotion',
        name: 'shopPromotion',
        meta: {
          tarbar: false
        },
        component: () => import('@/views/shop/promotion/index.vue')
      },
      {
        path: '/shop/marketing',
        name: 'ShopMarketing',
        meta: {
          tarbar: false
        },
        component: () => import('@/views/shop/marketing/index.vue')
      },
      {
        path: '/shop/marketing/record',
        name: 'ShopMarketingRecord',
        meta: {
          tarbar: false
        },
        component: () => import('@/views/shop/marketing/record/index.vue')
      },
      {
        path: '/productPage',
        name: 'productPage',
        meta: {
          tarbar: true
        },
        component: () => import('@/views/Layout.vue'),
        children: [
          { path: 'list', meta: { tarbar: false }, component: () => import('@/views/product/list.vue') }, //商品库
          { path: 'details', meta: { tarbar: false }, component: () => import('@/views/product/details.vue') }, //商品详情
          { path: 'comment', meta: { tarbar: false }, component: () => import('@/views/product/comment.vue') }, //商品评论

        ], //商品
      },
      {   // 订单
        path: '/order',  
        name: 'Order',
        meta: { tarbar: true },
        component: () => import('@/views/order/index.vue'),
        // children: [
        //   { path: 'submit', meta: { tarbar: true }, component: () => import('@/views/order/order-submit.vue') },
        //   { path: 'success', component: () => import('@/views/order/success.vue') }, //成功
        //   { path: 'apply-success', component: () => import('@/views/order/apply-success.vue') }, //申请成功
        // ]
      },
      {
        path: '/withdraw',
        name: 'Withdraw',
        meta: { tarbar: false },
        component: () => import('@/views/withdraw/index.vue'),
      },
      {
        path: '/withdraw/record',
        name: 'WithdrawRecord',
        meta: { tarbar: false },
        component: () => import('@/views/withdraw/record.vue'),
      },
      {
        path: '/recharge',
        name: 'Recharge',
        meta: { tarbar: false },
        component: () => import('@/views/recharge/index.vue'),
      },
      {
        path: '/recharge/:id',
        name: 'RechargeDetail',
        meta: { tarbar: false },
        component: () => import('@/views/recharge/detail.vue'),
      },
      {
        path: '/recharge/record',
        name: 'RechargeRecord',
        meta: { tarbar: false },
        component: () => import('@/views/recharge/record.vue'),
      },
      // {
      //   path: '/chart',
      //   redirect: '/chart/index',
      //   component: () => import('@/views/Layout.vue'),
      //   children: [
      //     { path: 'index/:symbol', meta: { tarbar: true }, component: () => import('@/views/charts/index.vue') },
      //     { path: 'order/:symbol', component: () => import('@/views/charts/order.vue') },
      //     { path: 'result', component: () => import('@/views/charts/result.vue') },
      //
      //   ]
      // },
      // {
      //   path: '/exchange',
      //   name: 'Exchange',
      //   redirect: '/exchange/list',
      //   // meta: { tarbar: true },
      //   component: () => import('@/views/Layout.vue'),
      //   children: [
      //     { path: 'list', meta: { tarbar: true }, component: () => import('@/views/exchange/List.vue') },
      //     { path: 'channel-in', name: 'channelIn', component: () => import('@/views/exchange/Channel.vue') },
      //     { path: 'channel-out', name: 'channelOut', component: () => import('@/views/exchange/Channel.vue') },
      //     { path: 'charge-bank', component: () => import('@/views/exchange/charge-bank.vue') },
      //     { path: 'charge-crypto', component: () => import('@/views/exchange/charge-crypto.vue') },
      //     { path: 'warehouse', component: () => import('@/views/exchange/warehouse.vue') },
      //     { path: 'withdraw-bank', component: () => import('@/views/exchange/withdraw-bank.vue') }, //银行卡提现
      //     { path: 'fund-password-verify', component: () => import('@/views/exchange/FundPasswordVerify.vue') }, //资金密码验证
      //     { path: 'withdraw-usdt', component: () => import('@/views/exchange/withdraw-usdt.vue') }, //usdt提现
      //   ]
      // },
	  {   // 采购确认
	    path: '/qr_order',  
	    name: 'qrOrder',
	    component: () => import('@/views/order/qr_order.vue'),
	  },
	  {   // 支付成功
	    path: '/passsuess',  
	    name: 'passsuess',
	    component: () => import('@/views/order/passsuess.vue'),
	  },
	  {   // 订单详情
	    path: '/orderdeails',  
	    name: 'orderdeails',
	    component: () => import('@/views/order/orderdeails.vue'),
	  },
      {
        path: '/chart',
        redirect: '/chart/index',
        component: () => import('@/views/Layout.vue'),
        children: [
          { path: 'index/:symbol', meta: { tarbar: true }, component: () => import('@/views/charts/index.vue') },
          { path: 'order/:symbol', component: () => import('@/views/charts/order.vue') },
          { path: 'result', component: () => import('@/views/charts/result.vue') },

        ]
      },
      {
        path: '/exchange',
        name: 'Exchange',
        redirect: '/exchange/list',
        // meta: { tarbar: true },
        component: () => import('@/views/Layout.vue'),
        children: [
          { path: 'list', meta: { tarbar: true }, component: () => import('@/views/exchange/List.vue') },
          { path: 'channel-in', name: 'channelIn', component: () => import('@/views/exchange/Channel.vue') },
          { path: 'channel-out', name: 'channelOut', component: () => import('@/views/exchange/Channel.vue') },
          { path: 'charge-bank', component: () => import('@/views/exchange/charge-bank.vue') },
          { path: 'charge-crypto', component: () => import('@/views/exchange/charge-crypto.vue') },
          { path: 'warehouse', component: () => import('@/views/exchange/warehouse.vue') },
          { path: 'withdraw-bank', component: () => import('@/views/exchange/withdraw-bank.vue') }, //银行卡提现
          { path: 'fund-password-verify', component: () => import('@/views/exchange/FundPasswordVerify.vue') }, //资金密码验证
          { path: 'withdraw-usdt', component: () => import('@/views/exchange/withdraw-usdt.vue') }, //usdt提现
        ]
      },
      {
        path: '/history',
        name: 'History',
        component: () => import('@/views/Layout.vue'),
        meta: { tarbar: true },
        redirect: '/history/list',
        children: [
          { path: 'list', meta: { tarbar: true }, component: () => import('@/views/history/List.vue') }
        ]
      },
      {
        path: '/my',
        name: 'My',
        redirect: '/my/index',
        component: () => import('@/views/Layout.vue'),
        meta: { tarbar: true },
        children: [
          { path: 'index', meta: { tarbar: true }, component: () => import('@/views/my/index.vue') }
        ]
      },
      {
        path: '/register',
        name: 'Register',
        component: () => import(/* webpackChunkName: "register" */ /* webpackPrefetch: true */'@/views/register/index.vue'),
        // meta: { tarbar: true },
      },
      { //验证码
        path: '/verify',
        name: 'verify',
        component: () => import(/* webpackChunkName: "verify" */ /* webpackPrefetch: true */'@/views/register/verify.vue')
      },
      { //设置资金密码
        path: '/setFond',
        name: 'setFond',
        component: () => import(/* webpackChunkName: "setFond" */ /* webpackPrefetch: true */'@/views/register/setFond.vue')
      },
      { //注册身份认证
        path: '/identity',
        name: 'identity',
        component: () => import(/* webpackChunkName: "identity" */ /* webpackPrefetch: true */'@/views/register/identity.vue')
      },
      { //谷歌验证
        path: '/gooleVerify',
        name: 'gooleVerify',
        component: () => import(/* webpackChunkName: "gooleVerify" */ /* webpackPrefetch: true */'@/views/register/gooleVerify.vue')
      },
      { //注册完成
        path: '/finish',
        name: 'finish',
        component: () => import(/* webpackChunkName: "finish" */ /* webpackPrefetch: true */'@/views/register/finish.vue')
      },
      {   //语言设置
        path: '/language',
        name: 'language',
        component: () => import(/* webpackChunkName: "language" */ /* webpackPrefetch: true */'@/views/language/index.vue')
      },
      { //客服
        path: '/customerService',
        name: 'customerService',
        component: () => import(/* webpackChunkName: "customerService" */ /* webpackPrefetch: true */'@/views/customerService/index.vue')
      },
      {//修改登录密码
        path: '/changePassword',
        name: 'changePassword',
        component: () => import(/* webpackChunkName: "changePassword" */ /* webpackPrefetch: true */'@/views/changePassword/index.vue')
      },
      {//修改资金密码
        path: '/changeFundsPassword',
        name: 'changeFundsPassword',
        component: () => import(/* webpackChunkName: "changeFundsPassword" */ /* webpackPrefetch: true */'@/views/changeFundsPassword/index.vue')
      },
      {//绑定验证
        path: '/bindVerify',
        name: 'bindVerify',
        component: () => import(/* webpackChunkName: "bindVerify" */ /* webpackPrefetch: true */'@/views/bindVerify/index.vue')
      },
      {//重置绑定
        path: '/resetVerify',
        name: 'resetVerify',
        component: () => import(/* webpackChunkName: "resetVerify" */ /* webpackPrefetch: true */'@/views/resetVerify/index.vue')
      },
      {//安全中心
        path: '/safety',
        name: 'safety',
        component: () => import(/* webpackChunkName: "safety" */ /* webpackPrefetch: true */'@/views/safety/index.vue')
      },
      {//更换绑定
        path: '/changeVerify',
        name: 'changeVerify',
        component: () => import(/* webpackChunkName: "changeVerify" */ /* webpackPrefetch: true */'@/views/safety/changeVerify.vue')
      },
      {
        //服务条款
        path: '/TermsOfService',
        name: 'TermsOfService',
        component: () => import(/* webpackChunkName: "TermsOfService" */ /* webpackPrefetch: true */'@/views/termsOfService/index.vue')
      },
      {//
        path: '/resetSuccess',
        name: 'resetSuccess',
        component: () => import(/* webpackChunkName: "resetSuccess" */ /* webpackPrefetch: true */'@/views/resetVerify/resetSuccess.vue')
      },
      {//忘记密码
        path: '/forget',
        name: 'forget',
        component: () => import(/* webpackChunkName: "forget" */ /* webpackPrefetch: true */'@/views/forget/index.vue')
      },
      {//重置登录密码
        path: '/resetPassword',
        name: 'resetPassword',
        component: () => import(/* webpackChunkName: "resetPassword" */ /* webpackPrefetch: true */'@/views/forget/resetPassword.vue')
      },
      {//忘记密码修改成功
        path: '/passSuccess',
        name: 'passSuccess',
        component: () => import(/* webpackChunkName: "passSuccess" */ /* webpackPrefetch: true */'@/views/forget/passSuccess.vue')
      },
      {//安全验证
        path: '/safeVerify',
        name: 'safeVerify',
        component: () => import(/* webpackChunkName: "safeVerify" */ /* webpackPrefetch: true */'@/views/forget/safeVerify.vue')
      },
      {//重置邮箱/手机号
        path: '/resetPane',
        name: 'resetPane',
        component: () => import(/* webpackChunkName: "resetPassword" */ /* webpackPrefetch: true */'@/views/resetPane/index.vue')
      },
      {//设置
        path: '/setting',
        name: 'setting',
        component: () => import(/* webpackChunkName: "safeVerify" */ /* webpackPrefetch: true */'@/views/setting/index.vue')
      },
      {//个人信息
        path: '/personalInfo',
        name: 'personalInfo',
        component: () => import(/* webpackChunkName: "safeVerify" */ /* webpackPrefetch: true */'@/views/personalInfo/index.vue')
      },
      {//登录密码修改成功
        path: '/successChange',
        name: 'successChange',
        component: () => import(/* webpackChunkName: "safeVerify" */ /* webpackPrefetch: true */'@/views/successChange/index.vue')
      },
      {//refundRequest
        path: '/refundRequest',
        name: 'refundRequest',
        component: () => import(/* webpackChunkName: "safeVerify" */ /* webpackPrefetch: true */'@/views/refundRequest/index.vue')
      },
      {//名称
        path: '/name',
        name: 'name',
        component: () => import(/* webpackChunkName: "safeVerify" */ /* webpackPrefetch: true */'@/views/name/index.vue')
      },
      {//电话
        path: '/number',
        name: 'number',
        component: () => import(/* webpackChunkName: "safeVerify" */ /* webpackPrefetch: true */'@/views/number/index.vue')
      },

      {//邮箱
        path: '/email',
        name: 'email',
        component: () => import(/* webpackChunkName: "safeVerify" */ /* webpackPrefetch: true */'@/views/email/index.vue')
      },
       {//搜索
        path: '/search',
        name: 'search',
        component: () => import(/* webpackChunkName: "safeVerify" */ /* webpackPrefetch: true */'@/views/search/index.vue')
      },
      {
        path: '/:pathMatch(.*)*',
        name: '404',
        component: () => import('@/views/404.vue')
      },
      {
        path: '/order',
        name: 'order',
        // meta: { tarbar: true },
        component: () => import('@/views/Layout.vue'),
        children: [
          // { path: 'submit', meta: { tarbar: true }, component: () => import('@/views/order/order-submit.vue') },
          // { path: 'success', component: () => import('@/views/order/success.vue') }, //成功
          // { path: 'apply-success', component: () => import('@/views/order/apply-success.vue') }, //申请成功
        ]
      },
      {
        path: '/Record',
        name: 'Record',
        // meta: { tarbar: true },
        component: () => import('@/views/Layout.vue'),
        children: [
          { path: 'DepositAndWithdrawal', meta: { tarbar: false }, component: () => import('@/views/Record/DepositAndWithdrawal.vue') },
          { path: 'RecordDetails', meta: { tarbar: false }, component: () => import('@/views/Record/RecordDetails.vue') }
        ], //充值和提现记录
      },
      {
        path: '/payMentMethod',
        name: 'payMentMethod',
        // meta: { tarbar: true },
        component: () => import('@/views/Layout.vue'),
        children: [
          { path: 'list', meta: { tarbar: false }, component: () => import('@/views/payMentMethod/list.vue') },
          { path: 'add', meta: { tarbar: false }, component: () => import('@/views/payMentMethod/add.vue') },
          { path: 'selectPay', meta: { tarbar: false }, component: () => import('@/views/payMentMethod/selectPay.vue') },
        ], //收款方式
      },
      { // 资金记录
        path: '/fundsRecords',
        component: () => import('@/views/fundsRecords/index.vue')
      },
      { // 财务管理
        path: '/finance',
        component: () => import('@/views/FinancialStatements/index.vue')
      }
    ]
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

router.beforeEach(async (to, from, next) => {
  if (to.name !== 'Login') {
    const userStore = useUserStore()
    await userStore.getUserInfo()
    next()
  } else {
    next()
  }
})

export default router
