<template lang="pug">
section.my-index
    fx-header(title="我的" :showLeft="false")
        template(v-slot:right)
            van-icon(name="service-o" size="18" @click="$router.push('/customerService')")
    div.px-4.mt-4
        h1.text-2xl.font-bold 欢迎来到DEMO!
        p.w-full.flex.mt-4.gap-x-4(v-if="!(userStore.userInfo&&userStore.userInfo.token)")
            van-button.flex-1(@click="onRoute('/register')") {{$t('register')}}
            van-button.flex-1(type='primary' @click="onRoute('/login')") {{$t('login')}}
        div.mt-8.flex(v-else)
            img.w-16.h-16(src="@/assets/image/avatar.png" alt="avatar")
            div.ml-2.flex.flex-col.justify-center
                div.font-bold.text-lg {{userStore.userInfo&&userStore.userInfo.username}}
                div.text-sm.text-gray-400.mt-1.flex.items-center ID：{{userStore.userInfo&&userStore.userInfo.usercode}}
                    img.w-4.h-4.ml-2(src="@/assets/image/idcopy.png" alt="id" @click="copy")

    div.mt-4
        van-cell-group(v-for="(item, index) in cellList" :key="index" :title="item.title" :border="false" )
            van-cell(v-for="(_item, _index) in item.list" key="_index" is-link center :icon="_item.icon" :title="_item.title" @click="onRoute(_item.path)")
    div.px-4.mt-4(v-if="userStore.userInfo&&userStore.userInfo.token")
        p.w-full.flex.mt-4.gap-x-4
            van-button.flex-1(@click="loginOut") {{$t('loginOut')}}
</template>

<script setup>
import { reactive, onMounted, ref, computed } from 'vue';
import { useRouter } from 'vue-router';
import { _getIdentify } from "@/service/user.api.js";
import { useUserStore } from '@/store/user';
import { useI18n } from "vue-i18n";
import useClipboard from "vue-clipboard3";
import { Toast } from "vant";
const { t } = useI18n()
const { toClipboard } = useClipboard();

const router = useRouter()
const userStore = useUserStore()
const status = ref(0)
const state = reactive({
    cellList: [
        {
            title: t('safe'), list: [
                { icon: 'shield-o', title: t('safe'), path: '/safety' },
                { icon: 'setting-o', title: t('changePassword'), path: '/changePassword' }
            ]
        },
        {
            title: t('universal'), list: [
                { icon: 'font-o', title: t('language'), path: '/language' },
                { icon: 'service-o', title: t('onLineService'), path: '/customerService' }
            ]
        }
    ]
})
const onRoute = (path) => {
    console.log(path)
    router.push(path)
}
onMounted(() => {
    // getIdentify()
})
const cellList = computed(() => {
    if (userStore.userInfo && userStore.userInfo.token) {
        return [
            {
                title: t('safe'), list: [
                    { icon: 'shield-o', title: t('safe'), path: '/safety' },
                    { icon: 'setting-o', title: t('changePassword'), path: '/changePassword' }
                ]
            },
            {
                title: t('universal'), list: [
                    { icon: 'font-o', title: t('language'), path: '/language' },
                    { icon: 'service-o', title: t('onLineService'), path: '/customerService' }
                ]
            }
        ]
    } else {
        return [
            {
                title: t('universal'), list: [
                    { icon: 'font-o', title: t('language'), path: '/language' },
                    { icon: 'service-o', title: t('onLineService'), path: '/customerService' }
                ]
            }
        ]
    }

})
const loginOut = () => {
    userStore.userInfo = {}
}
const getIdentify = () => {
    _getIdentify().then(data => {
        status.value = data.status
    })
}
const copy = async () => {
    try {
        await toClipboard(userStore.userInfo && userStore.userInfo.usercode);
        Toast(t('copySuccess'));
    } catch (e) {
        console.error(e);
    }
}
</script>

<style lang="scss" scoped>
:deep(.van-cell-group__title) {
    background: #f6f6f6;
    padding: 12px 16px;
}
</style>
