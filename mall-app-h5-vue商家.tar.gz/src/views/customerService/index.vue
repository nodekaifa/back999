<template>
  <div class="service-box flex flex-col pb-150" style="height: 100vh">
    <div>
      <van-nav-bar ref="navEl" :title="$t('onLineService')" left-arrow @click-left="onClickLeft" fixed/>
      <!-- <div class="px-3.5 py-5" :style="{'margin-top': navHeight + 'px'}"> -->
        <!-- <div class="text-xl black">订单将在 <span style="color: #2555F8">13：03</span> 后取消</div>
        <div class="mt-3 text-sm">
          <span class="mr-1" style="color: #8A919E">总额</span>
          <span class="black">$ 33,350.00</span>
        </div>
        <div class="mt-5">
          <van-button class="w-full" type="primary" @click="router.back()">去付款</van-button>
        </div> -->
      <!-- </div> -->
    </div>
    <div class="content flex-1 overflow-auto" :style="{'margin-top': navHeight + 'px', 'padding-bottom': '70px'}">
      <div class="flex flex-col px-16 box-border" style="background: #F5F5F5">
        <div class="w-full py-4 text-grey text-center pt-100" @click="onMore"
             :style="{ 'display': finished ? 'none' : 'block' }">
          {{ $t('historyMessage') }}
        </div>
        <ul class="flex flex-col pt-3">
          <li v-for="(item, index) in list" :key="item.id" class="flex flex-col my-3">
            <p class="font-13 text-center py-2 text-grey" v-if="showTime(index)">{{
                item.createtime &&
                item.createtime.split(' ')[0]
              }}</p>
            <div class="flex responser-content" :class="item.send_receive === 'send' ? 'justify-end' : ''">
              <template v-if="item.send_receive === 'receive'">
                <img :src="iconImg.responser" class="res"/>
                <div class="responser px-25 py-18 font-15 font-13 chatBg res-content">
                  <p class="break-word textColor" style="max-width: 115px;"
                     v-if="item.type === 'text'">{{ item.content }}</p>
                  <img v-else :src="item.content" class="w-200 h-200"
                       @click="onPreview(item.content)"/>
                </div>
              </template>
              <div class="py-12 px-12 rounded-md flex flex-col chatBg" v-else>
                <img :src="`${item.content}`" class="w-200 h-200" v-if="item.type === 'img'"
                     @click="onPreview(item.content)"/>
                <p class="break-word textColor" v-else style="max-width: 115px;">{{ item.content }}</p>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div
        class="bottom bottomBox flex justify-between items-center w-full fixed bottom-0 borderTop px-4 box-border bgBottom bg-white">
      <van-uploader :max-size="10000 * 1024" @oversize="onOversize" :after-read="afterRead"
                    :capture="androidAttrs ? 'camera' : null">
        <img :src="iconImg.photo" class="w-9 h-9"/>
      </van-uploader>
      <input type="text" v-model="message" :placeholder="$t('entryYouMessage')"
             class="flex-1 mx-3 h-full border-none bgBottom textColor"/>
      <img :src="iconImg.send" class="w-9 h-9" @click="send('text', message)"/>
    </div>
  </div>
</template>

<script setup>
import {Uploader, ImagePreview} from 'vant'
import {_getMsg, _getUnreadMsg, _sendMsg} from '@/service/im.api'
import {_uploadImage} from '@/service/upload.api'
import {ref, onMounted, onUnmounted} from "vue";
import {useI18n} from "vue-i18n";
import {Toast} from "vant";
import {useRouter} from "vue-router";

const {t} = useI18n()

const router = useRouter()
const list = ref([])
const message = ref('')
const lastMsgId = ref('')
const interval = ref(null)
const unread = ref(0)
const finished = ref(false)
const androidAttrs = ref(null)
const navEl = ref(null);
const navHeight = ref(0);
const startInterval = ref(false)

const iconImg = {
  responser: new URL('../../assets/image/service/responser.png', import.meta.url),
  photo: new URL('../../assets/image/service/photo.png', import.meta.url),
  send: new URL('../../assets/image/service/send.png', import.meta.url)
}

onMounted(() => {
  navHeight.value = navEl.value.$el.getBoundingClientRect().height

  startInterval.value = false
  fetchList()
  const model = navigator.userAgent;
  // 判断是否是安卓手机，是则是true
  androidAttrs.value = model.indexOf('Android') > -1 || model.indexOf('Linux') > -1
})

const onOversize = (file) => {
  Toast(t('fileMaxLimit'));
}
const onPreview = (url) => { // 预览
  ImagePreview([url])
}
const showTime = (index) => { // 时间显示
  if (index === 0) {
    return true
  }
  if (index === list.value.length - 1) {
    return false
  }
  if (list.value[index].createtime.split(' ')[0] === list.value[index + 1].createtime.split(' ')[1]) {
    return false
  }
}
const afterRead = (file) => { // 文件上传
  Toast.loading({duration: 0})
  _uploadImage(file, (percent) => {
    console.log(percent)
  }).then(data => {
    Toast.clear()
    send('img', data)
  }).catch(() => {
    Toast.clear()
  })
}
const fetchList = (message_id = '') => { // 获取消息列表
  _getMsg({message_id}).then(data => { //
    if (!lastMsgId.value) {
      lastMsgId.value = data.length && data[data.length - 1]['id']
    }
    if (data.length) {
      if (message_id) { // 加载更多
        lastMsgId.value = data[data.length - 1]['id']
        list.value = [...data.reverse(), ...list.value]
      } else {
        list.value = [...list.value, ...data.reverse()]
        let hash = {};
        list.value = list.value.reduce(function (preVal, curVal) {
          hash[curVal.id] ? ' ' : hash[curVal.id] = true && preVal.push(curVal);
          return preVal
        }, []);
      }
      if (data.length < 10) {
        finished.value = true
      }
    }

    if (!startInterval.value) {
      startInterval.value = true
      interval.value = setInterval(() => {
        fetchList()
      }, 1000)
    }
  })
}

const onMore = () => { // 加载更多
  fetchList(lastMsgId.value)
}
const clearIntervalTimer = () => {
  if (interval.value) {
    clearInterval(interval.value)
    interval.value = null
  }
}
const fetchUnread = () => { // 获取未读
  _getUnreadMsg().then(data => {
    unread.value = data
    // console.log(data)
  })
}
const onClickLeft = () => { // 返回
  router.go(-1);
}
const send = (type = 'text', content = '') => { // 发送消息, img 也当消息text
  if (!content) {
    Toast(t('entryMessageContent'))
    return
  }
  _sendMsg(type, content).then(data => {
    console.log(data)
    message.value = ''
    // document.getElementById('bottom').click()
    fetchList()
  })
}
onUnmounted(() => {
  clearIntervalTimer()
})


</script>
<style lang="scss" scoped>
.service-box {
  width: 100%;
  box-sizing: border-box;

  :deep(.van-hairline--bottom::after) {
    border-color: #f3f3f3;
  }
}

.break-word {
  word-wrap: break-word;
}

.max-w-230 {
  max-width: 115px;
}

.responser {
  position: relative;

  &::after {
    content: '';
    width: 0;
    height: 0;
    border-top: 5px solid transparent;
    border-bottom: 5px solid transparent;
    border-right: 10px solid #f3f3f3;
    position: absolute;
    left: -10px;
    top: 10px;
  }
}

.borderTop {
  border-top: 1px solid #f3f3f3;
}

.bottomBox {
  height: 65px;
}

.black {
  color: #1F2025;
}

.chatBg {
  border-radius: 10.0022px 10.0022px 0px 10.0022px;
}

.responser-content {
  > img {
    &.res {
      width: 50px;
      height: 50px;
      margin: 0;
      margin-right: 15px;
    }
  }
  > .res-content {
    border-radius: 10.0022px 10.0022px 10.0022px 0;
  }
}
</style>
