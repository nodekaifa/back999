<template>
  <div class="h-full w-full">
    <fx-header>
      <template #title>
        {{ $t('personalInformation') }}
      </template>
    </fx-header>
    <div class="flex items-center justify-between bg-white h-20 img ">
      <div style="color: #000">{{$t('avatar')}}</div>
      <div>
        <van-uploader  >
          <van-image
              width="3.75rem"
              height="3.75rem"
              round
              fit="cover"
              :src="userinfo.url"
          />
        </van-uploader>

      </div>
    </div>
    <van-cell-group>
      <van-cell style="height: 3.125rem" :title="t('realName')" is-link :value="status" :to="'/name?statusId='+statusId"/>
      <van-cell style="height: 3.125rem" :title="t('phoneVerify')" :value="userinfo.phone_filled" is-link :to="!isResetPhone ? '/bindVerify?type=1' : '/resetPane?type=phone'"/>
      <van-cell style="height: 3.125rem" :title="t('emailVerify')" :value="userinfo.email_filled" :to="!isResetEmail ? '/bindVerify?type=2' : '/resetPane?type=email'" is-link />
      <van-cell style="height: 3.125rem" :title="t('changeFunsPassword')" is-link  />
      <van-cell style="height: 3.125rem" :title="t('changeLoginPassword')" is-link to="/changePassword" />
    </van-cell-group>
  </div>
</template>

<script setup>
import {onMounted, ref} from "vue";
import { useI18n } from 'vue-i18n';
import { _getVerifTarget, _getIdentify } from '@/service/user.api.js'

const { t } = useI18n();
import defaultImg from "../../assets/imgs/me/defaultAvatar.png"
const userinfo = ref({
  url: defaultImg,
  name: "JACK",
  email_filled: "",
  phone_filled: ""
});
let isResetPhone = ref(false);
let isResetEmail = ref(false);
const status = ref("未认证");
const statusId = ref(0);
const handleTo = (data) => {
  data.phone_authority ? isResetPhone.value = true : '';
  data.email_authority ? isResetEmail.value = true : '';
}
const getVerifTarget = () => {
  _getVerifTarget({
  }).then((res) => {
    userinfo.value = {...userinfo.value, ...res};
    console.error(res)
    handleTo(res);
  })
}

const getIdentify = () => {
  _getIdentify().then(res => {
    statusId.value = res.status;
    switch (res.status) {
      case 0:
        status.value = '未认证';
        break;
      case 1:
        status.value = '审核中';
        break;
      case 2:
        status.value = '已认证';
        break;
      case 3:
        status.value = '审核失败';
        break;
    }
  })
}
onMounted(() => {
  getVerifTarget();
  getIdentify()
})

</script>

<style lang="scss" scoped>
.img {
  padding: var(--van-cell-group-inset-padding);
}
::v-deep(.van-cell__title) {
  color: #333;
}
</style>
