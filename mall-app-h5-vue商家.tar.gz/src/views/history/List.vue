<template>
    <div class="history-list pb-16">
        <fx-account></fx-account>
        <div class="mt-2">
            <div class="tabs flex">
                <div class="tab-item" v-for="(item, index) in tabList" @click="tabIndex = index"
                    :class="[tabIndex === index ? 'active' : '']">
                    {{ item.title }}</div>
            </div>
            <div class="all-wrap" v-if="tabIndex === 1">全部(12)</div>
            <div v-if="tabIndex === 0" class="p-4" v-for="item in 2" :key="item">
                <fx-pair></fx-pair>
                <van-cell :title="_item.title" @click="isShow = true" v-for="(_item, _index) in historyItems"
                    :key="_index">
                    <template #value>
                        <span :class="[_index === 0 ? 'blue' : '', _index === 5 ? 'red' : '']">{{ _item.value }}</span>
                    </template>
                </van-cell>
            </div>
            <div v-else class="p-4">
                <fx-pair type="sell-limit"></fx-pair>
                <van-cell :title="_item.title" @click="isShow = true" v-for="(_item, _index) in accountHistoryItems"
                    :key="_index">
                    <template #value>
                        <span :class="[_index === 0 ? 'blue' : '', _index === 5 ? 'red' : '']">{{ _item.value }}</span>
                    </template>
                </van-cell>
            </div>
        </div>
    </div>
</template>
    
<script setup>
import fxPair from '@/components/fx-pair/index.vue'
import fxAccount from '@/components/fx-account/index.vue'
import { ref } from 'vue';

const historyItems = ref([
    { title: '买/卖', value: '做多' },
    { title: '类型', value: '限价' },
    { title: '数量', value: '123,456.00' },
    { title: '价格', value: '148.746' },
    { title: '执行价格', value: '148.746' },
    { title: '状态', value: '已成交' },
    { title: '手续费', value: '123.12' },
    { title: '时间', value: '2022-10-15 01:45:43' },
    { title: '订单编号', value: '148.531' }
])
const tabList = ref([
    { title: '历史' },
    { title: '账户历史' },
])

const accountHistoryItems = ref([
    { title: '买/卖', value: '做多' },
    { title: '结平前', value: '99,997.05' },
    { title: '结平后', value: '123,456.00' },
    { title: '获利', value: '148.746' },
    { title: '操作', value: 'Close long position for symbol USDJPY at price 148.753 fro 5 shares. Position AVG Price was148.769200, currency :JPY, rate:0.006720,last updated rate on 2022-10-14T 18:02:04Z,point value:1.000000' }
])
let tabIndex = ref(0)

</script>
<style lang="scss" scoped>
.tabs {
    padding: 0 15px;
    border-bottom: 1px solid #eeeeee;
    margin-top: 30px;

    .tab-item {
        width: 100px;
        text-align: center;
        padding: 10px 0;
        font-size: 16px;
        color: #878A96;
    }

    .active {
        color: #1F2025 !important;
        border-bottom: 2px solid #2555F8;
    }
}

.all-wrap {
    width: 100px;
    background: #2555F8;
    margin: 15px;
    height: 26px;
    line-height: 26px;
    color: #fff;
    font-size: 14px;
    border-radius: 20px;
    text-align: center;
}

.blue {
    color: #2555F8 !important;
}

.red {
    color: #E35461 !important;
}


.green {
    color: #2EBD85 !important;
}
</style>