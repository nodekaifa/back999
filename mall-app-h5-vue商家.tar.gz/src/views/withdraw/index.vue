<template>
  <fx-header>
    <template #title>
      <div>{{ $t('withdrawal') }}</div>
    </template>
    <template #right>
      <div @click="handleRecord">{{ $t('withdrawalRecord') }}</div>
    </template>
  </fx-header>
  <div class="withdraw">
    <ExRadioGroup
      :list="list"
      :label="$t('blockchainNetwork')"
      v-model="channel"
    />

    <ExInput
      :label="$t('withdrawalAddress')"
      :placeholderText="$t('withdrawalAddressTips')"
      v-model="from"
      typeText="text"
    />

    <ExInput
      :label="$t('withdrawalAmount')"
      :placeholderText="$t('withdrawalAmountTips')"
      v-model="amount"
      :maxLength="8"
      typeText="number"
    >
      <template #rightBtn>
        <div class="withdraw-all" @click="handleAll">{{ $t('total') }}</div>
      </template>
    </ExInput>

    <div class="tips">
      <span>{{ $t('realWithdrawalAccount') }}: {{ realWithdrawAmount }}</span>
      <span>{{ $t('withdrawalFee') }}: {{ withdrawFee }}%</span>
    </div>

    <van-button
      class="w-full"
      style="margin-top: 10px"
      type="primary"
      @click="withdraw"
      >{{ $t('submit') }}
    </van-button>

    <van-popup
      v-model:show="passwordShow"
      closeable
      position="bottom"
      :style="{ height: '280px' }"
    >
      <div class="popup-content">
        <ExPasswordInput ref="passwordInputRef" v-model="safeword" has-gap />

        <van-button
          class="w-full"
          style="margin-top: 50px"
          type="primary"
          :loading="loading"
          :disabled="computedSafeWord"
          @click="handleWithdraw"
          >{{ $t('submit') }}
        </van-button>
      </div>
    </van-popup>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import NP from 'number-precision'
import { Toast } from 'vant'
import { useI18n } from 'vue-i18n'
import {
  exchangeGetBlockChain,
  exchangeGetWithdrawFee,
  exchangeSetWithdrawToken,
  exchangeGetWithdrawApply
} from '@/service/exchange.api'
import ExRadioGroup from '@/components/ex-radio-group/index.vue'
import ExChecked from '@/components/ex-checked/index.vue'
import ExInput from '@/components/ex-input/index.vue'
import ExPasswordInput from '@/components/ex-password-input/index.vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/store/user'

const userStore = useUserStore()
const router = useRouter()
const { t } = useI18n()

const userBalance = ref(10e8)
const channel = ref('')
const from = ref('')
const safeword = ref('')
const amount = ref('')
const withdrawFee = ref('')

const passwordShow = ref(false)
const loading = ref(false)

const list = ref([])

const isEmptyParams = (str) => [null, undefined, ''].includes(str)

/**
 * 获取提现费率
 */
const getWithdrawFee = () => {
  exchangeGetWithdrawFee().then((res) => {
    const { withdraw_fee } = res
    withdrawFee.value = withdraw_fee * 100
  })
}

/**
 * 获取提现区块
 */
const getWithdrawBlockChain = () => {
  exchangeGetBlockChain().then((res) => {
    const filterList = res.filter((i) => i.coin === 'USDT')
    const newList = filterList.map((i) => ({
      ...i,
      label: i.blockchain_name,
      value: i.blockchain_name
    }))

    if (newList.length) {
      channel.value = newList[0]?.value ?? ''
    }

    list.value = newList ?? []
  })
}

onMounted(() => {
  // 获取提现费率
  getWithdrawFee()
  // 获取提现区块
  getWithdrawBlockChain()
})

const realWithdrawAmount = computed(() => {
  const val = amount.value
  const fee = withdrawFee.value
  const ratio = NP.divide(NP.minus(100, fee), 100)

  return NP.times(val, ratio)
})

const computedSafeWord = computed(() => {
  const val = safeword.value
  return String(val).length < 6
})

const handleAll = () => {
  amount.value = userBalance.value
}

const handleRecord = () => {
  router.push({ name: 'WithdrawRecord' })
}

/**
 * 提现验证
 */
const withdraw = () => {
  if (isEmptyParams(channel.value)) {
    Toast(t('blockchainNetworkRequire'))
    return
  }

  if (isEmptyParams(from.value)) {
    Toast(t('withdrawalAddressRequire'))
    return
  }

  if (isEmptyParams(amount.value)) {
    Toast(t('withdrawalAmountRequire'))
    return
  }

  // 打开密码弹出层
  if (userStore?.userInfo?.safeword === 1) {
    passwordShow.value = true
  }
}

/**
 * 提现提交
 */
const handleWithdraw = async () => {
  const params = {
    safeword: safeword.value,
    amount: amount.value,
    from: from.value,
    channel: channel.value
  }

  await exchangeSetWithdrawToken({ session_token: userStore?.userInfo?.token })

  loading.value = true
  exchangeGetWithdrawApply(params)
    .then((res) => {
      console.log(1111, res)
      Toast(t('withdrawalApplySuccess'))
    })
    .finally(() => {
      loading.value = false
    })
}
</script>

<style scoped lang="scss">
.withdraw {
  padding: 25px;
  height: calc(100vh - var(--van-nav-bar-height));
  background-color: $background-color;
  overflow-y: scroll;

  :deep(.inputCom) {
    .label {
      font-size: 12px;
    }

    input {
      font-size: 14px !important;
    }
  }

  .tips {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
    padding-bottom: 10px;

    span:nth-child(1) {
      color: $text-color-light;
    }

    span:nth-child(2) {
      color: $primary-color;
    }
  }

  :deep(.inputBackground) {
    background: transparent;

    input {
      padding-left: 0;
    }
  }

  :deep(.inputBackground.iptbox) {
    border: 1px solid $border-color;
  }

  &-all {
    font-size: 14px;
    color: $primary-color;
    padding-left: 6px;
  }
}

.popup-content {
  padding: 80px 30px 0;
}
</style>
