<template>
    <div class="login">
        <div class="top-content">
            <div class="item" @click="onRoute('/my/index')"><img :src="iconImg.close" alt="" /></div>
            <div class="item lang" @click="$router.push('/language')"><img :src="iconImg.feedback" alt="" /></div>
        </div>
        <div class="title textColor">{{ $t('login') }}</div>
        <div class="flex login-tab">
            <div class="textColor1" :class="activeIndex == 1 ? 'active' : ''" @click="changeIndex(1)">{{ $t('email') }}</div>
            <div class="textColor1" :class="activeIndex == 2 ? 'active' : ''" @click="changeIndex(2)">{{ $t('phoneNum')}}</div>
        </div>
        <ExInput :label="getRegType(activeIndex, true)" :placeholderText="getRegType(activeIndex, false)"
            v-model="username" :dialCode="dialCode" @selectArea="onSelectArea" :area="isArea" :icon="icon" />
        <ExInput style="padding-bottom:0!important;" :label="$t('password')" :placeholderText="$t('entryPassword')"
            v-model="password" typeText="password" />
        <div class="forget colorMain" @click="$router.push('/customerService')">{{ $t('forgetPassword') }}</div>
        <van-button class="w-full" style="margin-top: 20px;" type="custom" @click="verifyLogin">{{ $t('login') }}</van-button>

        <nationality-list ref='controlChildRef' :title="$t('selectArea')" @get-name="getName"></nationality-list>
    </div>
</template>

<script setup>
import ExInput from "@/components/ex-input/index.vue";
import { _loginUser } from "@/service/login.api";
import { GET_USERINFO } from '@/store/types.store'
import { useUserStore } from '@/store/user';
import { useI18n } from 'vue-i18n'
import nationalityList from '../authentication/components/nationalityList.vue'
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { Toast } from "vant";
const { t } = useI18n()

const router = useRouter()
const onRoute = (path) => {
    if (path == 'back') {
        router.go(-1)
    } else {
        router.push(path)
    }
}

let username = ref('')
let password = ref('')
let activeIndex = ref(1)
let isArea = ref(false)
let dialCode = ref(0)
let icon = ref('')

const iconImg = {
    close: new URL('../../assets/image/login/Union.png', import.meta.url),
    feedback: new URL('../../assets/image/login/feedback.png', import.meta.url)
}

const getRegType = (activeIndex, bFlag) => {
    switch (activeIndex) {
        case 0:
            return bFlag ? t('account') : t('entryAccount');
        case 1:
            return bFlag ? t('email') : t('entryEmail');
        case 2:
            return bFlag ? t('phoneNum') : t('entryPhone');
    }
}
const controlChildRef = ref(null)
const onSelectArea = () => {
    controlChildRef.value.open();
}

//获取到当前选中国家的code值
const getName = (childname, childcode, childdialCode) => {
    icon.value = childcode;
    dialCode.value = childdialCode;
}

const changeIndex = (index) => {
    activeIndex.value = index;
    username.value = ''
    password.value = ''
    switch (index) {
        case 0:
        case 1: {
            isArea.value = false;
            break;
        }
        case 2: {
            isArea.value = true;
            break;
        }
    }
}

const verifyLogin = () => {
    if (username.value == '') {
        switch (activeIndex.value) {
            case 0:
                {
                    Toast(t('entryAccount'));
                    break;
                }
            case 1:
                {
                    Toast(t('entryEmail'));
                    break;
                }
            case 2:
                {
                    Toast(t('entryPhone'));
                    break;
                }
        }
        return false
    }
    if (password.value == '') {
        Toast(t('entryPassword'));
        return false
    }
    loginUser()
}

const userStore = useUserStore();
const loginUser = () => {
    Toast.loading({
        duration: 0,
        message: t('submitting'),
        forbidClick: true
    })

    _loginUser({
        username: (activeIndex.value == 0 || activeIndex.value == 1) ? username.value : `${dialCode.value}${username.value}`,
        password: password.value,
    }).then((res) => {
        Toast.success(t('loginsuc'))
        userStore[GET_USERINFO](res)
        router.push('/my/index')
    }).catch(err => {
        console.log(err)
    })
}
</script>

<style lang="scss" scoped>
.login {
    width: 100%;
    min-height: 100vh;
    background-color: #fff;
    padding: 15px;
    font-size: 13px;
    box-sizing: border-box;
}

.top {
    padding-left: 9px;
    padding-top: 9px;

    img {
        width: 18px;
        height: 18px;
    }
}

.top-content {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    > .item {
        > img {
            width: 18px;
            height: 18px;
        }
        &.lang {
            > img {
                width: 22px;
                height: 22px;
            } 
        }
    }
}

.title {
    font-weight: 700;
    font-size: 26px;
    margin-top: 27px;
    margin-bottom: 33px;
}

.login-tab {
    margin-bottom: 20px;

    div {
        padding: 0 20px;
        height: 34px;
        line-height: 34px;
        text-align: center;
        border-radius: 4px;
        margin-right: 10px;
        background: #eee;
        color: #333;
    }

    .active {
        background: #1552F0;
        color: #fff;
    }
}

.forget {
    font-size: 12px;
    line-height: 14px;
    margin-top: 9px;
}

.noTips {
    margin-top: 22px;
}

.van-button--custom {
    color: #fff;
    background: #1552F0 !important;
}

</style>