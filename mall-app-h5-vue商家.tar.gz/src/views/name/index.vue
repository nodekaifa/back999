<template>
  <fx-header>
    <template #title>
      {{ $t('realNameVertify') }}
    </template>
  </fx-header>

  <!-- 申请身份认证 -->
  <div class="identity pl-15 pr-15 font-12 bg-white" style="padding-bottom: 30px;" >
    <div v-if="route.query.statusId > 0" class="flex justify-between items-center text-sm pt-6 pb-8" style="color: #000">
      <div>{{$t('authVerify')}}</div>
      <div class="flex items-center">
        <img class="w-4 h-4 mr-0.5" :src="handleShow(true)" alt="">
        <div>{{$t(handleShow())}}</div>
      </div>
    </div>
<!--    <div class="header">-->
<!--      <div class="flex items-center" @click="$router.go(-1)"><img-->
<!--          src="../../assets/image/assets-center/left-arrow.png" alt="" class="leftReturn" /></div>-->
<!--      <div class="textColor" @click="$router.push('/gooleVerify')">{{ $t('skip') }}</div>-->
<!--    </div>-->
    <div class=" pt-29 pb-27 box-border border-b-color" v-if="disabled() || status === 3">

      <div class="flex justify-between items-center px-15">
        <div class="font-25">{{ $t('authVerify') }}</div>
        <div class="flex items-center" v-if="resultArr[this.status]">
          <img :src="require(`@/assets/image/assets-center/${resultArr[this.status] && resultArr[this.status].split('_')[0]}.png`)"
               alt="success img" class="w-18 h-18" />
          <div class="font-16 ml-9">{{ resultArr[this.status] && resultArr[this.status].split('_')[1] }}
          </div>
        </div>
      </div>
    </div>
    <div>
      <div class="mb-5">
        <div class="mt-27 mb-13 font-12 textColor">{{ $t('nationality') }}</div>
        <div class="pt-2 pb-2 pl-4 pr-19 flex justify-between items-center rounded inputBackground textColor"
             @click="openBtn">
          <div class="flex items-center">
            <div class="iti-flag mr-8" :class="countryCode" style="transform: scale(1.3)"></div>
            <div>{{ countryName }}</div>
          </div>

          <img v-if="resultArr.length === 0" src="../../assets/image/public/down-arrow.png" class="w-17 h-10"
               alt="arrow" />
        </div>
      </div>
      <ExInput :label="$t('realName')" :placeholderText="$t('entryRealName')" v-model="name" />
      <ExInput :label="$t('credentPassport')" :placeholderText="$t('entryCredentPassport')" v-model="idnumber" />
      <div>
        <div v-if="resultArr.length > 0" class="mb-13 textColor">{{ $t('uploadCredentPassport') }}</div>
        <div v-else class="mt-55 mb-13">{{ $t('uploadPicCredentPassport') }}</div>
        <div class="flex mt-4 mb-6 justify-between">
          <div class="flex-1 flex flex-col text-center justify-center items-center">
            <div class="upload-wrap">
              <img src="@/assets/image/kyc/0.png" alt="" class="w-full"
                   v-if="[1, 2].includes(status) && frontFile.length === 0" />
              <van-uploader v-model="frontFile" multiple :max-count="1" :disabled="disabled()"
                            :deletable="!disabled()" :after-read="afterRead"
                            @click-upload="onClickUpload('frontFile')" v-else />
            </div>
            <div class="mt-3 font-13 h-5 textColor">{{ $t('credentFront') }}</div>
          </div>
          <div class="flex-1 flex flex-col text-center justify-center items-center">
            <div class="upload-wrap">
              <img src="@/assets/image/kyc/1.png" alt="" class="w-full"
                   v-if="[1, 2].includes(status) && reverseFile.length === 0" />
              <van-uploader v-model="reverseFile" multiple :max-count="1" :disabled="disabled()"
                            :deletable="!disabled()" :after-read="afterRead"
                            @click-upload="onClickUpload('reverseFile')" v-else />
            </div>
            <div class="mt-3 font-13 h-5 textColor">{{ $t('credentObverse') }}</div>
          </div>
          <div class="flex-1 flex flex-col text-center justify-center items-center">
            <div class="upload-wrap">
              <img src="@/assets/image/kyc/2.png" alt="" class="w-full"
                   v-if="[1, 2].includes(status) && fileList.length === 0" />
              <van-uploader v-model="fileList" multiple :max-count="1" :disabled="disabled()"
                            :deletable="!disabled()" :after-read="afterRead"
                            @click-upload="onClickUpload('fileList')" v-else />
            </div>
            <div class="mt-3 font-13 h-5 textColor">{{ $t('handCredent') }}</div>
          </div>
        </div>
      </div>
      <template v-if="!disabled()">
        <div class="mb-4 textColor">{{ $t('photoExample') }}</div>
        <div class="flex items-center justify-between">
          <div class="">
            <img src="../../assets/imgs/me/kyc-1.png" alt=""
                 class="mb-4"
                 style="width: 6.2175rem; height: 4rem;">
            <img src="../../assets/imgs/me/kyc-true.png" style="width: 1.1875rem; height: 1.1875rem; margin: 0 auto" alt="">
          </div>
          <div class="">
            <img src="../../assets/imgs/me/kyc-2.png" alt=""
                 class="mb-4"
                 style="width: 6.2175rem; height: 4rem;">
            <img src="../../assets/imgs/me/kyc-false.png" style="width: 1.1875rem; height: 1.1875rem; margin: 0 auto" alt="">
          </div>
          <div class="">
            <img src="../../assets/imgs/me/kyc-3.png" alt=""
                 class="mb-4"
                 style="width: 6.2175rem; height: 4rem;">
            <img src="../../assets/imgs/me/kyc-false.png" style="width: 1.1875rem; height: 1.1875rem; margin: 0 auto" alt="">
          </div>
        </div>
      </template>
      <van-button class="w-full" style="margin-top:10px;" type="primary" @click="onSubmit">{{ $t('certification') }}
      </van-button>
      <nationality-list ref='controlChildRef' :title="$t('selectNation')" @getName="getName" v-if="!disabled()">
      </nationality-list>
    </div>
  </div>
</template>

<script setup>
import nationalityList from '../authentication/components/nationalityList.vue'
import { Uploader } from 'vant';
import { _applyIdentify, _getIdentify } from '@/service/user.api.js'
import { _uploadImage } from '@/service/upload.api'
import countriesinit from "../authentication/components/countryList";
import ExInput from "@/components/ex-input/index.vue";

import KeySuccess from "../../assets/imgs/me/kyc-success.png";
import KeyFail from "../../assets/imgs/me/kyc-fail.png";
import KeyWait from "../../assets/imgs/me/kyc-wait.png";
import { Toast } from "vant";
import { useRouter,useRoute } from "vue-router";
import { ref, reactive, onMounted } from "vue";
import { useI18n } from 'vue-i18n'
const { t } = useI18n()
const router = useRouter()
const route = useRoute();

const countries = ref(countriesinit)
const countryName = ref(t('selectNation'))   //this.$t("selectNation"), //国家名称
const countryCode = ref('af') //国家地区号
const idnumber = ref('')
const name = ref('')

const frontFile = ref([])
const reverseFile = ref([])
const fileList = ref([])
const curFile = ref('frontFile')
const status = ref(-1) // 0
const imgs = ref([])
const resultArr = ref(['small-success_' + t('applynoView'), 'identifing_' + t('reviewing'), 'small-success_' + t('passView'), 'icon-close_' + t('noPassView')]) // 0 好像是未提交

onMounted(() => {
  fetchInfo()
})

const handleShow = (type = false) => {
  switch (status.value) {
    case 1:
      return type ? KeyWait : 'inCertification';
    case 2:
      return type ? KeySuccess : 'passTheCertification';
    case 3:
      return type ? KeyFail : 'authenticationFailure';
    default:
      return "";
  }
}

const fetchInfo = () => {   // 获取状态
  _getIdentify().then(data => {
    console.error(data)
    status.value = data.status
    if (data.status !== 0) {
      countryName.value = countries[data.nationality]['name']
      countryCode.value = data.nationality
      idnumber.value = data.idnumber
      name.value = data.name
      frontFile.value = data.idimg_1 ? [{ url: data.idimg_1_path }] : []
      reverseFile.value = data.idimg_2 ? [{ url: data.idimg_2_path }] : []
      fileList.value = data.idimg_3 ? [{ url: data.idimg_3_path }] : []
    }
  })
}

const onClickLeft = () => {
  router.go(-1);
}
const disabled = () => { // 是否禁用按钮
  return ![0, 3, -1].includes(status.value)
}
const onClickUpload = (type) => {
  curFile.value = type
}
const afterRead = (file) => { /// 处理文件
  file.status = 'uploading'
  file.message = t('uploading')
  _uploadImage(file).then(data => {
    file.status = 'success';
    file.message = t('uploadSuccess');
    file.resURL = data
    if (curFile.value == 'frontFile') {
      frontFile.value = [file]
    } else if (curFile.value == 'reverseFile') {
      reverseFile.value = [file]
    } else {
      fileList.value = [file]
    }
    // [curFile.value].value = [file]
  })
}
//打开国家列表底部弹窗
const controlChildRef = ref(null)
const openBtn = () => {
  if (!disabled()) {
    controlChildRef.value.open();
  }
}
//获取到当前选中国家的code值
const getName = (childname, childcode, childdialCode) => {
  countryName.value = childname;
  countryCode.value = childcode;
}
const onSubmit = () => {
  if (!countryName.value) {
    Toast(t('selectNation'))
    return
  }
  if (!name.value) {
    Toast(t('entryName'))
    return
  }
  if (!idnumber.value) {
    Toast(t('entryCredent'))
    return
  }
  _applyIdentify({
    name: name.value,
    idnumber: idnumber.value,
    frontFile: frontFile.value,
    reverseFile: reverseFile.value,
    fileList: fileList.value,
    countryName: countryCode.value // countryName 存储的 code, 回来再遍历
  }).then(() => {
    Toast(t('submitSuccess'))
    router.push('/personalInfo');
    //this.fetchInfo()
  }).catch(err => {
    Toast(t(err.message));
  })

}

</script>
<style lang="scss" scoped>
@import "@/views/authentication/components/intl.css";

.identity {
  width: 100%;
  box-sizing: border-box;
}

.upload-wrap {
  width: 110px;
  height: 110px;
  display: flex;
  justify-content: center;
  align-items: center;
}

input {
  font-size: 18px;
}

input:disabled {
  background: #fff;
}

.list-view {
  overflow-y: scroll;
  border-bottom: 1px solid #e5e5e5;
}

.kyc-input {
  width: 100%;
  border: none;
}


.service-text {
  text-decoration: underline;
}

.header {
  display: flex;
  justify-content: space-between;
  padding: 0 13px;
  font-size: 14px;
  height: 50px;
  line-height: 50px;
}

.stepBox {
  padding: 0 15px;
}

.title {
  font-weight: 700;
  font-size: 26px;
  margin-top: 25px;
  margin-bottom: 30px;
}

.city {
  background: #F5F5F5;
}
::v-deep(.van-button--primary) {
  background-color: #1552F0;
  border-color: #1552F0;
}
:deep(.inputBackground) {
  background-color: #fff !important;
  border-radius: 4px;
  border: 1px solid #eee;
}
</style>
