<template>
  <div class="comment">
    <fx-header fixed>
      <template #title>{{t('product.23')}}</template>
    </fx-header>
    <div class="list">

      <van-pull-refresh v-model="loading" @refresh="onRefresh">
        <van-list v-model:loading="loading" :finished="finished" :finished-text="t('product.3')" @load="onLoad">
          <div class="pl-3 pr-3 pt-4 comment-info" v-for="(item, index) in list" :key="index">
            <div class="flex score">
              <div class="flex user-name">
                <img class="user-img" src="@/assets/imgs/product/user.png" />
                {{ item.partyName }}
              </div>
              <div>
                <van-rate :size="20" color="#FFC93E" v-model="item.rating" />
              </div>
            </div>
            <div class="comment-text pt-3 pb-3">
              {{item.content}}
            </div>
            <div class="comment-time">{{item.createTime}}</div>
            <div class="item  pb-3 pt-3 flex">
              <div class="flex-1 flex left">
                <div class="product-img-wrap">
                  <img class="product-img" :src="item.imgUrl1" />
                </div>
                <div class="product-info">
                  <div class="name">{{item.name}}</div>
                  <div class="Specification">
                    <span>{{t('product.4')}}: {{item.unit}}</span>
                    <!-- <span>Sales: 1000</span> -->
                  </div>
                  <div class="money">${{item.systemPrice}}</div>
                </div>
              </div>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
    </div>

  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';
import { getEvaluation } from "@/service/product.api";
const { t } = useI18n();
const route = useRoute()
const router = useRouter()
const list = ref([]);
const value = ref(3);
const loading = ref(false);
const finished = ref(false);
let pageNum = ref(1)
const onLoad = () => {
  let data = {
    pageNum: pageNum.value,
    pageSize: 20,
    // lang: 'cn',
  }
  getEvaluation(data).then((res) => {
    pageNum.value++
    for (let i = 0; i < res.pageList.length; i++) {
      list.value.push(res.pageList[i]);
    }

    // 加载状态结束
    loading.value = false;

    if (res.pageList.length == 0) {
      finished.value = true;
    }
  })
}
</script>

<style scoped lang="scss">
.comment {
  padding-top: 50px;
  min-height: 100vh;
  background: #EFF2F6;

  .comment-info {
    background: #fff;
    margin-top: 10px;
  }

  .search-wrap {
    margin: 0 15px;
    border-radius: 25px;
    height: 45px;
    text-align: center;

    .search-icon {
      height: 24px;
    }
  }

  .product-header {
    background: #FFFFFF;
    border-radius: 4px;
    padding: 20px 0;
    margin-top: 20px;

    .moeny {
      font-weight: 600;
      font-size: 20px;
    }

    .title {
      margin-top: 10px;
      color: #999999;
    }

    .after {
      position: relative;

      &::after {
        position: absolute;
        height: 100%;
        width: 1px;
        background: #DDDDDD;
        content: '';
        right: 0;
        top: 0;
      }
    }
  }

  .score {
    justify-content: space-between;
    align-items: center;

    .user-name {
      align-items: center;
      color: #999999;
    }

    .user-img {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      margin-right: 10px;
    }
  }

  .comment-text {
    font-size: 14px;
    color: #333;
  }

  .comment-time {
    font-size: 12px;
    color: #999;
  }

  .list {
    .item {
      border-radius: 4px;
      align-items: center;
      background: #F6F6F6;
      .more-icon {
        width: 20px;
      }

      .product-img {
        width: 100px;
      }

      .left {
        align-items: center;
        padding: 12px;
        border-radius: 4px;

        .product-info {
          padding-left: 10px;

          .name {
            font-size: 14px;
            color: #333333;
            width: 180px;
            height: 50px;
            font-weight: bold;
            overflow: hidden;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            -ms-text-overflow: ellipsis;
            text-overflow: ellipsis;
          }

          .Specification {
            font-size: 12px;
            color: #999999;
          }

          .money {
            color: #1552F0;
            font-weight: bold;
          }
        }
      }


    }

    .product-img-wrap {
      position: relative;
    }

    .delete-wrap {
      padding: 0 15px;
      background: rgba(0, 0, 0, 0.6);
      position: absolute;
      left: 0;
      top: 0;
      font-size: 12px;
      color: #fff;

    }
  }
}





:deep(.van-search__content) {
  background: #fff;
}

:deep(.van-field__control) {
  text-align: center;
}
</style>