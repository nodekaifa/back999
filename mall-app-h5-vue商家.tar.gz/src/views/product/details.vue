<template>
  <div class="details">
    <fx-header fixed>
      <template #title>{{t('product.11')}}</template>
    </fx-header>
    <div class="list ml-4 mr-4 mt-4">

   
          <div class="item pl-3 pr-3 pb-3 pt-3 flex">
            <div class="flex-1 flex left">
              <div class="product-img-wrap">
                <img class="product-img" :src="info.imgUrl1" />
              </div>
              <div class="product-info">
                <div class="name">{{info.name}}</div>
                <div class="Specification">
                  <span>{{t('product.4')}}: {{ info.unit }}</span>
                  <span>{{t('product.9')}}: {{info.soldNum}}</span>
                </div>
                <div class="money">${{info.sellingPrice}}</div>
              </div>
            </div>
            <!-- <div class="number">
              x1
            </div> -->

          </div>
    </div>
    <div class="pl-4 pr-4">
      <div class="flex details-item pl-3 pr-3">
        <div class="title">{{t('product.9')}}</div>
        <div class="text">{{info.soldNum}}</div>
      </div>
      <div class="flex details-item pl-3 pr-3">
        <div class="title">{{ t('product.12') }}</div>
        <div class="text">${{info.sellingPrice}}</div>
      </div>
      <!-- <div class="flex details-item pl-3 pr-3">
        <div class="title">Discount Price</div>
        <div class="text">$18.90</div>
      </div> -->
      <div class="flex details-item pl-3 pr-3">
        <div class="title">{{t('product.13')}}</div>
        <div class="text">${{info.sellingPrice}}</div>
      </div>
      <div class="flex details-item pl-3 pr-3">
        <div class="title">{{t('product.14')}}</div>
        <div class="text">${{ (info.sellingPrice - info.systemPrice).toFixed(2)}}</div>
      </div>
      <div class="flex details-item pl-3 pr-3">
        <div class="title">{{t('product.15')}}</div>
        <div class="text">{{info.isShelf == 0  ? t('product.18') : t('product.17')}}</div>
      </div>
      <div class="flex details-item pl-3 pr-3">
        <div class="title">{{t('product.16')}}</div>
        <div class="text">{{info.recTime != 0  ? t('product.17') : t('product.18')}}</div>
      </div>

    </div>
  </div>
</template>

<script setup>
import { ref,onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';
const { t } = useI18n();
const route = useRoute()
const router = useRouter()
let info = ref({})
onMounted(() => {
  info.value = JSON.parse(route.query.item)
  console.log(info.value)
})
</script>

<style scoped lang="scss">
.details {
  padding-top: 50px;
  padding-bottom: 50px;

  .search-wrap {
    margin: 0 15px;
    border-radius: 25px;
    height: 45px;
    text-align: center;

    .search-icon {
      height: 24px;
    }
  }

  .product-header {
    background: #FFFFFF;
    border-radius: 4px;
    padding: 20px 0;
    margin-top: 20px;

    .moeny {
      font-weight: 600;
      font-size: 20px;
    }

    .title {
      margin-top: 10px;
      color: #999999;
    }

    .after {
      position: relative;

      &::after {
        position: absolute;
        height: 100%;
        width: 1px;
        background: #DDDDDD;
        content: '';
        right: 0;
        top: 0;
      }
    }
  }

  .list {
    position: relative;
    border-bottom: 1px solid #EFF2F6;
    .item {
      background: #FFFFFF;
      border-radius: 4px;
      // align-items: center;
      
      .more-icon {
        width: 20px;
      }

      .product-img {
        width: 100px;
      }
      .number{
        position: absolute;
        bottom: 12px;
        right: 12px;
        font-weight:700;
        color: #1552F0;
      }
      .left {
        align-items: center;

        .product-info {
          padding-left: 10px;

          .name {
            font-size: 14px;
            color: #333333;
            width: 180px;
            height: 50px;
            font-weight: bold;
            overflow: hidden;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            -ms-text-overflow: ellipsis;
            text-overflow: ellipsis;
          }

          .Specification {
            font-size: 12px;
            color: #999999;
            span{
              margin-right: 10px;
            }
          }

          .money {
            color: #1552F0;
            font-weight: bold;
          }
        }
      }

    }

    .product-img-wrap {
      position: relative;
    }

    .delete-wrap {
      padding: 0 15px;
      background: rgba(0, 0, 0, 0.6);
      position: absolute;
      left: 0;
      top: 0;
      font-size: 12px;
      color: #fff;
    }
  }

}
.details-item{
  justify-content: space-between;
  padding-top: 12px;
  padding-bottom: 12px;
  background: #FFFFFF;
  .title{
    color: #999999;
  }
  .text{
    color: #333;
  }
}
:deep(.van-search__content) {
  background: #fff;
}

:deep(.van-field__control) {
  text-align: center;
}
</style>