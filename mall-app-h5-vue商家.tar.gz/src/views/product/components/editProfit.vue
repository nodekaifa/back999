<template>

  <div class="editProduct">
    <van-popup v-model:show="props.isEdit" round closeable @click-close-icon="close"
      :style="{ height: '30%', width: '95%' }">
      <div class="edit-product-pop">
        <div class="title">{{t('product.24')}}</div>
        <van-form>
          <div class="tip pt-2 pb-2 pl-4 pr-4">{{t('product.25')}}</div>
          <van-cell-group class="input-field" inset>
            <van-field v-model="fromData.sellerBi" :placeholder="t('product.25')"
              >
              <template #button>
                <span>%</span>
              </template>
            </van-field>
          </van-cell-group>
          <div style="margin: 16px;">
            <van-button block type="primary" @click="onSubmit"  native-type="submit">
              {{t('product.26')}}
            </van-button>
          </div>
        </van-form>
      </div>
    </van-popup>
    <!-- <fx-header fixed>
      <template #title>编辑商品</template>
    </fx-header> -->
    <!-- <van-popup v-model:show="show" position="bottom">
      <div>
        <van-date-picker v-model="fromData.recTime" title="选择日期"   ></van-date-picker>

      </div>
    </van-popup> -->
  </div>
</template>

<script setup>
import { goodsaddOrUpdate } from "@/service/product.api";
import { ref, watch } from 'vue';
import { Toast } from 'vant'
import { useRoute, useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';
let show = ref('true')
const { t } = useI18n();
const emit = defineEmits(['back'])
// const minDate = new Date(2020, 0, 1)
const route = useRoute()
const router = useRouter()
const fromData = ref({
  sellerBi: '',
})
const onSubmit = (values) => {
  let dataJson = {
    goodsIds: props.productArry.join(','),
    sellerBi: fromData.value.sellerBi
  }
  console.log(dataJson)
  goodsaddOrUpdate(dataJson).then((res)=>{
    close()
  })
};
const props = defineProps({
  isEdit: Boolean,
  productArry: Array
});
const close = () => {
  emit('close')
}

</script>

<style scoped lang="scss">
.editProduct {
  background: #fff;
  color: #333;

  .title {
    text-align: center;
    line-height: 55px;
    font-size: 16px;
    font-weight: bold;
  }

  .edit-product-pop {
    // padding-top: 20px;
  }

  .tip {
    font-size: 14px;

  }

  .tips {
    font-size: 12px;
    line-height: 18px;
    color: #000000;

    span {
      color: #1552F0;
    }
  }

  .input-field {
    border: 1px solid #ddd;

    .profit {
      color: #0ECB81;
    }

  }

  .input-item {
    justify-content: space-between;
    align-items: center;

  }
}
</style>