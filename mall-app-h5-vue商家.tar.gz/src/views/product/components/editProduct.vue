<template>

  <div class="editProduct">
    <van-popup v-model:show="props.isEdit" round closeable @click-close-icon="close"
      :style="{ height: '40%', width: '95%' }">
      <div class="edit-product-pop">
        <div class="title">编辑商品</div>
        <van-form>
          <div class="tip pt-2 pb-2 pl-4 pr-4">当前售价</div>
          <van-cell-group class="input-field" inset>
            <van-field v-model="fromData.sellingPrice" placeholder="当前售价"
              >
              <template #button>
                <span class="profit">利润${{ (fromData.sellingPrice - productInfo.systemPrice).toFixed(2) }}</span>
              </template>
            </van-field>
          </van-cell-group>
          <div class="flex pl-4 pr-4 input-item pt-3 pb-3">
            <div>是否上架</div>
            <div class="flex">
              <van-switch v-model="fromData.isShelf" size="25" active-color="#1552F0" inactive-color="#fff" />
            </div>
          </div>
          <div class="flex pl-4 pr-4 input-item pt-3 pb-3">
            <div>是否推荐</div>
            <div class="flex">
              <van-switch v-model="isRecommend" size="25" active-color="#1552F0" inactive-color="#fff" />
            </div>
          </div>
          <!-- <div class="tip pt-2 pb-2 pl-4 pr-4" v-if="isRecommend">推荐时间</div>
          <van-cell-group v-if="isRecommend" class="input-field" inset>
            <van-field v-model="fromData.recTime" placeholder="推荐时间">

            </van-field>
          </van-cell-group> -->
          <!-- <div class="flex pl-4 pr-4 input-item pt-3 pb-3">
            <div>直通车</div>
            <div class="flex">
              <van-switch v-model="checked" size="25" active-color="#1552F0" inactive-color="#fff" />
            </div>
          </div>
          <div class="tip pt-2 pb-2 pl-4 pr-4">Percentage</div>
          <van-cell-group class="input-field" inset>
            <van-field v-model="username" placeholder="百分比" :rules="[{ required: true, message: '请填写百分比' }]">
              <template #button>
                <span>%</span>
              </template>
            </van-field>
          </van-cell-group>
          <div class="tips pt-2 pb-2 pl-4 pr-4">Post the selected goods to your store and fill in the profit ratio of
            the goods, the recommendation ratio: <span>5%-20%</span></div>
          <div class="tip pt-2 pb-2 pl-4 pr-4">折扣开始日期</div>
          <van-cell-group class="input-field" inset>
            <van-field v-model="username" placeholder="折扣开始日期">

            </van-field>
          </van-cell-group>
          <div class="tip pt-2 pb-2 pl-4 pr-4">折扣结束日期</div>
          <van-cell-group class="input-field" inset>
            <van-field v-model="username" placeholder="折扣结束日期">

            </van-field>
          </van-cell-group>
          <div class="tip pt-2 pb-2 pl-4 pr-4">折扣比例</div>
          <van-cell-group class="input-field" inset>
            <van-field v-model="username" placeholder="折扣比例">
              <template #button>
                <span>%</span>
              </template>
            </van-field>
          </van-cell-group> -->
          <div style="margin: 16px;">
            <van-button block type="primary" @click="onSubmit"  native-type="submit">
              保存
            </van-button>
          </div>
        </van-form>
      </div>
    </van-popup>
    <!-- <fx-header fixed>
      <template #title>编辑商品</template>
    </fx-header> -->
    <!-- <van-popup v-model:show="show" position="bottom">
      <div>
        <van-date-picker v-model="fromData.recTime" title="选择日期"   ></van-date-picker>

      </div>
    </van-popup> -->
  </div>
</template>

<script setup>
import { goodsUpdate } from "@/service/product.api";
import { ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';
import { dataTime } from '@/utils/index'
let show = ref('true')
const { t } = useI18n();
const emit = defineEmits(['back'])
// const minDate = new Date(2020, 0, 1)
const route = useRoute()
const router = useRouter()
const isRecommend = ref(true);
const fromData = ref({
  sellingPrice: '',
  isShelf: true,
  recTime: ''
})
const onSubmit = (values) => {
  let dataJson = {
    sellingPrice: fromData.value.sellingPrice,
    isShelf: fromData.value.isShelf ? 0 : 1,
    recTime: isRecommend.value ? dataTime(new Date()) : 0,
    isCombo: 0,
    sellerGoodsId:props.productInfo.id
  }
  console.log(dataJson)
  goodsUpdate(dataJson).then((res)=>{
    close()
    emit('update',props.productInfo,fromData.value.sellingPrice)
  })
};
const props = defineProps({
  isEdit: Boolean,
  productInfo: Array
});
const close = () => {
  emit('close')
}
watch(
  () => props.productInfo,
  (newVal, oldVal) => {
    fromData.value.sellingPrice = newVal.sellingPrice
    fromData.value.isShelf = newVal.isShelf == 0 ? true : false
    fromData.value.recTime = newVal.recTime == 0 ? '' : newVal.recTime
    isRecommend.value = newVal.recTime == 0 ? false : true
    console.log('new', newVal)
  }
)

</script>

<style scoped lang="scss">
.editProduct {
  background: #fff;
  color: #333;

  .title {
    text-align: center;
    line-height: 55px;
    font-size: 16px;
    font-weight: bold;
  }

  .edit-product-pop {
    // padding-top: 20px;
  }

  .tip {
    font-size: 14px;

  }

  .tips {
    font-size: 12px;
    line-height: 18px;
    color: #000000;

    span {
      color: #1552F0;
    }
  }

  .input-field {
    border: 1px solid #ddd;

    .profit {
      color: #0ECB81;
    }

  }

  .input-item {
    justify-content: space-between;
    align-items: center;

  }
}
</style>