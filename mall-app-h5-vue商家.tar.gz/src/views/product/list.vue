<template>
  <div class="product">
    <fx-header fixed>
      <template #title>{{t('product.2')}}</template>
      <template #right>
        <img @click="isShow = true" class="nav_filtering_icon" src="@/assets/imgs/product/nav_filtering.png" />
      </template>
    </fx-header>
    <van-search class="search-wrap" disabled @click="search" v-model="value" :placeholder="t('product.1')" clearable>
      <template #left-icon="icon">
        <img class="search-icon" src="@/assets/imgs/product/search-icon.png" />
      </template>
    </van-search>
    <div class="list mr-4 mt-4 mb-4">

      <van-pull-refresh v-model="loading" @refresh="onRefresh">
        <van-list v-model:loading="loading" :finished="finished" :finished-text="t('product.3')" @load="onLoad">
          <div class="item  pr-3 pb-3 pt-3 flex" v-for="(item, index) in list" :key="index">
            <div class="pl-3 pr-3 ">
              <div class="check-icon" @click="item.check = !item.check" :class="[item.check ? 'check-true ' : 'check']">

              </div>
            </div>
            <div class="flex-1 flex left">
              <div class="product-img-wrap">
                <img class="product-img" :src="item.imgUrl1" />
              </div>
              <div class="product-info">
                <div class="name">{{ item.name }}</div>
                <div class="Specification">
                  <span>{{t('product.4')}}: {{item.unit}}</span>
                  <!-- <span>Sales: {{1000}}</span> -->
                </div>
                <div class="money">${{item.systemPrice}}</div>
              </div>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
      <div class="flex fixed-wrap pl-3">
        <div class="flex-1 flex " @click="allCheck">
          <div class="check-icon" :class="[isAll ? 'check-true ' : 'check']">

          </div>
          <div class="pl-2">
            {{t('product.5')}}: {{ selectNumber() }}
          </div>
        </div>
        <div class="submit-but" @click="openEdit">{{t('product.6')}}</div>
      </div>
    </div>
    <van-action-sheet v-model:show="isShow"  :title="t('product.7')" :actions="categoryArry" @select="onSelect" />
    <edit-profit :isEdit="isEdit" @update="updateInfo" :productArry="productArry" @close="close"></edit-profit>
  </div>
</template>

<script setup>
import { ref,onMounted,watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';
import { getSystemGoods,categoryList,goodsaddOrUpdate } from "@/service/product.api";
import editProfit from './components/editProfit.vue';
const { t } = useI18n();
const route = useRoute()
const router = useRouter()
let value = ref('')
let isShow = ref(false)
let pageNum = ref(1)
let categoryArry = ref([])
let categoryId = ref('')
let isAll = ref(false)
let isEdit = ref(false)
let productArry = ref([])
const list = ref([]);
const loading = ref(false);
const finished = ref(false);
onMounted(() => {
  getCategory()
})
const onSelect = (item) => {
  isShow.value = false
  categoryId.value = item.value
  pageNum.value = 1
  list.value = []
  selectNumber()
  onLoad()
};
const close = () => {
  isEdit.value = false
}
const openEdit = () => {
  productArry.value = []
  list.value.map((item) => {
    if (item.check) {
      productArry.value.push(item.id)
    }
  })
  isEdit.value = true
}
const onLoad = () => {
  let data = {
    pageNum: pageNum.value,
    pageSize: 20,
    lang: 'cn'
  }
  if (categoryId.value) {
    data.categoryId = categoryId.value
  }
  getSystemGoods(data).then((res) => {
    pageNum.value++
    for (let i = 0; i < res.pageList.length; i++) {
      res.pageList[i].check = false
      list.value.push(res.pageList[i]);
    }
    console.log(list.value)
    // 加载状态结束
    loading.value = false;

    if (res.pageList.length == 0) {
      finished.value = true;
    }
  })
}
const getCategory = () => {
  categoryArry.value = []
  let data = {
    // lang: 'cn',
  }
  categoryList(data).then((res) => {
    res.pageList.map((item) => {
      let json = { name: item.name,value:item.categoryId }
      categoryArry.value.push(json)
    })
  })
} 
const allCheck = () => {
  isAll.value = !isAll.value
  list.value.map(item=>{
    if (isAll.value) {
      item.check = true
    } else {
      item.check = false
    }
  })
}
const selectNumber = () => {
  let  number = 0
  list.value.map(item=>{
    if (item.check) {
      number = number+1
    }
  })
  return number
}
const search = () => {
  router.push('/search?id=2')
}
</script>

<style scoped lang="scss">
.product {
  padding-top: 70px;
  padding-bottom: 50px;
  min-height: 100vh;
  background: #EFF2F6;

  .search-wrap {
    margin: 0 15px;
    border-radius: 25px;
    height: 45px;
    text-align: center;

    .search-icon {
      height: 24px;
    }
  }

  .product-header {
    background: #FFFFFF;
    border-radius: 4px;
    padding: 20px 0;
    margin-top: 20px;

    .moeny {
      font-weight: 600;
      font-size: 20px;
    }

    .title {
      margin-top: 10px;
      color: #999999;
    }

    .after {
      position: relative;

      &::after {
        position: absolute;
        height: 100%;
        width: 1px;
        background: #DDDDDD;
        content: '';
        right: 0;
        top: 0;
      }
    }
  }

  .list {
    .item {
      border-radius: 4px;
      align-items: center;

      .more-icon {
        width: 20px;
      }

      .product-img {
        width: 100px;
      }

      .left {
        align-items: center;
        background: #fff;
        padding: 12px;
        border-radius: 4px;

        .product-info {
          padding-left: 10px;

          .name {
            font-size: 14px;
            color: #333333;
            width: 180px;
            height: 50px;
            font-weight: bold;
            overflow: hidden;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            -ms-text-overflow: ellipsis;
            text-overflow: ellipsis;
          }

          .Specification {
            font-size: 12px;
            color: #999999;
          }

          .money {
            color: #1552F0;
            font-weight: bold;
          }
        }
      }


    }

    .product-img-wrap {
      position: relative;
    }

    .delete-wrap {
      padding: 0 15px;
      background: rgba(0, 0, 0, 0.6);
      position: absolute;
      left: 0;
      top: 0;
      font-size: 12px;
      color: #fff;

    }
  }

  .fixed-wrap {
    height: 50px;
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background: #fff;
    align-items: center;

    .submit-but {
      width: 130px;
      background: #1552F0;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      color: #fff;
    }
  }
}

.check-icon {
  width: 20px;
  height: 20px;
}

.check {
  background: url('@/assets/imgs/product/check.png') no-repeat center;
  background-size: 100% 100%;
}

.nav_filtering_icon {
  width: 20px;
  height: 20px;
}

.check-true {
  background: url('@/assets/imgs/product/check-select.png') no-repeat center;
  background-size: 100% 100%;
}

:deep(.van-search__content) {
  background: #fff;
}

:deep(.search-wrap .van-field__control) {
  text-align: center;
}
</style>