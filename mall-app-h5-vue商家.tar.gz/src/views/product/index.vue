<template>
  <div class="product">
    <van-search class="search-wrap" disabled="" @click="search" v-model="value" placeholder="请输入搜索商品" clearable>
      <template #left-icon="icon">
        <img class="search-icon" src="@/assets/imgs/product/search-icon.png" />
      </template>
    </van-search>
    <div class="flex ml-4 mr-4 product-header">
      <div class="flex-1 text-center after" @click="openCommodits">
        <div class="moeny">{{ systemGoodsNum }}</div>
        <div class="title">商品库<van-icon name="arrow" /></div>
      </div>
      <div class="flex-1 text-center" @click="openComment">
        <div class="moeny">{{ evaluations }}</div>
        <div class="title">评论<van-icon name="arrow" /></div>
      </div>
    </div>
    <div class="hot-title ml-4 mr-4 mt-4 mb-4">Hot Products({{ sellerGoodsNum }})</div>
    <div class="list ml-4 mr-4 mt-4 mb-4">

      <van-pull-refresh v-model="loading" @refresh="onRefresh">
        <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
          <div class="item pl-3 pr-3 pb-3 pt-3 flex" @click="getdDtails(item)" v-for="(item, index) in list"
            :key="index">
            <div class="flex-1 flex left">
              <div class="product-img-wrap">
                <img class="product-img" :src="item.imgUrl1" />
                <div class="delete-wrap" @click.stop="deleteGood(item)">删除</div>
              </div>
              <div class="product-info">
                <div class="name">{{ item.name }}</div>
                <div class="Specification">
                  <span>Specification: {{ item.unit }}</span>
                  <span>Sales: {{ item.soldNum }}</span>
                </div>
                <div class="money">${{ item.sellingPrice }}</div>
              </div>
            </div>
            <div>
              <img class="more-icon" @click.stop="openEdit(item)" src="@/assets/imgs/product/more.png" />
            </div>

          </div>
        </van-list>
      </van-pull-refresh>

    </div>
    <edit-product :isEdit="isEdit" @update="updateInfo" :productInfo="productInfo" @close="close"></edit-product>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { merchantGoodsList, sellerGoodsdelete } from "@/service/product.api";
import { useRoute, useRouter } from 'vue-router';
import editProduct from './components/editProduct.vue';
import { useI18n } from 'vue-i18n';
import { Toast, Dialog } from 'vant'
const { t } = useI18n();
const route = useRoute()
const router = useRouter()
let value = ref('')
let isEdit = ref(false)
let pageNum = ref(1)
let evaluations = ref(0)
let systemGoodsNum = ref(0)
let sellerGoodsNum = ref(0)
let productInfo = ref({})
const list = ref([]);
const loading = ref(false);
const finished = ref(false);
const onLoad = () => {
  let data = {
    pageNum: pageNum.value,
    pageSize: 20,
    lang: 'cn',
    isNew: 0,
    isRec: 0,
    isPrice: 0
  }
  merchantGoodsList(data).then((res) => {
    evaluations.value = res.evaluations
    systemGoodsNum.value = res.systemGoodsNum
    sellerGoodsNum.value = res.sellerGoodsNum
    pageNum.value++
    for (let i = 0; i < res.pageList.length; i++) {
      list.value.push(res.pageList[i]);
    }

    // 加载状态结束
    loading.value = false;

    if (res.pageList.length == 0) {
      finished.value = true;
    }
  })
}
const search = () => {
  router.push('/search?id=1')
}
const openCommodits = () => {
  router.push('/productPage/list')
}
const openComment = () => {
  router.push('/productPage/comment')
}
const getdDtails = (item) => {
  router.push({ path: '/productPage/details', query: { item: JSON.stringify(item) } })
}
const close = () => {
  isEdit.value = false
}
const openEdit = (item) => {
  isEdit.value = true
  productInfo.value = item
}
const updateInfo = (item, price) => {
  item.sellingPrice = price
}
const deleteGood = (item) => {
  Dialog.confirm({
    title: '提示',
    message:
      '确认删除吗？',
  })
    .then(() => {
      sellerGoodsdelete({ sellerGoodsId: item.id }).then(() => {
        onLoad()
        Toast('操作成功');
      })
    })
    .catch(() => {
      // on cancel
    });


}
</script>

<style scoped lang="scss">
.product {
  padding-top: 20px;
  padding-bottom: 50px;

  .search-wrap {
    margin: 0 15px;
    border-radius: 25px;
    height: 45px;
    text-align: center;

    .search-icon {
      height: 24px;
    }
  }

  .product-header {
    background: #FFFFFF;
    border-radius: 4px;
    padding: 20px 0;
    margin-top: 20px;

    .moeny {
      font-weight: 600;
      font-size: 20px;
    }

    .title {
      margin-top: 10px;
      color: #999999;
    }

    .after {
      position: relative;

      &::after {
        position: absolute;
        height: 100%;
        width: 1px;
        background: #DDDDDD;
        content: '';
        right: 0;
        top: 0;
      }
    }
  }

  .list {
    .item {
      background: #FFFFFF;
      border-radius: 4px;
      // align-items: center;
      margin-bottom: 20px;

      .more-icon {
        width: 20px;
      }

      .product-img {
        width: 100px;
      }

      .left {
        align-items: center;

        .product-info {
          padding-left: 10px;

          .name {
            font-size: 14px;
            color: #333333;
            width: 180px;
            height: 50px;
            font-weight: bold;
            overflow: hidden;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            -ms-text-overflow: ellipsis;
            text-overflow: ellipsis;
          }

          .Specification {
            font-size: 12px;
            color: #999999;
          }

          .money {
            color: #1552F0;
            font-weight: bold;
          }
        }
      }

    }

    .product-img-wrap {
      position: relative;
    }

    .delete-wrap {
      padding: 0 15px;
      background: rgba(0, 0, 0, 0.6);
      position: absolute;
      left: 0;
      top: 0;
      font-size: 12px;
      color: #fff;
    }
  }

}

:deep(.van-search__content) {
  background: #fff;
}

:deep(.search-wrap .van-field__control) {
  text-align: center;
}
</style>