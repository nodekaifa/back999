<template>
	<div>
		<fx-header>
		  <template #title>
		    订单详情
		  </template>
		</fx-header>
		
		<div class="section">
			<div class="list">
				Order Number <span>153132131 <van-icon name="records" /> </span>
			</div>
			<div class="list">
				Order Time <span>2022-10-30</span>
			</div>
			<div class="list">
				Payment Method <span>Wallet</span>
			</div>
			<div class="list">
				Payment Statue <span>Paid</span>
			</div>
			<div class="list">
				Logistics Status <span>Confirmed</span>
			</div>
			<div class="list">
				Purchase amonut <span>$15.75</span>
			</div>
			<div class="list">
				Sales ambunt <span>$18.90</span>
			</div>
			<div class="list">
				Name <span>Adasd</span>
			</div>
			<div class="list">
				Email<span>54526***</span>
			</div>
			<div class="list">
				Phone <span>+971***</span>
			</div>
			<div class="list">
				国家 <span>USA</span>
			</div>
			<div class="list">
				州 <span>加州</span>
			</div>
			<div class="list">
				城市 <span>洛杉矶</span>
			</div>
			<div class="list">
				邮编 <span>731312</span>
			</div>
			<div class="over">
				<span>收货地址</span>
				 <span>洛杉矶大道12号</span>
			</div>
			
			<div class="listitem">
				<div class="pic">
					<img src="../../assets/imgs/product/111.png"/>
				</div>
				<div class="name">
					<p class="title">ABIR X8扫地机器人，激光导航激光雷达、6500pa 吸力...</p>
				    <p class="col">采购数量</p>
					<p class="title money">$19.80</p>
					<span>x1</span>
				</div>
			</div>
			<div class="listitem">
				<div class="pic">
					<img src="../../assets/imgs/product/111.png"/>
				</div>
				<div class="name">
					<p class="title">ABIR X8扫地机器人，激光导航激光雷达、6500pa 吸力...</p>
				    <p class="col">采购数量</p>
					<p class="title money">$19.80</p>
					<span>x1</span>
				</div>
			</div>
		</div>
		
		<div class="section bottom">
			<div class="list">
				小计 <span>0.00</span>
			</div>
			<div class="list">
				税 <span>0.00</span>
			</div>
			<div class="list">
				运费 <span>0.00</span>
			</div>
			<div class="list">
				折扣 <span>0.00</span>
			</div>
			<div class="list">
				Total <span style="color:#1552F0;font-weight: bold;">$18.90</span>
			</div>
		</div>
	</div>
</template>

<script>
</script>

<style  lang="scss" scoped>
	.section{
		padding:10px 10px 0px 10px;
		box-sizing: border-box;
		.list{
			background: #fff;
			padding:0px 10px;
			box-sizing: border-box;
			color:#aaa;
			line-height:30px;
			height:30px;
			position: relative;
			span{
				color:#666;
				position: absolute;
				right:10px;
			}
		}
		.over{
			background: #fff;
			padding:0px 10px;
			box-sizing: border-box;
			color:#aaa;
			display: flex;
			span:nth-child(1){
				width:30%;
			}
			span:nth-child(2){
				width:70%;
				text-align:right;
				color:#666;
			}
		}
	}
	.listitem{
		background:#fff;
		margin-bottom:10px;
		border-radius:5px;
		display: flex;
		padding:10px;
		box-sizing:border-box;
		position:relative;
		margin-top:10px;
		.pic{
			width:120px;
			height:90px;
			text-align: center;
			img{
				height:90px;
				width:auto;
			}
		}
		.name{
			padding-left:10px;
			.title{
				font-size:15px;
				font-weight:bold;
			}
			.col{
				font-size:13px;
				color:#aaa;
			}
			.money{
				color:#1552F0;
			}
			span{
				position: absolute;
				color:#aaa;
				right:10px;
				bottom:35px;
				color:#1552F0;
			}
		}
	}
	.bottom{
		padding-top:0px;
		padding-bottom:10px;
	}
</style>
