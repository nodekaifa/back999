<template>
  <div>
    <van-tabs v-model="activeName" color="#1552F0" @click="tab">
      <!-- <van-tab title="全部" name="a"></van-tab> -->
      <van-tab title="待采购" name="0"></van-tab>
      <van-tab title="已采购" name="1"></van-tab>
    </van-tabs>

    <div class="main">
      <div class="seach">
        <van-search @input="onSearch" v-model="value" placeholder="搜索" />
        <!-- <div class="seach_list" v-show="showSeach">
				<div v-for="item in list" @click="change(item)">{{item}}</div>
			</div> -->
      </div>

      <div class="dropdown">
        <div class="dropdownitem one">
          <van-dropdown-menu active-color="#1989fa">
            <van-dropdown-item
              @change="onConfirm1"
              :title="title1"
              v-model="value1"
              :options="option1"
            />
          </van-dropdown-menu>
        </div>

        <div class="dropdownitem">
          <van-dropdown-menu active-color="#1989fa">
            <van-dropdown-item
              @change="onConfirm2"
              :title="title2"
              v-model="value2"
              :options="option2"
            />
          </van-dropdown-menu>
        </div>
      </div>

      <div class="goods">
        <div class="goods_list">
          <p class="title">41651531310313</p>
          <p>
            <van-icon size="20px" name="notes-o" />
            <span>下单日期：2022-10-26</span>
          </p>
          <p>
            <van-icon size="20px" name="debit-pay" />
            <span
              >支付状态：
              <span style="color: #dc2626">未支付</span>
              <!-- <span style="color: #f00">已支付</span> -->
            </span>
          </p>
          <p>
            <van-icon size="20px" name="cart-o" />
            <span>采购状态：未采购</span>
          </p>
          <p>
            <van-icon size="20px" name="logistics" />
            <span>物流状态：待发货</span>
          </p>
          <div class="money">
            <p>$18.29</p>
            <span>(利润$3.61)</span>
          </div>
          <!-- <span class="btn" @click="buy">采购</span> -->
        </div>

        <div class="goods_list">
          <p class="title">41651531310313</p>
          <p>
            <van-icon size="20px" name="notes-o" />
            <span>下单日期：2022-10-26</span>
          </p>
          <p>
            <van-icon size="20px" name="debit-pay" />
            <span
              >支付状态：
              <span style="color: #1989fa">已支付</span>
              <!-- <span style="color: #f00">已支付</span> -->
            </span>
          </p>
          <p>
            <van-icon size="20px" name="cart-o" />
            <span>采购状态：未采购</span>
          </p>
          <p>
            <van-icon size="20px" name="logistics" />
            <span>物流状态：待发货</span>
          </p>
          <div class="money">
            <p>$18.29</p>
            <span>(利润$3.61)</span>
          </div>
          <span class="btn" @click="buy">采购</span>
        </div>
      </div>
      {{ orderData }}
    </div>
  </div>
</template>

<script>
import { useUserStore } from '@/store/user' //  拿token
import { orderlist } from '@/service/my.api' //  接口地址

export default {
  name: 'index',
  data() {
    return {
      activeName: 0,
      value: '',
      showSeach: false,
      list: [11212, 6562, 326123, 454113],
      option1: [
        // { text: '全部', value: 0 },
        { text: '未支付', value: 0 },
        { text: '已支付', value: 1 }
        // { text: '已取消', value: 3 },
      ],
      option2: [
        { text: '待发货', value: 1 },
        { text: '已确认', value: 2 },
        { text: '待收货', value: 3 },
        { text: '已收货', value: 4 }
      ],
      orderData: [],
      title1: '支付状态',
      title2: '物流状态',
      value1: '',
      value2: '',
      token: ''
    }
  },
  created() {
    const userStore = useUserStore()
    console.log('userStore', userStore.userInfo.token)
    this.token = userStore.userInfo.token
    this.init(this.token)
  },
  methods: {
    init(token) {
      //  初始
      orderlist({
        token: token,
        // orderId: this.value,
        // payStatus: this.value1,
        purchStatus: '0'
        // status: this.value2,
        // begin: '',
        // end: ''
      })
        .then((res) => {
          if (res.code == 0) {
            this.orderData = res.data.pageList
            console.log('orderData ->', this.orderData)
          }
        })
        .catch((err) => {
          console.log('err->', err)
        })
    },
    tab(name, title) {
      //  标题
      console.log('name', name)
      console.log(title)
    },
    onSearch() {
      // 搜索
      console.log(this.value)
      this.showSeach = true
    },
    change(item) {
      //  选择搜索
      this.value = item
      this.showSeach = false
    },
    onConfirm1(val) {
      this.value1 = this.option1[val].text
      this.title1 = this.value1
    },
    onConfirm2(val) {
      this.value2 = this.option2[val].text
      this.title2 = this.value2
    },
    buy() {
      router.push('/qr_order')
    }
  }
}
</script>

<style lang="scss" scoped>
.van-tab--active {
  color: #1552f0 !important;
}
.main {
  padding: 10px;
  box-sizing: border-box;
}
.van-search {
  padding: 0px !important;
  border-radius: 5px;
  height: 44px;
}
.seach {
  position: relative;
  .seach_list {
    position: absolute;
    top: 35px;
    left: 0px;
    z-index: 999;
    background: #fff;
    width: 100%;
    max-height: 200px;
    overflow-y: scroll;
    padding: 0px 10px;
    box-sizing: border-box;
    div {
      height: 25px;
      line-height: 25px;
    }
  }
}
.dropdown {
  margin: 10px 0px;
  display: flex;
  .dropdownitem {
    width: 48%;
    border-radius: 5px;
    overflow: hidden;
  }
  .one {
    margin-right: 4%;
  }
}
.cenger {
  display: inline-block;
  width: 50px;
}
.goods {
  .goods_list {
    background: #fff;
    padding: 10px;
    box-sizing: border-box;
    border-radius: 5px;
    position: relative;
    margin-bottom: 10px;
    .btn {
      position: absolute;
      display: inline-block;
      width: 80px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      background: #1552f0;
      color: #fff;
      right: 10px;
      bottom: 10px;
      font-size: 13px;
      border-radius: 3px;
    }
    .money {
      position: absolute;
      right: 10px;
      top: 30px;
      font-size: 13px;
      color: #666;
      text-align: center;
      p {
        font-size: 18px;
        font-weight: bold;
        color: #1552f0;
      }
    }
    p {
      height: 25px;
      line-height: 25px;
      span {
        color: #666;
        font-size: 13px;
      }
      i {
        padding-right: 10px;
      }
    }
    .title {
      font-weight: bold;
    }
  }
}
</style>
