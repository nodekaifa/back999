<template>
	<div>
		<fx-header>
		  <template #title>
		    支付成功
		  </template>
		</fx-header>
		
		<div class="center">
			<van-icon name="checked" color="#0ECB81" />
			<p>支付成功</p>
			<div class="phone">如有疑问 ？？立即<span>联系客服</span></div>
		</div>
		
		<div class="bttn">
			<div class="one" @click="back">回到首页</div>
			<div class="two" @click="look">查看订单</div>
		</div>
	</div>
</template>

<script>
	export default{
		data() {
			return{
				
			}
		},
		created() {
			
		},
		methods:{
			look(){
				router.push('/orderdeails')
			},
			back(){
				router.push('/my/index')
			}
		}
	}
</script>

<style lang="scss" scoped>
	.center{
		text-align:center;
		padding:30px 0px;
		i{
			font-size:70px;
		}
		p{
			font-size:18px;
			height:50px;
			line-height:50px;
		}
		.phone{
			font-size:13px;
			color:#666;
			margin-top:30px;
			span{
				padding-left:10px;
				color:#1552F0;
			}
		}
	}
	.bttn{
		padding:10px;
		box-sizing: border-box;
		div{
			width:100%;
			height:40px;
			line-height:40px;
			text-align:center;
			margin-bottom:10px;
			border-radius:5px;
		}
		div.one{
			background:#1552F0;
			color:#fff;
		}
		div.two{
			border:1px solid #1552F0;
			color:#1552F0;
		}
	}
</style>
