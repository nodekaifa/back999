<template>
	<div>
		<fx-header>
		  <template #title>
		    采购确认
		  </template>
		</fx-header>
		<div class="list">
			<div class="listitem">
				<div class="pic">
					<img src="../../assets/imgs/product/111.png"/>
				</div>
				<div class="name">
					<p class="title">ABIR X8扫地机器人，激光导航激光雷达、6500pa 吸力...</p>
				    <p class="col">采购数量</p>
					<p class="title money">$19.80</p>
					<span>x1</span>
				</div>
			</div>
			<div class="listitem">
				<div class="pic">
					<img src="../../assets/imgs/product/111.png"/>
				</div>
				<div class="name">
					<p class="title">ABIR X8扫地机器人，激光导航激光雷达、6500pa 吸力...</p>
				    <p class="col">采购数量</p>
					<p class="title money">$19.80</p>
					<span>x1</span>
				</div>
			</div>
			
		</div>
		<div class="line">
			<div>采购金额<span>$15.75</span></div>
			<div>采购数量<span>2</span></div>
			<div>利润<span>$5.75</span></div>
			<div>合计<span>$18.75</span></div>
		</div>
		
		<div class="btn"><div @click="gobuy">立即支付</div></div>
	</div>
</template>

<script>
	export default {
		data() {
			return{
				
			}
		},
		created() {
			
		},
		methods:{
			gobuy(){
				router.push('/passsuess')
			}
		}
	}
</script>

<style lang="scss" scoped>
	.list{
		padding:10px 10px 0px 10px;
		box-sizing:border-box;
		.listitem{
			background:#fff;
			margin-bottom:10px;
			border-radius:5px;
			display: flex;
			padding:10px;
			box-sizing:border-box;
			position:relative;
			.pic{
				width:120px;
				height:90px;
				text-align: center;
				img{
					height:90px;
					width:auto;
				}
			}
			.name{
				padding-left:10px;
				.title{
					font-size:15px;
					font-weight:bold;
				}
				.col{
					font-size:13px;
					color:#aaa;
				}
				.money{
					color:#1552F0;
				}
				span{
					position: absolute;
					color:#aaa;
					right:10px;
					bottom:35px;
					color:#1552F0;
				}
			}
		}
	}
	.line{
		padding:10px;
		box-sizing: border-box;
		background: #fff;
		div{
			font-size:15px;
			font-weight:bold;
			color:#aaa;
			height:30px;
			line-height:30px;
			position:relative;
			span{
				position:absolute;
				right:0px;
				color:#666;
			}
		}
	}
	.btn{
		position:fixed;
		width:100%;
		bottom:0px;
		left:0px;
		padding:10px;
		box-sizing:border-box;
		div{
			
			height:40px;
			line-height:40px;
			text-align:center;
			border-radius:5px;
			background: #1552F0;
			color:#fff;
		}
	}
</style>
