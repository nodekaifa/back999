<template>
  <div class="search-container">
    <van-nav-bar fixed left-arrow @click-left="() => $router.back()">
      <template #title>
        <van-search v-model="keyword" shape="round" @blur="record" @update:model-value="search" :clearable="false"
          placeholder="请输入商品" @input="inputHandle">
          <template #left-icon>
            <img class="search-icon" src="@/assets/imgs/product/search-icon.png" />
          </template>
          <template #right-icon>
            <van-icon v-if="keyword" name="cross" @click="clearHandle" size="14" color="#333333" />
          </template>
        </van-search>
      </template>
      <!-- <template #right>
        <div @click="search">搜索</div>
      </template> -->
    </van-nav-bar>
    <div class="result-list pl-4 pr-4" v-if="resultList.length > 0">
      <div class="result-list-item pt-2 pb-2" @click="searchGoods(item)" v-for="(item, index) in resultList"
        :key="index">
        {{ item.name }}
      </div>
    </div>
    <div class="search-history" v-if="list.length == 0">
      <div class="title">
        <p>{{ $t('历史搜索') }}</p>
        <div class="clear" @click="emptyHandle" v-if="resultList.length > 0">
          <img src="@/assets/imgs/product/delete.png" alt="" class="delete-icon" />
          <p @click="clear">{{ $t('清空') }}</p>
        </div>
      </div>
      <div class="content">
        <div :key="index" class="item" v-for="(item, index) in searchList" @click="tipsHandle(item)">{{ item }}
        </div>
      </div>
    </div>
    <div class="list ml-4 mr-4 mt-4 mb-4" v-if="list.length > 0">

      <van-pull-refresh v-model="loading" @refresh="onRefresh">
        <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
          <div class="item pl-3 pr-3 pb-3 pt-3 flex" @click="getdDtails(item)" v-for="(item, index) in list"
            :key="index">
            <div class="flex-1 flex left">
              <div class="product-img-wrap">
                <img class="product-img" :src="item.imgUrl1" />
                <div class="delete-wrap" @click.stop="deleteGood(item)">删除</div>
              </div>
              <div class="product-info">
                <div class="name">{{ item.name }}</div>
                <div class="Specification">
                  <span>Specification: {{ item.unit }}</span>
                  <span>Sales: {{ item.soldNum }}</span>
                </div>
                <div class="money">${{ item.sellingPrice }}</div>
              </div>
            </div>
            <div>
              <img class="more-icon" @click.stop="openEdit(item)" src="@/assets/imgs/product/more.png" />
            </div>

          </div>
        </van-list>
      </van-pull-refresh>

    </div>
    <edit-product :isEdit="isEdit" @update="updateInfo" :productInfo="productInfo" @close="close"></edit-product>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import editProduct from '../product/components/editProduct.vue';
import { useRoute, useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';
import { searchKeyword, searchSllerKeyword, sellerGoodsList,sellerGoodsdelete } from "@/service/product.api";
import { setStorage, getStorage } from '@/utils/index'
import { Toast, Dialog } from 'vant'
const { t } = useI18n();
const router = useRouter();
let keyword = ref('')
let pageNum = ref(1)
let goodsId = ref('')
let isEdit = ref(false)
let productInfo = ref({})
const list = ref([]);
const resultList = ref([]);
const loading = ref(false);
const finished = ref(false);
let searchList = ref(getStorage('search') || [])
const inputHandle = () => {

}
const search = () => {

  if (keyword.value != '') {
    let data = {
      keyword: keyword.value,
      lang: 'cn'
    }
    searchSllerKeyword(data).then((res) => {
      resultList.value = res.goodsList
    })
  }
}
const record = () => {
  if (keyword.value != '') {
    if (searchList.value.length == 0) {
      searchList.value.push(keyword.value)
      setStorage('search', searchList.value)
    } else {
      let index = 0
      searchList.value.map(item => {
        if (keyword.value == item) {
          index = index + 1
        } else {
          index = 0
        }
      })
      if (index == 0) {
        searchList.value.push(keyword.value)
        setStorage('search', searchList.value)
      }
    }
  }
}
const clearHandle = () => {
  keyword.value = ''
}
const tipsHandle = (item) => {
  keyword.value = item
  search()
}
const clear = (item) => {
  searchList.value = []
  setStorage('search', '')
}
const onLoad = () => {
  let data = {
    pageNum: pageNum.value,
    pageSize: 20,
    lang: 'cn',
    goodsId: goodsId.value
  }
  sellerGoodsList(data).then((res) => {
    pageNum.value++
    for (let i = 0; i < res.pageList.length; i++) {
      res.pageList[i].check = false
      list.value.push(res.pageList[i]);
    }
    // 加载状态结束
    loading.value = false;

    if (res.pageList.length == 0) {
      finished.value = true;
    }
  })
}
const searchGoods = (item) => {
  keyword.value = ''
  resultList.value = []
  goodsId.value = item.goodsId
  pageNum.value = 1
  list.value = []
  onLoad()
}
const openEdit = (item) => {
  isEdit.value = true
  productInfo.value = item
}
const updateInfo = (item, price) => {
  item.sellingPrice = price
}
const close = () => {
  isEdit.value = false
}
const getdDtails = (item) => {
  router.push({ path: '/productPage/details', query: { item: JSON.stringify(item) } })
}
const deleteGood = (item) => {
  Dialog.confirm({
    title: '提示',
    message:
      '确认删除吗？',
  })
    .then(() => {
      sellerGoodsdelete({ sellerGoodsId: item.id }).then(() => {
        onLoad()
        Toast('操作成功');
      })
    })
    .catch(() => {
      // on cancel
    });


}
</script>

<style lang="scss" scoped>
.search-container {
  padding-top: 50px;

  :deep(.van-field__left-icon) {
    display: flex;
    align-items: center;
    width: 16px;
    margin-right: 8px;

    >img {
      width: 100%;
      height: auto;
    }
  }

  :deep(.van-nav-bar__left) {
    padding-right: 10px !important;
  }

  :deep(.van-nav-bar__title) {
    width: 73.6% !important;
    max-width: 73.6% !important;
    position: relative;
  }

  :deep(.van-search) {
    padding: 0 !important;

    .van-search__content {
      background-color: #fff;
    }
  }

  .search-btn {
    font-size: 12px;
    color: #333;
  }

  .search-history {
    padding: 0 15px;

    >.title {
      padding: 25px 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 14px;
      color: #000;

      >.clear {
        display: flex;
        align-items: center;

        >img {
          width: 14px;
          height: auto;
          margin-right: 5px;
        }

        >p {
          font-size: 14px;
          color: #333;
        }
      }
    }

    >.content {
      overflow: hidden;

      &.no {
        display: flex;
        justify-content: center;
        font-size: 14px;
        color: #999;
      }

      >.item {
        float: left;
        padding: 4px 15px;
        background-color: #fff;
        border-radius: 5px;
        color: #999;
        font-size: 12px;
        margin-right: 14px;
        margin-bottom: 22px;
      }
    }
  }

  .search-tips-content {
    >.item {
      padding: 23px 15px;
      border-bottom: 1px solid #eee;
      display: flex;
      align-items: center;

      .van-icon {
        margin-right: 5px;
      }

      >p {
        color: #333;
        font-size: 12px;
      }
    }
  }

  .shop-list-content {
    padding: 20px 15px;

    >.tips {
      font-size: 12px;
      color: #333;

      >span {
        color: #F89900;
      }
    }
  }
}

:deep(.van-icon) {
  font-size: 18px;
  color: #1F2025;
}

.delete-icon {
  width: 15px;
}

.list {
  .item {
    background: #FFFFFF;
    border-radius: 4px;
    // align-items: center;
    margin-bottom: 20px;

    .more-icon {
      width: 20px;
    }

    .product-img {
      width: 100px;
    }

    .left {
      align-items: center;

      .product-info {
        padding-left: 10px;

        .name {
          font-size: 14px;
          color: #333333;
          width: 180px;
          height: 50px;
          font-weight: bold;
          overflow: hidden;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          -ms-text-overflow: ellipsis;
          text-overflow: ellipsis;
        }

        .Specification {
          font-size: 12px;
          color: #999999;
        }

        .money {
          color: #1552F0;
          font-weight: bold;
        }
      }
    }

  }

  .product-img-wrap {
    position: relative;
  }

  .delete-wrap {
    padding: 0 15px;
    background: rgba(0, 0, 0, 0.6);
    position: absolute;
    left: 0;
    top: 0;
    font-size: 12px;
    color: #fff;
  }
}

.result-list {
  position: fixed;
  top: 46px;
  left: 0;
  width: 100%;
  background: #fff;
  z-index: 2;
  font-size: 14px;

  .result-list-item {
    border-bottom: 1px solid #EFF2F6;
  }
}
</style>
