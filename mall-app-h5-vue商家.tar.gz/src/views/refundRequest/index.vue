<template>

  <div class="h-full w-full">
    <fx-header>
      <template #title>
        {{ $t('refundRequest') }}
      </template>
    </fx-header>
    <div class="main">
      <div class="card bg-white text-sm" v-for="item in list">
        <van-card
            price="2.00"
            desc="描述信息"
            title="商品标题"
            thumb="https://fastly.jsdelivr.net/npm/@vant/assets/ipad.jpeg"
        />
        <div class="h-10 leading-10 flex van-row--justify-space-between">
          <div class="name">申请时间</div>
          <div class="info">{{item.refundTime}}</div>
        </div>
        <div class="h-10 leading-10 flex van-row--justify-space-between">
          <div class="name">退款单号</div>
          <div class="info">{{item.id}}</div>
        </div>
        <div class="h-10 leading-10 flex van-row--justify-space-between">
          <div class="name">退款金额</div>
          <div class="info">${{item.returnPrice}}</div>
        </div>
        <div class="h-10 leading-10 flex van-row--justify-space-between">
          <div class="name">退款状态</div>
          <div :style="{color:handleStatusColor(item.returnStatus)}">{{handleStatus(item.returnStatus)}}</div>
        </div>
        <div class="h-10 leading-10 flex van-row--justify-space-between">
          <div class="name">退款理由</div>
          <div class="info">{{item.returnReason}}</div>
        </div>
        <div class="h-10 leading-10 flex van-row--justify-space-between">
          <div class="name">退款说明</div>
          <div class="info">{{item.returnDetail || '无'}}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import {ref, onMounted} from "vue";
import { useI18n } from 'vue-i18n';
import {_returnApply} from "../../service/goods.api.js";
const { t } = useI18n();

const list = ref([]);
onMounted(async () => {
 const data = await _returnApply();
 if (data) {
   list.value = data.pageList
   console.error(data)
 }
})
const handleStatus = (type) => {
  switch (type) {
    case 0:
    case 3:
      return "失败";
    case 1:
      return "申请中";
    case 2:
      return "成功";

  }
}

const handleStatusColor = (type) => {
  switch (type) {
    case 0:
    case 3:
      return "#FF3E3E";
    case 1:
      return "#F99746";
    case 2:
      return "#0ECB81";
  }
}

</script>

<style scoped lang="scss">

.main {
  padding: var(--van-cell-group-inset-padding);
  background-color: #EFF2F6;
}
.card {
  padding: var(--van-card-padding);
  margin-top: 15px;
  border-radius: 4px;
  .name {
    color: #999;
  }
  .info {
    color: #333;
  }
}
:deep(.van-card) {
  background: #fff !important;
  padding: 0 !important;
  .van-card__title {
    font-size: 14px;
  }
  .van-card__price {
    color:#1552F0;
    font-size: 16px;
  }
}
</style>
