<template>
    <div class="register">
        <div class="top" @click="router.go(-1)"><img src="../../assets/image/Union.png" alt=""></div>
        <Step :step="1"></Step>
        <div class="title textColor">{{ $t('register') }}</div>
        <div class="flex re-tab">
            <div class="textColor1" :class="activeIndex == 0 ? 'active' : ''" @click="changeIndex(0)">{{ $t('account')
            }}</div>
            <div class="textColor1" :class="activeIndex == 1 ? 'active' : ''" @click="changeIndex(1)">{{ $t('email') }}
            </div>
            <div class="textColor1" :class="activeIndex == 2 ? 'active' : ''" @click="changeIndex(2)">{{ $t('phoneNum')
            }}</div>
        </div>
        <ExInput :label="getRegType(activeIndex, true)" :placeholderText="getRegType(activeIndex, false)"
            v-model="username" :area="isArea" :dialCode="dialCode" @selectArea="onSelectArea" :icon="icon" />

        <ExInput :label="$t('setPassword')" :placeholderText="$t('passwordTips')" v-model="password"
            typeText="password" />
        <ExInput :label="$t('repassword')" :placeholderText="$t('surePassword')" v-model="repassword"
            typeText="password" />
        <ExInput :label="$t('invitCode')" :placeholderText="$t('entryInvitCode')" v-model="invitCode"
            :clearBtn="false" />
        <div class="protocol textColor">
            <i @click="agreeProt">
                <img v-show="agree" src="../../assets/image/login/prot2.png" alt="" />
                <img v-show="!agree" src="../../assets/image/login/prot1.png" alt="" />
            </i>
            {{ $t('readAgree') }}<span class="colorMain" @click="router.push('/TermsOfService')">{{ $t('serviceConf')
            }}</span>
        </div>
        <van-button class="w-full" style="margin-top:10px;" type="primary" @click="register">{{ $t('register') }}
        </van-button>
        <div class="noTips textColor">{{ $t('hasAccount') }}<span class="colorMain" @click="router.push('/login')">
                {{ $t('goLogin') }}</span>
        </div>
        <nationality-list ref='controlChildRef' :title="$t('selectArea')" @get-name="getName"></nationality-list>

        <Vcode :imgs="[img1, img2]" :show="show" @success="onSuccess" :canvasHeight="200" @fail="onFail"
            @close="show = false;" sliderText='' :successText="$t('vertifyPass')" :failText="$t('vertifuFail')" />

        <div>{{ msg }}</div>
    </div>
</template>

<script setup>
import ExInput from "@/components/ex-input/index.vue";
import Step from "./step.vue";
import { _registerUser } from "@/service/login.api";
import { useUserStore } from '@/store/user';
import { GET_USERINFO } from '@/store/types.store'
import nationalityList from '../authentication/components/nationalityList.vue'
import Vcode from "vue3-puzzle-vcode";
import img1 from "../../assets/image/slider/1.png";
import img2 from "../../assets/image/slider/2.png";
import { getStorage } from '@/utils/index'
import { useI18n } from 'vue-i18n'
import { useRouter } from 'vue-router';
import { ref, onMounted } from 'vue';
import { Toast } from "vant";
const { t } = useI18n()
const router = useRouter()
const onRoute = (path) => {
    router.push(path)
}
const userStore = useUserStore();

let show = ref(false)
const msg = ref('')
const type = ref(1)
let agree = ref(false)
const username = ref('')
const password = ref('')
const repassword = ref('')
const fundPassword = ref('')
const refundPassword = ref('')
const activeIndex = ref(0)
const typeText = ref('password')
let isArea = ref(false)
let dialCode = ref(0)
let icon = ref('')

let invitCode = ref('')
onMounted(() => {
    let usercode = getStorage('usercode')
    if (usercode) {
        invitCode = usercode;
    }
})
const getRegType = (activeIndex, bFlag) => {
    switch (activeIndex) {
        case 0:
            return bFlag ? t('account') : t('entryAccount');
        case 1:
            return bFlag ? t('email') : t('entryEmail');
        case 2:
            return bFlag ? t('phoneNum') : t('entryPhone');
    }
}
const onSuccess = () => {
    console.log('onSuccess')
    registerApi();
    show.value = false;
}
const onFail = () => {
    msg.value = ''
}
const onRefresh = () => {
    msg.value = ''
}

const controlChildRef = ref(null)
const onSelectArea = () => {
    controlChildRef.value.open();
}

const getName = (childname, childcode, childdialCode) => {
    icon.value = childcode;
    dialCode.value = childdialCode;
}
const agreeProt = () => {
    agree.value = !agree.value
}
const register = () => {
    if (activeIndex.value == 0) {
        console.log(username.value)
        if (username.value == '') {
            Toast(t('entryAccount'));
            return
        }
        if (username.value.length < 6 || username.value.length > 30) {
            Toast(t('accountLength'));
            return
        }
    } else if (activeIndex.value == 1) {
        let match = username.value.search(/@/);
        if (username.value == '' || match.value == -1) {
            Toast(t('entryCorrectEmail'));
            return
        }
    } else if (activeIndex.value == 2) {
        if (username.value == '') {
            Toast(t('entryPhone'));
            return
        }
    }
    if (password.value == '') {
        Toast(t('entryPassword'));
        return
    }
    if (password.value.length < 6) {
        Toast(t('passwordTips'));
        return
    }
    if (repassword.value !== password.value) {
        Toast(t('noSamePassword'));
        return
    }
    if (!agree.value) {
        Toast(t('agreeServiceCond'));
        return
    }
    show.value = true
}
const changeIndex = (index) => {
    activeIndex.value = index;
    if (index == 0 || index == 1) {
        isArea.value = false
    } else {
        isArea.value = true
    }
}
const registerApi = () => {
    switch (activeIndex.value) {
        case 0:
            {
                type.value = 3;
                break;
            }
        case 1:
            {
                type.value = 2;
                break;
            }
        case 2:
            {
                type.value = 1;
                break;
            }
    }

    _registerUser({
        username: (activeIndex.value == 0 || activeIndex.value == 1) ? username.value : `${dialCode.value}${username.value}`,
        password: password.value,
        re_password: repassword.value,
        type: type.value,
        usercode: invitCode.value,
    }).then((res) => {
        userStore[GET_USERINFO](res)
        if (activeIndex.value == 0) {
            router.push('/setFond')
        } else {
            router.push({ name: 'verify', query: { type: activeIndex.value, account: activeIndex.value == 1 ? username.value : `${dialCode.value}${username.value}` } })
        }
    });
}


</script>

<style lang="scss" scoped>
.activeBKClick {
    &:active {
        background: #1989fa;
        opacity: 0.5;
    }
}

.activeClick {
    &:active {
        background: #fff;
        opacity: 0.5;
    }
}

.register {
    width: 100%;
    box-sizing: border-box;
    padding: 16px;
    font-size: 13px;
}

.top {
    padding-left: 9px;
    padding-top: 9px;

    img {
        width: 18px;
        height: 18px;
    }
}

.title {
    font-weight: 700;
    font-size: 26px;
    margin-top: 27px;
    margin-bottom: 33px;
}

.re-tab {
    margin-bottom: 22px;

    div {
        padding: 0 18px;
        height: 34px;
        line-height: 34px;
        text-align: center;
        border-radius: 4px;
        margin-right: 10px;
    }

    .active {
        background: #F5F5F5;
        color: #222;
    }
}

.forget {
    color: #1D91FF;
    font-size: 12px;
    line-height: 14px;
}

.noTips {
    margin-top: 24px;
}

.protocol {
    display: flex;
    align-items: center;
    height: 15px;

    i {
        width: 15px;
        height: 15px;
        margin-right: 9px;

        img {
            width: 100%;
            height: 100%;
        }
    }
}
</style>
