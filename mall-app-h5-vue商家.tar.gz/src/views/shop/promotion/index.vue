<template>
  <div class="shop-promotion">
    <fx-header :fixed="true">
      <template #title>
        {{ t('soical') }}
      </template>
    </fx-header>
    <div style="height: 46px;" />
    <div class="promotion-info">
      <div v-for="item in promotionDataRef" :key="item.key" class="item">
        <p>{{ t(item.title) }}</p>
        <van-field
          v-model="item.value"
          center
          label=""
          placeholder=""
        >
          <template #button>
            <van-button @click="copyHandle(item.value)" size="small" type="primary">{{ t('copy') }}</van-button>
          </template>
        </van-field>
      </div>
    </div>

    <div class="team-content">
      <van-tabs v-model:active="navActive" color="#1552F0" title-inactive-color="#999999" title-active-color="#1552F0" @change="navChange">
        <van-tab v-for="item in teamNav" :key="item.key" :title="t(item.title)"></van-tab>
      </van-tabs>

      <van-pull-refresh v-model="refreshing" :pulling-text="t('pullingText')" :loosing-text="t('loosingText')" :loading-text="t('loading')" @refresh="onRefresh">
        <van-list v-model:loading="loading" :finished="finished" :loading-text="t('loading')" :finished-text="t('product.3')" @load="getLevelData">
          <div v-if="listData.length" class="list-content">
            <div v-for="(item, index) in listData" :key="index" class="item">
              <div class="avatar">
                <img :src="item.avatarImg" alt="">
              </div>
              <div class="info">
                <p class="name">{{ item.username }}</p>
                <p class="rebate">{{ `${(t('shopRebate'))}：${item.rebate}`}}</p>
                <div>
                  <p>{{ `${(t('shopCountOrder'))}：${item.countOrder}`}}</p>
                  <p>{{ `${(t('shopRegTime'))}：${item.regTime}`}}</p>
                </div>
              </div>
            </div>
          </div>
          <van-empty v-if="!listData.length && !loading" :image="empytImg" :description="t('noData')" />
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref, computed, nextTick } from 'vue'
import { useI18n } from 'vue-i18n'
import { Toast } from 'vant'
import useClipboard from 'vue-clipboard3'

import { promotionData, teamNav } from './../config'
import {
  sellerPromotional,
  sellerPromotionalTeam
} from '@/service/shop.api.js'

export default defineComponent({
  name: 'shopPromotion',
  setup() {
    const { t } = useI18n()

    const empytImg = new URL('@/assets/image/public/no_data.png', import.meta.url)
    const promotionDataRef = ref([...promotionData])
    const { toClipboard } = useClipboard()
    const copyHandle = async (txt) => {
      try {
        await toClipboard(txt)
        Toast(t('copySuccess'))
      } catch (e) {
        console.error(e);
      }
    }

    const navActive = ref(0)
    const currentLevel = computed(() => {
      return teamNav[navActive.value].key
    })
    const listData = ref([])
    const refreshing = ref(false)
    const loading = ref(true)
    const finished = ref(false)
    const page = ref({
      pageNum: 1,
      pageSize: 10
    })

    const dataFormate = async (data) => {
      const dataArr = []
      for (let i = 0; i < data.length; i++) {
        const obj = {
          ...data[i]
        }
        if (isNaN(Number(data[i].avatar))) {
          obj.avatarImg = data[i].avatar
          dataArr.push(obj)
        } else {
          await import(`./../../../assets/image/avatar/head_${data[i].avatar}.jpg`).then((res) => {
            obj.avatarImg = res.default
            dataArr.push(obj)
          })
        }
      }
      return dataArr
    }
    
    const getLevelData = async () => {
      const params = {
        ...page.value,
        level: currentLevel.value
      }
      await sellerPromotionalTeam(params).then(async res => {
        const  { pageList } = res || []
        const data = await dataFormate(pageList)
        
        listData.value = page.value.pageNum === 1 ? data : [...listData.value, ...data]
        page.value.pageNum++
        loading.value = false
        refreshing.value = false
        if (data.length < page.value.pageSize) {
          finished.value = true
        }
      }).catch(() => {
        loading.value = false
        finished.value = true
      })
    }

    const onRefresh = () => {
      finished.value = false
      loading.value = true
      page.value.pageNum = 1
      getLevelData()
    }

    const navChange = () => {
      listData.value = []
      onRefresh()
    }

    nextTick(() => {
      Toast.loading({
        duration: 0,
        message: t('loading'),
        forbidClick: true
      })

      sellerPromotional().then(res => {
        promotionDataRef.value[0].value = res.download || ''
        promotionDataRef.value[1].value = res.code || ''
        Toast.clear()
      }).catch(() => {
        Toast.clear()
      })
    })
    
    return {
      promotionDataRef,
      navActive,
      teamNav,
      refreshing,
      loading,
      finished,
      listData,
      empytImg,
      t,
      copyHandle,
      navChange,
      getLevelData,
      onRefresh
    }
  }
})
</script>

<style lang="scss" scoped>
.shop-promotion {
  min-height: 100vh;
  background-color: #fff;
  .promotion-info {
    padding: 0 15px 16px 15px;
    background-color: #fff;
    > .item {
      margin-top: 24px;
      > p {
        color: #333;
        font-size: 14px;
      }
      :deep(.van-cell) {
        padding: 0;
        margin-top: 5px;
        .van-field__body {
          input {
            border: 1px solid #ddd;
            border-right: none;
            height: 44px;
            border-top-left-radius: 4px;
            border-bottom-left-radius: 4px;
            padding: 0 10px;
            pointer-events: none;
          }
          .van-field__button {
            padding-left: 0;
            .van-button {
              width: 86px;
              height: 44px;
              border-radius: 4px;
              background-color: #1552F0;
              border-color: #1552F0;
            }
          }
        }
      }
    }
  }
  .team-content {
    border-top: 10px solid #EFF2F6;
    :deep(.van-tabs) {
      border-bottom: 1px solid #eee;
    }
    .list-content {
      > .item {
        display: flex;
        padding: 15px;
        border-bottom: 1px solid #eee;
        background-color: #fff;
        > .avatar {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          overflow: hidden;
        }
        > .info {
          flex: 1;
          padding-left: 10px;
          font-size: 12px;
          line-height: 14px;
          color: #999;
          > .rebate {
            color: #333;
            margin-top: 15px;
          }
          > div {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 10px;
            > p {
              &:first-child {
                color: #333;
              }
            }
          }
        }
      }
    }
  }
}
</style>
