<template>
  <div>
    <fx-header :fixed="true">
      <template #title>
        {{ t('throughCar') }}
      </template>
      <template #right>
        <p @click="openPage('/shop/marketing/record')">{{ t('shopBuyRecord') }}</p>
      </template>
    </fx-header>
    <div style="height: 46px;" />
    <div v-if="listData.length" class="marketing-content">
      <div v-for="item in listData" :key="item.id" class="item">
        <div class="icon">
          <img :src="item.icon" alt="" />
        </div>
        <div class="info">
          <h3>{{ item.name }}</h3>
          <p>{{ item.desc1 }}</p>
          <div>
            <p>${{ item.prize }}<span>/{{ item.per }}{{ t('days') }}</span></p>
            <van-button type="primary" size="small" @click="buyHandle(item)">{{ t('shopBuyNow') }}</van-button>
          </div>
        </div>
      </div>
    </div>
    <van-empty v-if="!listData.length && !pageLoading" :image="empytImg" :description="t('noData')" />

    <van-popup
      v-model:show="passwordShow"
      closeable
      position="bottom"
      safe-area-inset-bottom
      :style="{ height: '280px' }"
    >
      <div class="popup-content">
        <p class="title">{{ t('shopSafeTips') }}</p>
        <ExPasswordInput ref="passwordInputRef" v-model="safewordInput" has-gap />
        <van-button
          style="margin-top: 50px"
          type="primary"
          :loading="loading"
          :disabled="computedSafeWord"
          @click="buySureHandle"
          >{{ $t('sure') }}
        </van-button>
      </div>
    </van-popup>
  </div>
</template>

<script>
import { defineComponent, nextTick, ref, computed, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { Toast, Dialog } from 'vant'
import { useUserStore } from '@/store/user.js'
import {
  openPage
} from '@/utils'

import {
  sellerPromotionalView,
  sellerPromotionalBuy
} from '@/service/shop.api.js'

export default defineComponent({
  name: 'ShopMarketing',
  setup() {
    const { t } = useI18n()
    const empytImg = new URL('@/assets/image/public/no_data.png', import.meta.url)
    const listData = ref([])
    const userStore = useUserStore()
    const safewordInput = ref('')
    const currentItem = ref()
    const passwordShow = ref(false)
    const loading = ref(false)
    const pageLoading = ref(true)

    watch(passwordShow, (val) => {
      if (!val) {
        safewordInput.value = ''
      }
    })

    const computedSafeWord = computed(() => {
      const val = safewordInput.value
      return String(val).length < 6
    })

    const buyHandle = (data) => {
      const safeword = Boolean(Number(userStore?.userInfo?.safeword))
      if (safeword) {
        currentItem.value = data
        passwordShow.value = true
      } else {
        Dialog.confirm({
          title: t('dialogTips'),
          message: t('shopSafeWord'),
          cancelButtonText: t('cancel'),
          confirmButtonText: t('gotoSet'),
          confirmButtonColor: '#1552F0',
          cancelButtonColor: '#999'
        }).then(() => {
          openPage('/personalInfo')
        }).catch(() => {
          console.log('cancel')
        });
      }
    }

    const buySureHandle = () => {
      loading.value = true
      const params = {
        id: currentItem.value.id,
        safeword: safewordInput.value
      }

      sellerPromotionalBuy(params).then(() => {
        Toast.success(t('shopBuySuc'))
        loading.value = false
        passwordShow.value = false
      }).catch(() => {
        loading.value = false
      })
    }

    nextTick(() => {
      Toast.loading({
        duration: 0,
        message: t('loading'),
        forbidClick: true
      })

      sellerPromotionalView().then(res => {
        listData.value = res.line || []
        Toast.clear()
        pageLoading.value = false
      }).catch(() => {
        Toast.clear()
        pageLoading.value = false
      })
    })
    return {
      listData,
      passwordShow,
      safewordInput,
      computedSafeWord,
      empytImg,
      loading,
      pageLoading,
      t,
      buyHandle,
      buySureHandle,
      openPage
    }
  }
})
</script>

<style lang="scss" scoped>
.marketing-content {
  padding: 15px;
  > .item {
    padding: 15px;
    background-color: #fff;
    border-radius: 4px;
    margin-bottom: 15px;
    display: flex;
    > .icon {
      width: 48px;
    }
    > .info {
      flex: 1;
      padding-left: 15px;
      > h3 {
        color: #000;
        font-size: 16px;
        font-weight: bold;
      }
      > p {
        font-size: 14px;
        color: #999;
        line-height: 16px;
        margin-top: 2px;
      }
      > div {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 10px;
        > p {
          line-height: 1;
          font-size: 18px;
          font-weight: bold;
          color: #1552F0;
          > span {
            font-weight: normal;
            font-size: 12px;
          }
        }
        :deep(.van-button--primary) {
          background-color: #1552F0;
          border-color: #1552F0;
          border-radius: 4px;
          padding: 1px 10px !important;
        }
      }
    }
  }
}
.popup-content {
  padding: 0 30px 30px 30px;
  > .title {
    padding-top: 15px;
    padding-bottom: 30px;
    text-align: center;
  }
  :deep(.van-button--primary) {
    width: 100%;
    background-color: #1552F0;
    border-color: #1552F0;
    border-radius: 4px;
  }
}
</style>
