export const saleData = [
  {
    title: 'totalSales',
    number: 0
  },
  {
    title: 'totalProfit',
    number: 0
  }
]

export const visitorsData = [
  {
    title: 'todayVisitors',
    number: 0
  },
  {
    title: 'visitors7',
    number: 0
  },
  {
    title: 'visitors30',
    number: 0
  }
]

export const navData = [
  {
    title: 'information',
    icon: new URL('@/assets/image/shop/icon_01.png', import.meta.url),
    href: '/shop/basicInfo'
  },
  {
    title: 'banner',
    icon: new URL('@/assets/image/shop/icon_02.png', import.meta.url),
    href: ''
  },
  {
    title: 'soical',
    icon: new URL('@/assets/image/shop/icon_03.png', import.meta.url),
    href: ''
  },
  {
    title: 'throughCar',
    icon: new URL('@/assets/image/shop/icon_04.png', import.meta.url),
    href: ''
  },
  {
    title: 'refunds',
    icon: new URL('@/assets/image/shop/icon_05.png', import.meta.url),
    href: ''
  },
  {
    title: 'promotion',
    icon: new URL('@/assets/image/shop/icon_06.png', import.meta.url),
    href: ''
  },
  {
    title: 'recharge',
    icon: new URL('@/assets/image/shop/icon_07.png', import.meta.url),
    href: '/recharge'
  },
  {
    title: 'withdraw',
    icon: new URL('@/assets/image/shop/icon_08.png', import.meta.url),
    href: '/withdraw'
  }
]

export const statItemData = [
  {
    title: 'totalSalesToday',
    icon: new URL('@/assets/image/shop/icon_09.png', import.meta.url),
    number: 0,
    decimals: 2,
    prefix: '$'
  },
  {
    title: 'ordersSoldToday',
    icon: new URL('@/assets/image/shop/icon_10.png', import.meta.url),
    number: 0,
    decimals: 0,
    prefix: ''
  },
  {
    title: 'profitToday',
    icon: new URL('@/assets/image/shop/icon_11.png', import.meta.url),
    number: 0,
    decimals: 2,
    prefix: '$'
  }
]

export const statBlockData = [
  {
    title: 'totalOrders',
    number: 0,
    color: '#5C9DFF'
  },
  {
    title: 'waitingOrders',
    number: 0,
    color: '#FF8049'
  },
  {
    title: 'successfulOrders',
    number: 0,
    color: '#3FBC8F'
  },
  {
    title: 'orderCancellation',
    number: 0,
    color: '#5D6A7E'
  }
]
