<template>
  <div class="goods-item">
    <div class="poster">
      <img :src="goodsData.imgUrl1 || goodsData.imgUrl2 || goodsData.imgUrl3 || goodsData.imgUrl4" alt="" />
    </div>
    <div class="info-content">
      <p class="name">{{ goodsData.name }}</p>
      <div>
        <div>{{ t('browse') }}: {{ goodsData.viewsNum }}</div>
        <div>{{ t('sales') }}: {{ goodsData.soldNum }}</div>
      </div>
      <p class="price">${{ goodsData.sellingPrice }}</p>
    </div>
  </div>
</template>

<script>
import { defineComponent } from 'vue'
import { useI18n } from 'vue-i18n'

export default defineComponent({
  name: 'GoodsItem',
  props: {
    goodsData: {
      type: Object,
      default: () => {}
    }
  },
  setup() {
    const { t } = useI18n()

    return {
      t
    }
  }
})
</script>

<style lang="scss" scoped>
.goods-item {
  padding: 10px;
  background-color: #fff;
  border-radius: 4px;
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  &:last-child {
    margin-bottom: 0;
  }
  > .poster {
    width: 78px;
    height: 78px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    > img {
      width: 100%;
      height: auto;
    }
  }
  > .info-content {
    flex: 1;
    padding-left: 10px;
    > .name {
      font-size: 14px;
      line-height: 18px;
      font-size: #333;
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: 2;
    }
    > div {
      display: flex;
      align-items: center;
      > div {
        font-size: 12px;
        color: #999;
        margin-right: 15px;
        &:last-child {
          margin-right: 0;
        }
      }
    }
    > .price {
      font-size: 16px;
      color: #1552F0;
    }
  }
}
</style>
