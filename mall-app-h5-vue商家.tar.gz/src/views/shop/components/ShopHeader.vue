<template>
  <div className="shop-header">
    <div className="avatar">
      <img v-if="sellerData.avatar" :src="sellerData.avatar" alt="">
      <img v-else :src="images.logo" alt="">
    </div>
    <p className="name">{{ sellerData.name || 'Store Name' }}</p>
    <div className="enter">
      <img :src="images.service" alt="" @click="openPage('/customerService')">
      <!-- <img :src="images.message" alt=""> -->
    </div>
  </div>
</template>

<script>
import {defineComponent, ref} from 'vue'
import {openPage} from '@/utils'
import {
  sellerInfo
} from '@/service/shop.api.js'

export default defineComponent({
  name: 'ShopHeader',
  setup() {
    const sellerData = ref({})

    const images = {
      logo: new URL('@/assets/image/shop/logo.png', import.meta.url),
      service: new URL('@/assets/image/shop/service.png', import.meta.url),
      message: new URL('@/assets/image/shop/message.png', import.meta.url)
    }

    sellerInfo().then(res => {
      sellerData.value = res
    })

    return {
      sellerData,
      images,
      openPage
    }
  }
})

</script>

<style lang="scss" scoped>
.shop-header {
  width: 100%;
  height: 140px;
  background-color: #1552F0;
  display: flex;
  align-items: center;
  padding: 0 15px;
  border-bottom: 42px solid #1552F0;

  > .avatar {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    border: 1.5px solid #fff;
    overflow: hidden;

    > img {
      width: 100%;
      height: 100%;
    }
  }

  > .name {
    flex: 1;
    padding: 0 10px;
    color: #fff;
    font-size: 16px;
    font-weight: bold;
  }

  > .enter {
    display: flex;
    align-items: center;

    > img {
      width: 20px;
      height: 20px;
      margin-right: 15px;

      &:last-child {
        margin-right: 0;
      }
    }
  }
}
</style>
