<template>
  <div>
    <van-pull-refresh
      v-model="refreshing"
      :pulling-text="t('pullingText')"
      :loosing-text="t('loosingText')"
      :loading-text="t('loading')"
      @refresh="onRefresh"
    >
      <shop-header />
      <div class="shop-main-content">
        <div style="padding: 0 15px">
          <div class="block-content sale-number">
            <div v-for="item in saleDataRef" :key="item.title" class="item">
              <count-to
                v-if="Number(item.number) > 0"
                prefix="$"
                :startVal="0"
                :endVal="item.number"
                :decimals="2"
                :duration="1500"
                :class="{ mini: Number(item.number) > 9999999 }"
                class="number-count"
              ></count-to>
              <h3 v-else class="number-count">$0</h3>
              <p>{{ t(item.title) }}</p>
            </div>
          </div>

          <div class="block-content today-data">
            <p class="title">{{ t('todayData') }}</p>
            <div class="content">
              <div
                v-for="item in visitorsDataRef"
                :key="item.title"
                class="item"
              >
                <count-to
                  v-if="Number(item.number) > 0"
                  :startVal="0"
                  :endVal="item.number"
                  :duration="1500"
                  class="number-count"
                ></count-to>
                <h3 v-else class="number-count">0</h3>
                <p>{{ t(item.title) }}</p>
              </div>
            </div>
          </div>

          <shop-chart ref="shopChartRef" />

          <div class="block-content nav-content">
            <div
              v-for="item in navData"
              :key="item.title"
              class="item"
              @click="openPage(item.href)"
            >
              <div class="icon"><img :src="item.icon" alt="" /></div>
              <p>{{ t(item.title) }}</p>
            </div>
          </div>

          <div class="stat-item-content">
            <div v-for="item in statItemDataRef" :key="item.title" class="item">
              <div class="icon"><img :src="item.icon" alt="" /></div>
              <p>{{ t(item.title) }}</p>
              <count-to
                v-if="Number(item.number) > 0"
                :prefix="item.prefix"
                :startVal="0"
                :endVal="item.number"
                :decimals="item.decimals"
                :duration="1500"
                class="number-count"
              ></count-to>
              <h3 v-else class="number-count">0</h3>
            </div>
          </div>

          <div class="stat-block-content">
            <div
              v-for="item in statBlockDataRef"
              :key="item.title"
              class="item"
              :style="{ 'background-color': item.color }"
            >
              <img :src="blockBg" alt="" />
              <p>{{ t(item.title) }}</p>
              <count-to
                v-if="Number(item.number) > 0"
                :startVal="0"
                :endVal="item.number"
                :duration="1500"
                class="number-count"
              ></count-to>
              <h3 v-else class="number-count">0</h3>
            </div>
          </div>
        </div>

        <div
          v-if="categoryData.length"
          class="data-block-content category-content"
        >
          <div class="title">{{ t('yourCategory') }}<span>(15)</span></div>
          <div class="scroll-content">
            <div class="item-content">
              <div v-for="item in categoryData" :key="item.id" class="item">
                <img :src="item.poster" alt="" />
                <div class="info">
                  <p>{{ item.name }}</p>
                  <p>({{ item.number }})</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="data-block-content goods-content">
          <div class="title">{{ t('saleTop10') }}</div>
          <div class="content">
            <goods-item
              v-for="item in goodsData"
              :key="item.id"
              :goods-data="item"
            />
          </div>
        </div>
      </div>
    </van-pull-refresh>
  </div>
</template>

<script>
import { defineComponent, ref, nextTick } from 'vue'
import ShopHeader from './components/ShopHeader.vue'
import ShopChart from './components/ShopChart.vue'
import GoodsItem from './components/GoodsItem.vue'
import { CountTo } from 'vue3-count-to'
import { useI18n } from 'vue-i18n'
import { openPage } from '@/utils/index'

import {
  saleData,
  visitorsData,
  navData,
  statItemData,
  statBlockData
} from './config'

import {
  sellerInstrumentPanelHead,
  sellerInstrumentPanelStats,
  sellerGoodsList
} from '@/service/shop.api.js'
export default defineComponent({
  name: 'ShopIndex',
  components: {
    ShopHeader,
    ShopChart,
    GoodsItem,
    CountTo
  },
  setup() {
    const { t } = useI18n()

    const shopChartRef = ref(null)
    const refreshing = ref(false)
    const saleDataRef = ref([...saleData])
    const visitorsDataRef = ref([...visitorsData])
    const statItemDataRef = ref([...statItemData])
    const statBlockDataRef = ref([...statBlockData])
    const blockBg = new URL('@/assets/image/shop/bg_01.png', import.meta.url)

    const categoryData = ref([])
    const goodsData = ref([])

    const pageDataInit = async () => {
      sellerInstrumentPanelHead().then((res) => {
        saleDataRef.value[0].number = res.head.totalSales || 0
        saleDataRef.value[1].number = res.head.totalProfit || 0

        visitorsDataRef.value[0].number = res.head.visits1Today || 0
        visitorsDataRef.value[1].number = res.head.visits7Today || 0
        visitorsDataRef.value[2].number = res.head.visits30Today || 0

        statItemDataRef.value[0].number = res.head.todaySales || 0
        statItemDataRef.value[1].number = res.head.todayOrder || 0
        statItemDataRef.value[2].number = res.head.todayProfit || 0
      })

      sellerInstrumentPanelStats().then((res) => {
        statBlockDataRef.value[0].number = res.stats.orderNum || 0
        statBlockDataRef.value[1].number = res.stats.orderIng || 0
        statBlockDataRef.value[2].number = res.stats.orderFinish || 0
        statBlockDataRef.value[3].number = res.stats.orderCancel || 0
      })

      await sellerGoodsList({
        pageNum: 1,
        pageSize: 10,
        isHot: '1'
      }).then((res) => {
        console.log('res ->', res)
        goodsData.value = res.pageList || []
      })
    }

    const onRefresh = async () => {
      shopChartRef.value.getChartData()
      await pageDataInit()
      refreshing.value = false
    }

    nextTick(() => {
      pageDataInit()
    })

    return {
      t,
      saleDataRef,
      visitorsDataRef,
      navData,
      statItemDataRef,
      statBlockDataRef,
      blockBg,
      categoryData,
      goodsData,
      openPage,
      refreshing,
      shopChartRef,
      onRefresh
    }
  }
})
</script>

<style lang="scss" scoped>
.shop-main-content {
  position: relative;
  top: -42px;
  // padding: 0 15px;
  padding-bottom: 20px;
  .block-content {
    background-color: #fff;
    border-radius: 4px;
    margin-bottom: 15px;
  }
  .sale-number {
    padding: 15px 0;
    display: flex;
    align-items: center;
    position: relative;
    &::after {
      content: '';
      display: block;
      width: 1px;
      height: 27px;
      background-color: #f6f6f6;
      position: absolute;
      top: 50%;
      left: 50%;
      margin-top: -13.5px;
      margin-left: 0.5px;
    }
    > .item {
      width: 50%;
      padding: 0 15px 0 25px;
      .number-count {
        font-size: 24px;
        color: #1552f0;
        font-weight: bold;
        &.mini {
          font-size: 18px;
        }
      }
      > p {
        color: #999;
        font-size: 12px;
        margin-top: 10px;
      }
    }
  }
  .today-data {
    padding: 15px 17px;
    > .title {
      font-size: 14px;
      color: #000;
      font-weight: bold;
    }
    > .content {
      display: flex;
      align-items: center;
      margin-top: 20px;
      > .item {
        width: 33.3333%;
        .number-count {
          font-size: 18px;
          color: #000;
          font-weight: bold;
        }
        > p {
          color: #999;
          font-size: 12px;
          margin-top: 10px;
        }
      }
    }
  }

  .nav-content {
    overflow: hidden;
    padding: 18px 0;
    > .item {
      float: left;
      width: 25%;
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 20px;
      &:nth-child(-n + 4) {
        margin-top: 0;
      }
      > .icon {
        width: 30px;
        height: 30px;
      }
      > p {
        font-size: 12px;
        color: #000;
        margin-top: 5px;
      }
    }
  }

  .stat-item-content {
    > .item {
      background-color: #fff;
      border-radius: 4px;
      padding: 15px;
      display: flex;
      align-items: center;
      margin-bottom: 15px;
      > .icon {
        width: 30px;
        height: 30px;
      }
      > p {
        flex: 1;
        font-size: 14px;
        padding: 0 12px;
      }
      .number-count {
        font-size: 18px;
        font-weight: bold;
      }
    }
  }

  .stat-block-content {
    overflow: hidden;
    > .item {
      float: left;
      width: calc((100% - 15px) / 2);
      margin-right: 15px;
      margin-top: 15px;
      padding: 10px;
      border-radius: 4px;
      overflow: hidden;
      position: relative;
      &:nth-child(-n + 2) {
        margin-top: 0;
      }
      &::before {
        content: '';
        display: block;
        width: 72px;
        height: 72px;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.1);
        position: absolute;
        top: -36px;
        right: -36px;
        z-index: 1;
      }
      &:nth-child(2n) {
        margin-right: 0;
      }
      > img {
        width: 100%;
        height: auto;
        position: absolute;
        left: 0;
        bottom: 0;
        z-index: 1;
      }
      > p {
        font-size: 14px;
        color: #fff;
        position: relative;
        z-index: 2;
      }
      .number-count {
        font-size: 20px;
        font-weight: bold;
        color: #fff;
        display: inline-block;
        width: 100%;
        text-align: right;
        margin-top: 20px;
        position: relative;
        z-index: 2;
      }
    }
  }

  .data-block-content {
    margin-top: 23px;
    > .title {
      font-size: 14px;
      color: #333;
      padding: 0 15px;
    }
  }

  .category-content {
    > .scroll-content {
      margin-top: 13px;
      width: 100vw;
      overflow-x: scroll;
      > .item-content {
        white-space: nowrap;
        float: left;
        > .item {
          display: inline-block;
          vertical-align: top;
          width: 120px;
          height: 140px;
          border-radius: 4px;
          overflow: hidden;
          margin-right: 15px;
          position: relative;
          &:first-child {
            margin-left: 15px;
          }
          > img {
            width: 100%;
            height: 100%;
          }
          > .info {
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            position: absolute;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            > p {
              color: #fff;
              font-size: 12px;
              line-height: 16px;
            }
          }
        }
      }
    }
  }

  .goods-content {
    > .content {
      padding: 0 15px;
      margin-top: 13px;
    }
  }
}
</style>
