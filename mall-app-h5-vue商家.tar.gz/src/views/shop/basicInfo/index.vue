<template>
  <div>
    <fx-header :fixed="true">
      <template #title>
        {{ t('basicInfo') }}
      </template>
    </fx-header>
    <div style="height: 46px;" />
    
    <div class="form-content">
      <div class="item">
        <p>ddd</p>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from 'vue'
import { useI18n } from 'vue-i18n'

export default defineComponent({
  name: 'BasicInfo',
  setup() {
    const { t } = useI18n()

    return {
      t
    }
  }
})
</script>

<style lang="less" scoped></style>
