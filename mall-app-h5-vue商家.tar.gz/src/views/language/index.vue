<template>
  <div class="lang h-full bg-white">
    <fx-header>
      <template #title> 语言设置 </template>
    </fx-header>
    <div
      v-for="(item, index) in lang"
      :key="index"
      class="lang-padding"
      @click="handleSetLang(item.key)"
    >
      <div class="lang-title flex items-center font-13 textColor">
        <img class="h-6 mr-3" :src="item.image" alt="" />
        {{ item.title }}
      </div>
      <div class="lang-flex"></div>
      <img
        v-if="item.key == locale"
        src="../../assets/imgs/lang/checked.png"
        style="width: 20px; height: 20px"
      />
    </div>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'
import { SET_LANGUAGE } from '@/store/types.store'
import { useLanguageStore } from '@/store/language.store'
const { locale } = useI18n()
const languageStore = useLanguageStore()

let lang = ref([
  {
    title: '简体中文',
    key: 'zh-CN',
    image: new URL('../../assets/imgs/lang/zh-CN.png', import.meta.url)
  },
  {
    title: '繁体中文',
    key: 'cn',
    image: new URL('../../assets/imgs/lang/taiwan.png', import.meta.url)
  },
  {
    title: 'English',
    key: 'en-US',
    image: new URL('../../assets/imgs/lang/en-US.png', import.meta.url)
  }
  // { title: '韩文', key: 'Korean', image: new URL('../../assets/image/lang/Korean.png', import.meta.url) },
  // { title: '日文', key: 'Japanese', image: new URL('../../assets/image/lang/Japanese.png', import.meta.url) },
])
console.log('lang ->', lang)
onMounted(() => {
  console.log(locale.value)
})
const handleSetLang = (lang) => {
  locale.value = lang
  languageStore[SET_LANGUAGE](lang)
}

// export default {
//   data() {
//     return {
//       lang: [
//         { title: '繁体中文', key: 'CN', image: require('../../assets/image/lang/taiwan.png') },
//         { title: '简体中文', key: 'zh-CN', image: require('../../assets/image/lang/zh-CN.png') },
//         { title: 'English', key: 'en-US', image: require('../../assets/image/lang/en-US.png') },
//         // { title: '日文', key: 'Japanese', image: require('../../assets/image/lang/Japanese.png') },
//         { title: '韩文', key: 'Korean', image: require('../../assets/image/lang/Korean.png') },
//       ]
//     }
//   },
//   components: {

//   },
//   computed: {
//     ...mapGetters({
//       activeLang: 'language'
//     })
//   },
//   methods: {
//     ...mapMutations('language', ['setLanguage']),
//     handleSetLang(lang) {
//       // 设置i18n.locale 组件库会按照上面的配置使用对应的文案文件
//       this.$i18n.locale = lang
//       // 提交mutations
//       this.setLanguage(lang)
//     },
//   }
// }
</script>
<style lang="scss" scoped>
.lang {
  width: 100%;
  box-sizing: border-box;
}

.CommonProblem-padding {
  padding-left: 25px;
  padding-right: 25px;
}

.lang-padding {
  padding: 22px 18px 22px 18px;
  box-sizing: border-box;
  border-bottom: 1px solid #e5e7ed;
  font-weight: 400;
  font-size: 18px;
  color: #000000;
  display: flex;
}

.lang-flex {
  flex: 1;
}
</style>
