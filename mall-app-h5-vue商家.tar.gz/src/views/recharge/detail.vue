<template>
  <fx-header>
    <template #title>
      <div>{{ $t('recharge') }}</div>
    </template>
    <template #right>
      <div @click="handleRecord">{{ $t('rechargeRecord') }}</div>
    </template>
  </fx-header>
  <div class="rechargeDetail">
    <ExRadioGroup
      :list="list"
      :label="$t('blockchainNetwork')"
      v-model="channel"
    />

    <img v-if="qrCodeImgSrc" class="qrCode" :src="qrCodeImgSrc" alt="" />

    <div class="download">
      <van-button type="default" @click="handleDownload"
        >{{ $t('saveQrCode') }}
      </van-button>
    </div>

    <ExInput
      :label="$t('rechargeAddress')"
      v-model="from"
      readonly
      typeText="text"
    >
      <template #rightBtn>
        <div class="rechargeDetail-all" @click="handleCopy">
          {{ $t('copy') }}
        </div>
      </template>
    </ExInput>

    <ExInput
      :label="$t('rechargeAmount')"
      :placeholderText="$t('rechargeAmountTips')"
      v-model="amount"
      :maxLength="8"
      typeText="number"
    >
    </ExInput>

    <ExInput
      :label="$t('expectedAmount', { ratio: computedFee })"
      v-model="realWithdrawAmount"
      :maxLength="18"
      readonly
      typeText="number"
    >
      <template #rightBtn>
        <div class="rechargeDetail-unit">{{ 'USDT' }}</div>
      </template>
    </ExInput>

    <div class="my-uploader">
      <div>{{ $t('uploadPaymentImage') }}</div>
      <van-uploader
        v-model="fileList"
        :max-size="10000 * 1024"
        @oversize="onOversize"
        :after-read="afterRead"
        :max-count="1"
      />
    </div>

    <van-button
      class="w-full"
      style="margin-top: 10px"
      type="primary"
      @click="handleRecharge"
      >{{ $t('submit') }}
    </van-button>
  </div>
</template>

<script setup>
import { ref, onMounted, computed, watch } from 'vue'
import QRCode from 'qrcode'
import NP from 'number-precision'
import { Toast } from 'vant'
import { useI18n } from 'vue-i18n'
import {
  exchangeGetBlockChain,
  exchangeSetRechargeToken,
  exchangeGetRechargeApply
} from '@/service/exchange.api'
import { _uploadImage } from '@/service/upload.api'
import { downloadFile, clipboardText } from '@/utils'
import ExRadioGroup from '@/components/ex-radio-group/index.vue'
import ExChecked from '@/components/ex-checked/index.vue'
import ExInput from '@/components/ex-input/index.vue'
import ExPasswordInput from '@/components/ex-password-input/index.vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/store/user'

const userStore = useUserStore()
const router = useRouter()
const route = useRoute()
const { t } = useI18n()

const userBalance = ref(10e8)
const channel = ref('')
const from = ref('')
const safeword = ref('')
const amount = ref('')
const fee = ref('')
const qrCodeImgSrc = ref('')

const loading = ref(false)

const list = ref([])
const fileList = ref([])
const uploadImg = ref('')

const isEmptyParams = (str) => [null, undefined, ''].includes(str)

const getQrCodeImg = async (src) => {
  qrCodeImgSrc.value = await QRCode.toDataURL(src)
}

watch(
  channel,
  (val) => {
    const dataArr = list.value
    const current = dataArr.find((item) => item.blockchain_name === val)
    const address = current?.address ?? ''
    if (address) {
      from.value = address
      fee.value = current?.fee ?? ''
      getQrCodeImg(address)
    }
  },
  { deep: true }
)

/**
 * 获取提现区块
 */
const getWithdrawBlockChain = () => {
  const id = route.params.id
  exchangeGetBlockChain().then((res) => {
    const filterList = res.filter((i) => i.coin === id?.toUpperCase())
    const newList = filterList.map((i) => ({
      ...i,
      label: i.blockchain_name,
      value: i.blockchain_name
    }))

    if (newList.length) {
      const [first] = newList
      channel.value = first?.value ?? ''
    }
    console.log(11111, newList)

    list.value = newList ?? []
  })
}

onMounted(() => {
  // 获取提现区块
  getWithdrawBlockChain()
})

const realWithdrawAmount = computed(() => {
  const val = amount.value
  const curFee = fee.value ?? 1
  return NP.times(val, curFee)
})

const computedSafeWord = computed(() => {
  const val = safeword.value
  return String(val).length < 6
})

const computedFee = computed(() => {
  const val = fee.value
  return `1:${val}`
})

const handleAll = () => {
  amount.value = userBalance.value
}

const handleRecord = () => {
  router.push({ name: 'RechargeRecord' })
}

const handleDownload = () => {
  downloadFile(qrCodeImgSrc.value, 'QRCode')
}

const onOversize = (file) => {
  Toast(t('fileMaxLimit'))
}

const afterRead = (file) => {
  // 文件上传
  Toast.loading({ duration: 0 })
  _uploadImage(file, (percent) => {
    console.log(percent)
  })
    .then((data) => {
      uploadImg.value = data

      Toast.clear()
    })
    .catch(() => {
      Toast.clear()
    })
}

const handleCopy = () => {
  clipboardText(from.value)
  Toast(t('copySuccess'))
}

/**
 * 充值
 */
const handleRecharge = async () => {
  if (isEmptyParams(channel.value)) {
    Toast(t('blockchainNetworkRequire'))
    return
  }

  if (isEmptyParams(amount.value)) {
    Toast(t('rechargeAmountRequire'))
    return
  }

    if (isEmptyParams(uploadImg.value)) {
    Toast(t('uploadPaymentImageRequire'))
    return
  }

  const params = {
    from: '123', // 客户转出地址
    blockchain_name: channel.value,  //充值链名称
    channel_address: from.value, // 通道充值地址
    amount: amount.value, // 充值金额
    img: uploadImg.value, // 已充值的上传图片 
    coin: (route.params.id ?? '').toUpperCase(), // 充值币种
    tx: ''// 转账hash
  }

  await exchangeSetRechargeToken({ session_token: userStore?.userInfo?.token })

  loading.value = true
  exchangeGetRechargeApply(params)
    .then((res) => {
      console.log(1111, res)
      Toast(t('rechargeApplySuccess'))
    })
    .finally(() => {
      loading.value = false
    })
}


</script>

<style scoped lang="scss">
.rechargeDetail {
  padding: 25px;
  height: calc(100vh - var(--van-nav-bar-height));
  background-color: $background-color;
  overflow-y: scroll;

  :deep(.inputCom) {
    .label {
      font-size: 12px;
    }

    input {
      font-size: 14px !important;
    }
  }

  .qrCode {
    width: 160px;
    height: 160px;
    margin: 0 auto;
  }

  .download {
    margin: 10px 0 20px;
    text-align: center;

    :deep(.van-button) {
      border-radius: 4px;
    }
  }

  .my-uploader {
    > div:nth-child(1) {
      font-size: 12px;
    }

    :deep(.van-uploader) {
      margin-top: 10px;
      margin-bottom: 20px;
      border: 1px dashed $border-color-ddd;
      border-radius: 4px;

      .van-uploader__upload {
        width: 110px;
        height: 110px;
        background: transparent;
        margin: 0;
      }

      .van-uploader__preview {
        width: 110px;
        height: 110px;
        margin: 0;

        .van-uploader__preview-image {
          width: 100%;
          height: 100%;
        }
      }
    }
  }

  .tips {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
    padding-bottom: 10px;

    span:nth-child(1) {
      color: $text-color-light;
    }

    span:nth-child(2) {
      color: $primary-color;
    }
  }

  :deep(.inputBackground) {
    background: transparent;

    input {
      padding-left: 0;
    }
  }

  :deep(.inputBackground.iptbox) {
    border: 1px solid $border-color;
  }

  &-all {
    font-size: 14px;
    color: $primary-color;
    padding-left: 6px;
  }

  &-unit {
    font-size: 14px;
    padding-left: 6px;
  }
}

.popup-content {
  padding: 80px 30px 0;
}
</style>
