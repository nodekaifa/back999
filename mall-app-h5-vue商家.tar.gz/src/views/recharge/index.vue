<template>
  <fx-header>
    <template #title>
      <div>{{ $t('recharge') }}</div>
    </template>
    <template #right>
      <div @click="handleRecord">{{ $t('rechargeRecord') }}</div>
    </template>
  </fx-header>
  <div class="recharge">
    <img :src="Banner" alt="" />

    <div class="tips">
      {{ $t('rechargeDescribe') }}
    </div>

    <div class="content">
      <van-cell-group inset>
        <van-cell is-link v-for="item in list" :key="item.id" @click="handleClick(item.id)">
          <template #title>
            <div class="flex items-center content-item">
              <img :src="item.icon" alt="">
              <div class="ml-2 color-333">
                {{ item.text }}
              </div>
            </div>
          </template>
        </van-cell>
      </van-cell-group>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import {useRouter} from 'vue-router';
import Banner from '@/assets/image/exchange/banner.png'
import USDT from '@/assets/image/exchange/usdt.png'
import ETH from '@/assets/image/exchange/eth.png'
import BTC from '@/assets/image/exchange/btc.png'
const router = useRouter();

const list = ref([
  {
    icon: USDT,
    text: 'USDT',
    id: 'usdt'
  },
  {
    icon: ETH,
    text: 'ETH',
    id: 'eth'
  },
  {
    icon: BTC,
    text: 'BTC',
    id: 'btc'
  }
])

const handleRecord = () => {
  router.push({ name: 'RechargeRecord' })
}

const handleClick = (id) => {
  router.push({ path: `/recharge/${id}` })
}
</script>

<style scoped lang="scss">
.recharge {
  padding: 25px 15px 0;
  height: calc(100vh - var(--van-nav-bar-height));
  background-color: $background-color;
  text-align: center;

  img {
    width: 100%;
    margin-bottom: 15px;
    max-width: 1000px;
  }

  .tips {
    background: #eff2f6;
    padding: 10px;
    font-size: 14px;
    line-height: 20px;
    color: $text-color-light;
  }

  .content {
    display: block;
    margin-top: 15px;

    .van-cell-group {
      margin: 0;

      :deep(.van-cell) {
        padding: 15px 10px;

        &::after {
          border-color: transparent;
        }
      }
    }

    &-item {

      img {
        width: 28px;
        height: 28px;
        margin-bottom: 0;
      }
    }
  }
}
</style>
