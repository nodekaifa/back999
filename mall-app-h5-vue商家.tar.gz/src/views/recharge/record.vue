<template>
  <div class="record pb-12">
    <fx-header fixed>
      <template #title>{{ $t('rechargeRecord') }}</template>
    </fx-header>
    <div class="list-wrap">
      <van-pull-refresh v-model="loading" @refresh="onRefresh">
        <van-list
          v-model:loading="loading"
          :finished="finished"
          :finished-text="$t('noMore')"
          @load="onLoad"
        >
          <ul>
            <li class="px-2 mt-4" v-for="(item, idx) in list" :key="idx">
              <div class="item">
                <div class="label">{{ $t('rechargeOrderNumber') }}</div>
                <div class="value">
                  <span>{{ item.order_no }}</span>
                  <svg
                    @click="handleCopy(item.order_no)"
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    class="feather feather-copy"
                  >
                    <rect
                      x="9"
                      y="9"
                      width="13"
                      height="13"
                      rx="2"
                      ry="2"
                    ></rect>
                    <path
                      d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
                    ></path>
                  </svg>
                </div>
              </div>
              <div class="item">
                <div class="label">{{ $t('rechargeOrderTime') }}</div>
                <div class="value">{{ item.createTime }}</div>
              </div>
              <div class="item">
                <div class="label">{{ $t('rechargeOrderAmount') }}</div>
                <div class="value">{{ item.volume }} {{ item.coin }}</div>
              </div>
              <div class="item">
                <div class="label">{{ $t('rechargeOrderStatus') }}</div>
                <div class="value" :class="`color-${item.state}`">
                  {{ getStatusName(item.state) }}
                </div>
              </div>
            </li>
          </ul>
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Toast } from 'vant'
import { exchangeGetRechargeRecord } from '@/service/exchange.api'
import { useI18n } from 'vue-i18n'
import { clipboardText } from '@/utils'
const { t } = useI18n()

// 充值状态 0 初始状态，审核中 1 成功 2 失败
const list = ref([])
const loading = ref(false)
const finished = ref(false)
const page_no = ref(1)

const getStatusName = (status) => {
  const statusMap = {
    0: t('processing'),
    1: t('successful'),
    2: t('failure')
  }
  return statusMap[status] ?? ''
}

const handleCopy = (order_no) => {
  if (order_no) {
    clipboardText(order_no)
    Toast(t('copySuccess'))
  }
}

const request = () => {
  loading.value = true
  finished.value = false
  
  const params = {
    page_no: page_no.value
  }
  exchangeGetRechargeRecord(params)
    .then((res) => {
      list.value = res
    })
    .finally(() => {
      loading.value = false
      finished.value = true
    })
}

const onLoad = () => {
  request()
}

const onRefresh = () => {
  request()
}
</script>
<style lang="scss" scoped>
.record {
  padding-top: var(--van-nav-bar-height);
  box-sizing: border-box;

  // .list-wrap {
  //   height: calc(100vh - var(--van-nav-bar-height));
  //   overflow-y: scroll;
  // }

  :deep(.van-list) {
    min-height: calc(100vh - var(--van-nav-bar-height) - 50px);
  }

  .item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: $background-color;
    padding: 10px 15px;
    border-radius: 4px;
    font-size: 14px;

    .label {
      color: $text-color-default;
    }

    .value {
      display: flex;
      align-items: center;
      color: $text-color-dark;

      svg {
        margin-left: 4px;
        color: $text-color-light;
      }

      &.color-1 {
        color: #0ecb81;
      }

      &.color-2 {
        color: #ff3e3e;
      }

      &.color-0 {
        color: $primary-color;
      }
    }
  }
}
</style>
