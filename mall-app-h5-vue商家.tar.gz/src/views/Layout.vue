<template>
    <router-view />
</template>