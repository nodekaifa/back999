<template>
  <div class="flex flex-col h-full bg-white">
    <fxHeader>
      <template #title>
        <span class="font-16 color-333">Funding records</span>
      </template>
      <template #right>
        <img @click="showSelect = true" class="w-5 h-5" src="@/assets/image/fundsRecords/Frame1277.png" alt="">
      </template>
    </fxHeader>
    <div class="flex-1">

      <van-pull-refresh class="h-full" v-model="refreshing" @refresh="onRefresh">
        <van-list
            class="h-full overflow-auto"
            v-model:loading="loading"
            :finished="finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <money-log-list
              v-for="(item, index) in list"
              :item="item"
              :key="index"
          />
        </van-list>
      </van-pull-refresh>

    </div>
  </div>
  <van-popup v-model:show="showSelect" position="bottom" :close-on-click-overlay="false">
    <div>
      <div class="select-header flex items-center justify-center font-14">
        <div class="cancel" @click="cancelClick">取消</div>
        <div class="font-16">筛选信息</div>
        <div class="enter" style="color: #1552F0;" @click="enterClick">确定</div>
      </div>
      <SelectList :list="selectList" v-model:value="selectVal"/>
    </div>
  </van-popup>
</template>

<script setup>
import {ref, onBeforeMount} from 'vue'

import {List, PullRefresh, Toast, Popup} from 'vant';
import MoneyLogList from "@/views/fundsRecords/MoneyLogList.vue";
import SelectList from "@/views/fundsRecords/SelectList.vue";
import {useUserStore} from "@/store/user.js";
import {_getMoneyLogList} from '@/service/fundsRecords.api.js'

const userStore = useUserStore();
console.log(userStore.userInfo);

const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);

// 获取数据
const page = ref(10)
const list = ref([])

const handleData = data => {
  if (refreshing.value) {
    // list.value = [];
    refreshing.value = false;
  }
  list.value = list.value.concat(data);
  page.value++;
  loading.value = false;

  if (list.value.length >= 40) {
    finished.value = true;
  }
}

const getList = async () => {
  const res = await _getMoneyLogList({page_no: page.value})
  console.log(res);
  handleData(res);
}

const onLoad = () => {
  getList()
};

const onRefresh = () => {
  // 清空列表数据
  // list.value = [];
  finished.value = false;

  // 重新加载数据
  // 将 loading 设置为 true，表示处于加载状态
  loading.value = true;
  onLoad();
};

const showSelect = ref(false);
const selectList = ref([
  {name: '全部'},
  {name: '充值'},
  {name: '提现'},
  {name: '推广佣金'},
  {name: '商品退款'},
  {name: '商品采购'},
])
const selectVal = ref('全部');

const cancelClick = () => {
  showSelect.value = false
}

const enterClick = () => {
  showSelect.value = false
  console.log(selectVal.value);
}


</script>

<style lang="scss" scoped>
.select-header {
  position: relative;
  height: 50px;

  .cancel, .enter {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
  }

  .cancel {
    left: 15px;
  }

  .enter {
    right: 15px;
  }
}

</style>