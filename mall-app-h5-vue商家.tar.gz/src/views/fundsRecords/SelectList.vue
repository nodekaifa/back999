<template>
  <div class="select-list-wrapper">
    <div
        class="select-list-item van-hairline--top color-333"
        v-for="(item, index) in list"
        :key="index"
        @click="handleClick(item.name)"
    >
      {{ item.name }}
      <img v-show="value === item.name" src="@/assets/image/fundsRecords/icon_check.png" alt="">
    </div>
  </div>
</template>

<script setup>
import { useVModels } from "@vueuse/core";

const props = defineProps(['list', 'value'])

const emits = defineEmits(['update:value'])

const { value } = useVModels(props,emits)

const handleClick = val => {
  value.value = val;
}


</script>

<style lang="scss" scoped>
.select-list-item {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 50px;
  font-size: 14px;
  box-sizing: border-box;

  img {
    position: absolute;
    top: 50%;
    right: 19px;
    transform: translateY(-50%);
    width: 18px;
    height: 18px;
  }
}

</style>