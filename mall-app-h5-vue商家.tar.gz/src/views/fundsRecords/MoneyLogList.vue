<template>
<div class="flex items-center justify-between" v-if="Object.keys(item).length > 0">
  <div class="pl-4">
    <template v-if="item.amount < 0">
      <img class="w-5 h-5" src="@/assets/image/fundsRecords/out.png" alt="">
    </template>
    <template v-else>
      <img class="w-5 h-5" src="@/assets/image/fundsRecords/in.png" alt="">
    </template>
  </div>
  <div class="flex-1 flex justify-between items-center py-4 pr-4 ml-4 van-hairline--bottom">
    <div class="font-14">
      <div class="mb-2.5 text-black">{{ item.content_type }}</div>
      <div class="mb-2 font-12">{{ item.createTimeStr }}</div>
      <div class="font-12">{{ item.wallettype }}</div>
    </div>
    <div :class="[item.amount < 0 ? 'down' : 'up']" class="font-14">{{ item.amount }}</div>
  </div>
</div>
</template>

<script setup>
const props = defineProps(['item'])
</script>

<style lang="scss" scoped>
.up {
  color: #0ECB81;
}

.down {
  color: #FF3E3E;
}

</style>