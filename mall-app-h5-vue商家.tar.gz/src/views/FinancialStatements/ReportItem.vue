<template>
  <div class="report-item relative p-4 mt-4 bg-white text-black font-12">
    <div class="flex items-center mb-4">
      <img class="w-5 h-5" src="@/assets/image/finance/calendar.png" alt="">
      <div class="ml-2.5">
        <span>Order date: </span>
        <span>{{ item.dayString }}</span>
      </div>
    </div>
    <div class="flex items-center mb-4">
      <img class="w-5 h-5" src="@/assets/image/finance/credit-card.png" alt="">
      <div class="ml-2.5">
        <span>Payment status: </span>
        <span>Not paid</span>
      </div>
    </div>
    <div class="flex items-center mb-4">
      <img class="w-5 h-5" src="@/assets/image/finance/cancel.png" alt="">
      <div class="ml-2.5">
        <span>Procurement status: </span>
        <span>{{ item.orderCancel }}</span>
      </div>
    </div>
    <div class="flex items-center mb-4">
      <img class="w-5 h-5" src="@/assets/image/finance/ri_refund.png" alt="">
      <div class="ml-2.5">
        <span>Logistics Status: </span>
        <span>{{ item.orderReturns }}</span>
      </div>
    </div>
    <div class="absolute right-4 top-4">
      <div class="mb-0.5 font-20 font-semibold" style="color: #1552F0;">${{ item.orderNum }}</div>
      <div class="profit relative font-12" style="color: #999999;">（利润${{ item.totalProfit }}）</div>
    </div>
  </div>
</template>

<script setup>
const props = defineProps(['item'])
</script>

<style lang="scss" scoped>
.profit {
  left: -13px;
}

.report-item {
  border-radius: 4px;
}
</style>