<template>
  <div class="flex flex-col w-full h-full">
    <fxHeader>
      <template #title>
        <span class="font-16 color-333">财务报表</span>
      </template>
    </fxHeader>
    <div class="flex-1 px-4 pb-4 overflow-auto" style="background: #EFF2F6;">
      <div class="report-head-wrapper">
        <div class="item">
          <div class="title">{{ headTitle.willIncome }}</div>
          <div class="number">{{ headData.willIncome }}</div>
        </div>
        <div class="item">
          <div class="title">{{ headTitle.totalProfit }}</div>
          <div class="number">{{ headData.totalProfit }}</div>
        </div>
        <div class="item">
          <div class="title">{{ headTitle.orderNum }}</div>
          <div class="number">{{ headData.orderNum }}</div>
        </div>
        <div class="item">
          <div class="title">{{ headTitle.totalSales }}</div>
          <div class="number">{{ headData.totalSales }}</div>
        </div>
        <div class="item">
          <div class="title">{{ headTitle.orderCancel }}</div>
          <div class="number">{{ headData.orderCancel }}</div>
        </div>
        <div class="item">
          <div class="title">{{ headTitle.orderReturns }}</div>
          <div class="number">{{ headData.orderReturns }}</div>
        </div>
      </div>
      <ReportItem
          v-for="(item, index) in list"
          :key="index"
          :item="item"
      />
    </div>
  </div>
</template>

<script setup>

import {ref, onBeforeMount} from 'vue'
import ReportItem from './ReportItem.vue'
import {_getSellerReport} from '@/service/FinancialStatements.api.js'

const headData = ref({})
const headTitle = ref({
  totalProfit: '总利润',
  totalSales: '总销售额',
  willIncome: '总收入',
  orderCancel: '取消订单',
  orderNum: '总订单',
  orderReturns: '退款订单',

})

onBeforeMount(() => {
  _getSellerReport().then(res => {
    headData.value = res.data.data.head;
    console.log(Object.keys(headData.value));
  })
})

const list = ref([
  {
    dayString: '16-10-2022',
    orderNum: '18.89',
    orderCancel: 'Not procured',
    orderReturns: 'Pending delivery',
    totalProfit: '3.15'
  },
  {
    dayString: '16-10-2022',
    orderNum: '18.89',
    orderCancel: 'Not procured',
    orderReturns: 'Pending delivery',
    totalProfit: '3.15'
  },
  {
    dayString: '16-10-2022',
    orderNum: '18.89',
    orderCancel: 'Not procured',
    orderReturns: 'Pending delivery',
    totalProfit: '3.15'
  },
])
</script>

<style lang="scss" scoped>
.report-head-wrapper {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 15px;
  margin-top: 13px;

  .item {
    position: relative;
    height: 90px;
    padding: 10px;
    border-radius: 4px;
    box-sizing: border-box;
    background: #41A3FF;
    color: #fff;

    &:nth-child(2) {
      background: #54C1FF;
    }
    &:nth-child(3) {
      background: #3CCDC4;
    }
    &:nth-child(4) {
      background: #FF6F4F;
    }
    &:nth-child(5) {
      background: #757F8F;
    }
    &:nth-child(6) {
      background: #DD4E4E;
    }

    .title {
      font-size: 14px;
    }

    .number {
      position: absolute;
      bottom: 12px;
      right: 13px;
      font-size: 20px;
      font-weight: 700;
    }
  }
}

</style>