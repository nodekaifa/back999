<template>
  <div class="h-full w-full">
    <fx-header>
      <template #title>
        {{ $t('setting') }}
      </template>
    </fx-header>
    <van-cell-group>
      <van-cell title="Clear cache" value="0MB" />
      <van-cell @click="testUpdate" title="Testing updates" is-link value="V1.02" />
    </van-cell-group>
    <div class="btn">
      <van-button type="danger" block @click="loginOut">退出</van-button>
    </div>
  </div>
</template>

<script setup>
import { Toast } from "vant";
import { useRouter} from "vue-router";
import { useI18n } from 'vue-i18n';
import {useUserStore} from "@/store/user.js";
const { t } = useI18n();
const router = useRouter();

// TODO: 推出登录
const loginOut = () => {
  let userStore = useUserStore()
  userStore.logout() // 恢复初始化
}

const testUpdate = () => {
  Toast.loading({
    message: '加载中...',
    forbidClick: true,
  });
  setTimeout(() => {
    Toast('当前已是最新版本，无需更新~');
  }, 2000)
}
</script>

<style scoped>
.btn {
  margin: var(--van-cell-group-inset-padding);
  margin-top: 1rem;
}

:deep(.van-button) {
  border-radius: 4px;
}

:deep(.van-cell__title), :deep(.van-cell__value) {
  color: #333;
}
</style>
