import { createI18n } from 'vue-i18n'
import { getStorage } from '@/utils/index'
import enLocale from './en'
import cnLocale from './cn'
import zhcnLocale from './zhcn'
// import korcnLocale from './korean'
// import japcnLocale from './Japanese'
const lang = getStorage('lang') || 'en-US'

const messages = {
  'en-US': {
    ...enLocale
  },
  'cn': {
    ...cnLocale
  },
  'zh-CN': {
    ...zhcnLocale
  },
  // 'Korean': {
  //   ...korcnLocale
  // },
  // 'Japanese': {
  //   ...japcnLocale
  // },
}


const i18n = createI18n({
  legacy: false,
  locale: lang, // 首先从缓存里拿，没有的话就用浏览器语言，
  fallbackLocale: 'CN', // 设置备用语言
  messages,
})

export default i18n