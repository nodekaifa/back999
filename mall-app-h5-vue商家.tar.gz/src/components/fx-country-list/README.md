# IntlTelInput

>  International telephone area code selection component base on Vue.

<img width="434" alt="2018-11-20 11 01 11" src="https://user-images.githubusercontent.com/9512362/48748981-b54fb100-ecb3-11e8-8225-08aca68e8e32.png">
