<template>
  <div class="relative z-30 footer">
    <van-tabbar
      route
      v-model="active"
      active-color="#1D91FF"
      fixed
      safe-area-inset-bottom
    >
      <van-tabbar-item name="shop" to="/shop">
        <span>{{ $t('shop') }}</span>
        <template #icon="props">
          <img :src="props.active ? icon.shop.active : icon.shop.inactive" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item name="trade" to="/product">
        <span>{{ $t('producte') }}</span>
        <template #icon="props">
          <img
            :src="props.active ? icon.product.active : icon.product.inactive"
          />
        </template>
      </van-tabbar-item>
      <van-tabbar-item name="order" to="/order">
        <span>{{ $t('order') }}</span>
        <template #icon="props">
          <img :src="props.active ? icon.order.active : icon.order.inactive" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item name="mine" to="/my">
        <span>{{ $t('home') }}</span>
        <template #icon="props">
          <img :src="props.active ? icon.home.active : icon.home.inactive" />
        </template>
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'
const { t } = useI18n()
const active = ref('home')

// 底部列表
const icon = {
  shop: {
    active: new URL('@/assets/imgs/footer/shop-active.png', import.meta.url),
    inactive: new URL('@/assets/imgs/footer/shop-inactive.png', import.meta.url)
  },
  '': {
    active: new URL('@/assets/imgs/footer/product-active.png', import.meta.url),
    inactive: new URL(
      '@/assets/imgs/footer/product-inactive.png',
      import.meta.url
    )
  },
  product: {
    active: new URL('@/assets/imgs/footer/product-active.png', import.meta.url),
    inactive: new URL(
      '@/assets/imgs/footer/product-inactive.png',
      import.meta.url
    )
  },
  order: {
    active: new URL('@/assets/imgs/footer/order-active.png', import.meta.url),
    inactive: new URL(
      '@/assets/imgs/footer/order-inactive.png',
      import.meta.url
    )
  },
  home: {
    active: new URL('@/assets/imgs/footer/home-active.png', import.meta.url),
    inactive: new URL('@/assets/imgs/footer/home-inactive.png', import.meta.url)
  }
}
</script>

<style lang="scss" scoped>
:deep(.van-tabbar-item__text) {
  font-size: 12px;
}
</style>
