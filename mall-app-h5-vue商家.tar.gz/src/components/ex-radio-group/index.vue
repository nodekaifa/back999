<template>
  <div class="my-radio-group">
    <span class="label textColor">{{ label }}</span>
    <div class="container">
      <div
        v-for="item in list"
        :key="item.value"
        :class="{ active: item.value === modelValue, item: true }"
        @click.stop.prevent="handleRadioGroup(item.value)"
      >
        {{ item.label }}
      </div>
    </div>
  </div>
</template>

<script setup>
const $emit = defineEmits(['selectRadio', 'update:modelValue'])

const selectRadio = () => {
  console.log(1)
  $emit('selectRadio', true)
}


const props = defineProps({
  label: {
    type: String,
    default: ''
  },

  /**
   * [{ label: '', value: 1 }]
   */
  list: {
    type: Array,
    default: []
  },

  modelValue: {
    type: [Number, String],
    default: '1'
  }
})


const handleRadioGroup = (val) => {
   $emit('update:modelValue', val)
}
</script>

<style lang="scss" scoped>
.my-radio-group {

  .label {
    font-size: 12px;
  }

  .container {
    padding-top: 10px;
    padding-bottom: 22px;
    display: flex;
    flex-wrap: wrap;

    .item {
      position: relative;
      width: 105px;
      height: 44px;
      border: 1px solid $border-color-ddd;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      color: $text-color-light;

      &:not(:last-child) {
        margin-right: 15px;
      }

      &.active {
        border-color: $primary-color;
        color: $primary-color;

        &::after {
          content: '';
          position: absolute;
          width: 23px;
          height: 23px;
          bottom: 0;
          right: 0;
          background: url('@/assets/image/exchange/block_choose.png') no-repeat bottom right;
          background-size: contain;
        }
      }
    }
  }
}
</style>
