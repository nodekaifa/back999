import fxHeader from './index.vue'

export default {
    install(app) {
        app.component('fxHeader', fxHeader)
    }
}