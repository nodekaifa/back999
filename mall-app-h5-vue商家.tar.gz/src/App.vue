<template>
  <router-view />
  <fx-footer v-if="route.meta.tarbar" />
</template>

<script setup>
import fxFooter from '@/components/fx-footer/index.vue'
import { useRoute, useRouter } from 'vue-router';

const route = useRoute()
window.router = useRouter()

</script>
<style lang="scss">
.nationList {
  .van-action-sheet {
    height: 80%;
  }
}
.van-search__content{
	 	  background:#fff !important;
	 	 
	  }
	.van-dropdown-menu__bar{
		height:44px !important;
	}
	.van-tab--active{
		 color:#1552F0 !important; 
	}
	
</style>
