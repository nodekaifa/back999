import { defineStore } from 'pinia'
import { useStorage } from '@vueuse/core'
import { GET_USERINFO, GET_BALANCE } from '@/store/types.store'
import { _info, _getBalance } from "@/service/user.api.js";
let state = useStorage('user', {
        userInfo: {
            token: ''
        }
    })
export const useUserStore = defineStore('user', {

    // state 持久化
    state: () => state,
    getters: {
    },
    actions: {
        async [GET_USERINFO](userInfoObj) { // 发送请求获取信息
            console.log(userInfoObj)
            this.userInfo = userInfoObj
            let data = await _info()
            this.userInfo = { ...this.userInfo, ...data }
            let res = await _getBalance()
            let obj = { 'balance': res.money }
            this.userInfo = { ...this.userInfo, ...obj }
            console.log('userinfo', this.userInfo)
        },
        async getUserInfo() {
            return new Promise(async (resolve, reject) => {
                if (this.userInfo.token) {
                    resolve(this.userInfo)
                } else {
                    let data
                    try {
                        data = await _info()
                    } catch (err) {
                        reject(err)
                    }

                    try {
                        let res = await _getBalance()
                        let obj = {'balance': res.money}
                        this.userInfo = {...data, ...obj}
                        resolve(this.userInfo)
                    } catch (err) {
                        reject(err)
                    }
                }
            })
        },
        async [GET_BALANCE]() {
            const res = await _getBalance()
            const obj = { 'balance': res.money }
            this.userInfo = { ...this.userInfo, ...obj }
        },
        logout() {
            this.$reset()
            state.value = {
                userInfo: {
                    token: ''
                }
            }
            window.router.push('/login')
        }
    },
})
