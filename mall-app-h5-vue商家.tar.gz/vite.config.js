import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'
import Components from 'unplugin-vue-components/vite';
import { VantResolver } from 'unplugin-vue-components/resolvers';
const scss_path = `@/assets/init.scss`

const addScssPath = `@/assets/scss/theme.scss`

export default defineConfig({
  base: '/www/',
  plugins: [
    vue(),
    Components({
      resolvers: [VantResolver()],
    }),
  ],
  css: {
    loaderOptions: {
      scss: {
        additionalData: `@import "${scss_path}";`
      },
    },
    preprocessorOptions: {
      scss: {
        additionalData: `@import "${addScssPath}";`
      }
    }
  },
  server: {
    open: true,
    port: 8080,
    hmr: true,
    host: '0.0.0.0',
    proxy: {
      "/wap/api": {
        // target: "https://uhjhajfsd.site",
        target: "https://thsjbvh.site",
        // target: "https://rfbhabkjk.com",
        changeOrigin: true,
        // rewrite: (path) => path.replace(/^\/wap/, ""),
        secure: false
      },
      "/wap/seller": {
        // target: "https://uhjhajfsd.site",
        target: "https://thsjbvh.site",
        changeOrigin: true,
        // rewrite: (path) => path.replace(/^\/wap/, ""),
        secure: false
      },
      // "/wap/seller/report!head.action": {
      //   // target: "https://uhjhajfsd.site",
      //   target: "https://thsjbvh.site",
      //   changeOrigin: true,
      //   // rewrite: (path) => path.replace(/^\/wap/, ""),
      //   secure: false
      // },
      // "/wap/seller/orders!list-returns.action": {
      //   // target: "https://uhjhajfsd.site",
      //   target: "https://thsjbvh.site",
      //   changeOrigin: true,
      //   // rewrite: (path) => path.replace(/^\/wap/, ""),
      //   secure: false
      // },
    },
  },
  resolve: {
    alias: {
      'vue-i18n': 'vue-i18n/dist/vue-i18n.cjs.js',
      "~": path.resolve(__dirname, './'),
      "@": path.resolve(__dirname, 'src'),
    }
  },
  build: {
    assetsDir: "static",
    rollupOptions: {
      input: {
        index: path.resolve(__dirname, "index.html"),
      },
      output: {
        chunkFileNames: 'js/[name]-[hash].js',
        entryFileNames: "js/[name]-[hash].js",
        assetFileNames: "[ext]/name-[hash].[ext]"
      }
    },
  },
})

const globalSass = config => {
  const oneOfsMap = config.module.rule('scss').oneOfs.store
  oneOfsMap.forEach(item => {
    item
      .use('sass-resources-loader')
      .loader('sass-resources-loader')
      .options({
        resources: '@/assets/init.scss'
      })
      .end()
  });
}
