<template>
  <div id="app">
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script>
  // import Tables from "./pages/tables.vue";
  export default {
    name: "App",
    components: {},
  };
</script>

<style>
  #app {
  }
</style>
